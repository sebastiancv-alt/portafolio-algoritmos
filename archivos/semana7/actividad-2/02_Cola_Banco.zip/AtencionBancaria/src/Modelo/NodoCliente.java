package Modelo;

public class NodoCliente {

    private UsuarioBanco cliente;
    private NodoCliente siguiente;

    public NodoCliente(UsuarioBanco cliente) {
        this.cliente = cliente;
        this.siguiente = null;
    }

    public UsuarioBanco getCliente() {
        return cliente;
    }

    public void setCliente(UsuarioBanco cliente) {
        this.cliente = cliente;
    }

    public NodoCliente getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCliente siguiente) {
        this.siguiente = siguiente;
    }
}
