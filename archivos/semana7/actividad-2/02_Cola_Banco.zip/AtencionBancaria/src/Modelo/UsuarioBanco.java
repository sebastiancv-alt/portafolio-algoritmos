package Modelo;

public class UsuarioBanco {

    private String ticket;
    private String documento;
    private String nombre;
    private String tramite;
    private int nivelPrioridad;
    private String horaIngreso;

    public UsuarioBanco(String ticket, String documento, String nombre,
            String tramite, int nivelPrioridad, String horaIngreso) {
        setTicket(ticket);
        setDocumento(documento);
        setNombre(nombre);
        setTramite(tramite);
        setNivelPrioridad(nivelPrioridad);
        setHoraIngreso(horaIngreso);
    }

    private static String requerido(String valor, String campo) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException("El campo " + campo + " es obligatorio.");
        }
        return valor.trim();
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = requerido(ticket, "número de ticket");
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        String d = requerido(documento, "documento");
        if (!d.matches("\\d{8}")) {
            throw new IllegalArgumentException("El documento debe tener 8 dígitos.");
        }
        this.documento = d;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = requerido(nombre, "nombre");
    }

    public String getTramite() {
        return tramite;
    }

    public void setTramite(String tramite) {
        this.tramite = requerido(tramite, "tipo de trámite");
    }

    public int getNivelPrioridad() {
        return nivelPrioridad;
    }

    public void setNivelPrioridad(int nivelPrioridad) {
        if (nivelPrioridad != 1 && nivelPrioridad != 2) {
            throw new IllegalArgumentException("La prioridad debe ser 1 (Normal) o 2 (Preferencial).");
        }
        this.nivelPrioridad = nivelPrioridad;
    }

    public String getHoraIngreso() {
        return horaIngreso;
    }

    public void setHoraIngreso(String horaIngreso) {
        this.horaIngreso = requerido(horaIngreso, "hora de llegada");
    }

    @Override
    public String toString() {
        return "Ticket: " + ticket
                + " | Doc: " + documento
                + " | Cliente: " + nombre
                + " | Trámite: " + tramite
                + " | Prioridad: " + (nivelPrioridad == 2 ? "Preferencial" : "Normal")
                + " | Hora: " + horaIngreso;
    }
}
