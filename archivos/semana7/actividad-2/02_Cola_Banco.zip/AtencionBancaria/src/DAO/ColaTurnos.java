package DAO;

import Modelo.UsuarioBanco;
import Modelo.NodoCliente;

public class ColaTurnos {

    private NodoCliente frente;
    private NodoCliente fin;
    private int tamano;

    public ColaTurnos() {
        this.frente = null;
        this.fin = null;
        this.tamano = 0;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public int getTamano() {
        return tamano;
    }

    public void encolar(UsuarioBanco cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser null.");
        }
        if (existeTicket(cliente.getTicket())) {
            throw new IllegalArgumentException("Ya existe un ticket con ese número.");
        }
        NodoCliente nuevo = new NodoCliente(cliente);
        if (estaVacia()) {
            frente = nuevo;
        } else {
            fin.setSiguiente(nuevo);
        }
        fin = nuevo;
        tamano++;
    }

    public UsuarioBanco desencolar() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola de atención está vacía.");
        }
        UsuarioBanco atendido = frente.getCliente();
        NodoCliente viejo = frente;
        frente = frente.getSiguiente();
        viejo.setSiguiente(null);
        if (frente == null) {
            fin = null;
        }
        tamano--;
        return atendido;
    }

    public UsuarioBanco consultarSiguiente() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: no hay turnos pendientes.");
        }
        return frente.getCliente();
    }

    public void mostrarCola() {
        if (estaVacia()) {
            System.out.println("La cola de espera se encuentra vacía.");
            return;
        }
        System.out.println("\n--- COLA DE ESPERA ACTUAL (" + tamano + " clientes) ---");
        NodoCliente actual = frente;
        int posicion = 1;
        while (actual != null) {
            System.out.println(posicion + ". " + actual.getCliente());
            actual = actual.getSiguiente();
            posicion++;
        }
        System.out.println("--------------------------------------------------");
    }

    public UsuarioBanco buscarCliente(String criterio) {
        if (criterio == null || criterio.trim().isEmpty()) {
            throw new IllegalArgumentException("El criterio de búsqueda es obligatorio.");
        }
        NodoCliente actual = frente;
        while (actual != null) {
            UsuarioBanco c = actual.getCliente();
            if (c.getTicket().equalsIgnoreCase(criterio.trim())
                    || c.getDocumento().equalsIgnoreCase(criterio.trim())) {
                return c;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public boolean eliminarPorTicket(String numeroTicket) {
        if (estaVacia()) {
            return false;
        }
        if (frente.getCliente().getTicket().equalsIgnoreCase(numeroTicket.trim())) {
            desencolar();
            return true;
        }
        NodoCliente anterior = frente;
        NodoCliente actual = frente.getSiguiente();
        while (actual != null
                && !actual.getCliente().getTicket().equalsIgnoreCase(numeroTicket.trim())) {
            anterior = actual;
            actual = actual.getSiguiente();
        }
        if (actual == null) {
            return false;
        }
        anterior.setSiguiente(actual.getSiguiente());
        if (actual == fin) {
            fin = anterior;
        }
        actual.setSiguiente(null);
        tamano--;
        return true;
    }

    private boolean existeTicket(String ticket) {
        NodoCliente actual = frente;
        while (actual != null) {
            if (actual.getCliente().getTicket().equalsIgnoreCase(ticket)) {
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }
}
