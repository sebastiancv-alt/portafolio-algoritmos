package Vista;

import java.util.Scanner;
import DAO.ColaTurnos;
import Modelo.UsuarioBanco;

public class MenuBanco {

    private static final Scanner teclado = new Scanner(System.in);
    private static final ColaTurnos cola = new ColaTurnos();

    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println("  SISTEMA DE TURNOS BANCARIOS (COLA FIFO)");
        System.out.println("==========================================");
        int opcion;
        do {
            System.out.println("\n1. Registrar cliente (encolar)");
            System.out.println("2. Atender cliente (desencolar)");
            System.out.println("3. Consultar próximo turno");
            System.out.println("4. Mostrar cola de espera");
            System.out.println("5. Buscar por ticket o documento");
            System.out.println("6. Cancelar turno por ticket");
            System.out.println("0. Salir");
            opcion = leerEntero("Opción: ");
            try {
                switch (opcion) {
                    case 1:
                        String ticket = leerTexto("Número de ticket: ");
                        String doc = leerTexto("Documento (8 dígitos): ");
                        String nombre = leerTexto("Nombre: ");
                        String tramite = leerTexto("Tipo de trámite: ");
                        int pri = leerEntero("Prioridad (1=Normal, 2=Preferencial): ");
                        String hora = leerTexto("Hora de llegada (ej. 09:30): ");
                        cola.encolar(new UsuarioBanco(ticket, doc, nombre, tramite, pri, hora));
                        System.out.println("Cliente registrado y encolado correctamente.");
                        break;
                    case 2:
                        System.out.println("\n[ATENCIÓN] Pasando a cliente:");
                        System.out.println(cola.desencolar());
                        break;
                    case 3:
                        System.out.println("\n[PRÓXIMO TURNO]: " + cola.consultarSiguiente());
                        break;
                    case 4:
                        cola.mostrarCola();
                        break;
                    case 5:
                        UsuarioBanco c = cola.buscarCliente(leerTexto("Ticket o documento: "));
                        System.out.println(c != null ? "\n[Encontrado]: " + c
                                : "No se encontró ningún registro con ese criterio.");
                        break;
                    case 6:
                        String t = leerTexto("Ticket a cancelar: ");
                        System.out.println(cola.eliminarPorTicket(t)
                                ? "El turno " + t + " fue cancelado."
                                : "No se encontró el ticket en la cola.");
                        break;
                    case 0:
                        System.out.println("Saliendo del sistema de turnos...");
                        break;
                    default:
                        System.out.println("Opción inválida.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("[Error] " + e.getMessage());
            }
        } while (opcion != 0);
        teclado.close();
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("El campo no puede estar vacío.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero válido.");
            }
        }
    }
}
