package DAO;

import Modelo.NodoOrden;
import Modelo.Orden;

public class ColaOrdenes {

    private NodoOrden frente;
    private NodoOrden fin;
    private int tamano;

    public ColaOrdenes() {
        frente = null;
        fin = null;
        tamano = 0;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public int getTamano() {
        return tamano;
    }

    public void encolar(Orden orden) {
        if (orden == null) {
            throw new IllegalArgumentException("La orden no puede ser null.");
        }
        if (buscarPorCodigo(orden.getCodigo()) != null) {
            throw new IllegalArgumentException("Ya existe una orden con ese código.");
        }
        NodoOrden nuevo = new NodoOrden(orden);
        if (estaVacia()) {
            frente = nuevo;
        } else {
            fin.setSiguiente(nuevo);
        }
        fin = nuevo;
        tamano++;
    }

    public Orden desencolar() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: no hay órdenes pendientes.");
        }
        NodoOrden viejo = frente;
        Orden despachada = viejo.getOrden();
        frente = frente.getSiguiente();
        viejo.setSiguiente(null);
        if (frente == null) {
            fin = null;
        }
        tamano--;
        return despachada;
    }

    public Orden consultarSiguiente() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: no hay órdenes pendientes.");
        }
        return frente.getOrden();
    }

    public void mostrarCola() {
        if (estaVacia()) {
            System.out.println("No hay órdenes pendientes en cocina.");
            return;
        }
        System.out.println("\n--- ÓRDENES PENDIENTES (" + tamano + ") ---");
        NodoOrden actual = frente;
        int posicion = 1;
        while (actual != null) {
            System.out.println(posicion++ + ". " + actual.getOrden());
            actual = actual.getSiguiente();
        }
        System.out.println("--------------------------------------------");
    }

    public Orden buscarPorCodigo(String codigo) {
        NodoOrden actual = frente;
        while (actual != null) {
            if (actual.getOrden().getCodigo().equalsIgnoreCase(codigo.trim())) {
                return actual.getOrden();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public void buscarPorCliente(String cliente) {
        if (cliente == null || cliente.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio.");
        }
        int encontrados = 0;
        NodoOrden actual = frente;
        while (actual != null) {
            Orden o = actual.getOrden();
            if (o.getCliente().toLowerCase().contains(cliente.trim().toLowerCase())) {
                System.out.println(o);
                encontrados++;
            }
            actual = actual.getSiguiente();
        }
        if (encontrados == 0) {
            System.out.println("No se encontraron órdenes para ese cliente.");
        }
    }

    public double calcularMontoTotal() {
        double total = 0;
        NodoOrden actual = frente;
        while (actual != null) {
            total += actual.getOrden().getMonto();
            actual = actual.getSiguiente();
        }
        return total;
    }

    public boolean eliminarPorCodigo(String codigo) {
        if (estaVacia()) {
            return false;
        }
        if (frente.getOrden().getCodigo().equalsIgnoreCase(codigo.trim())) {
            desencolar();
            return true;
        }
        NodoOrden anterior = frente;
        NodoOrden actual = frente.getSiguiente();
        while (actual != null
                && !actual.getOrden().getCodigo().equalsIgnoreCase(codigo.trim())) {
            anterior = actual;
            actual = actual.getSiguiente();
        }
        if (actual == null) {
            return false;
        }
        anterior.setSiguiente(actual.getSiguiente());
        if (actual == fin) {
            fin = anterior;
        }
        actual.setSiguiente(null);
        tamano--;
        return true;
    }
}
