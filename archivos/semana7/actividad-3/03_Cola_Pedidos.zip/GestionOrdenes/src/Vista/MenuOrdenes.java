package Vista;

import java.util.Scanner;
import DAO.ColaOrdenes;
import Modelo.Orden;

public class MenuOrdenes {

    private static final Scanner teclado = new Scanner(System.in);
    private static final ColaOrdenes cola = new ColaOrdenes();

    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println("  GESTIÓN DE ÓRDENES DE COCINA (COLA FIFO)");
        System.out.println("==========================================");
        int opcion;
        do {
            System.out.println("\n1. Registrar orden (encolar)");
            System.out.println("2. Despachar orden (desencolar)");
            System.out.println("3. Consultar siguiente orden");
            System.out.println("4. Mostrar cola de órdenes");
            System.out.println("5. Estado de la cola");
            System.out.println("6. Buscar (código o cliente)");
            System.out.println("7. Monto total acumulado");
            System.out.println("8. Cancelar orden por código");
            System.out.println("0. Salir");
            opcion = leerEntero("Opción: ");
            try {
                switch (opcion) {
                    case 1:
                        String codigo = leerTexto("Código: ");
                        String cliente = leerTexto("Nombre del cliente: ");
                        String platillo = leerTexto("Platillo: ");
                        double monto = leerDecimal("Monto (S/): ");
                        String tipo = leerTexto("Tipo de comida: ");
                        String hora = leerTexto("Hora de registro (ej. 13:45): ");
                        cola.encolar(new Orden(codigo, cliente, platillo, monto, tipo, hora));
                        System.out.println("[Éxito] Orden registrada correctamente.");
                        break;
                    case 2:
                        System.out.println("[DESPACHADO] " + cola.desencolar());
                        break;
                    case 3:
                        System.out.println("[SIGUIENTE EN COCINA] " + cola.consultarSiguiente());
                        break;
                    case 4:
                        cola.mostrarCola();
                        break;
                    case 5:
                        System.out.println(cola.estaVacia()
                                ? "Estado: la cola está vacía, no hay órdenes pendientes."
                                : "Estado: hay " + cola.getTamano() + " orden(es) pendiente(s).");
                        break;
                    case 6:
                        System.out.println("a) Por código   b) Por cliente");
                        String modo = leerTexto("Elija (a/b): ").toLowerCase();
                        if (modo.equals("a")) {
                            Orden o = cola.buscarPorCodigo(leerTexto("Código: "));
                            System.out.println(o != null ? "[Encontrado] " + o
                                    : "No existe una orden con ese código.");
                        } else if (modo.equals("b")) {
                            cola.buscarPorCliente(leerTexto("Cliente: "));
                        } else {
                            System.out.println("Opción de búsqueda inválida.");
                        }
                        break;
                    case 7:
                        System.out.printf("Monto total acumulado en cola: S/ %.2f (%d órdenes)%n",
                                cola.calcularMontoTotal(), cola.getTamano());
                        break;
                    case 8:
                        String cod = leerTexto("Código de la orden a cancelar: ");
                        System.out.println(cola.eliminarPorCodigo(cod)
                                ? "[Éxito] Orden " + cod + " cancelada."
                                : "[Error] No se encontró la orden en la cola.");
                        break;
                    case 0:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("[Error] Opción inválida.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("[Error] " + e.getMessage());
            }
        } while (opcion != 0);
        teclado.close();
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("El campo no puede estar vacío.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("[Error] Ingrese un número entero válido.");
            }
        }
    }

    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                double v = Double.parseDouble(teclado.nextLine().trim().replace(',', '.'));
                if (Double.isFinite(v)) {
                    return v;
                }
            } catch (NumberFormatException e) {
                // se repite
            }
            System.out.println("[Error] Ingrese un número decimal válido.");
        }
    }
}
