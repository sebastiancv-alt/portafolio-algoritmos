package Modelo;

public class Orden {

    private String codigo;
    private String cliente;
    private String platillo;
    private double monto;
    private String tipo;
    private String hora;

    public Orden(String codigo, String cliente, String platillo,
            double monto, String tipo, String hora) {
        setCodigo(codigo);
        setCliente(cliente);
        setPlatillo(platillo);
        setMonto(monto);
        setTipo(tipo);
        setHora(hora);
    }

    private static String requerido(String valor, String campo) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException("El campo " + campo + " es obligatorio.");
        }
        return valor.trim();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = requerido(codigo, "código");
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = requerido(cliente, "nombre del cliente");
    }

    public String getPlatillo() {
        return platillo;
    }

    public void setPlatillo(String platillo) {
        this.platillo = requerido(platillo, "descripción del platillo");
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        if (!Double.isFinite(monto) || monto <= 0) {
            throw new IllegalArgumentException("El monto total debe ser mayor que cero.");
        }
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = requerido(tipo, "tipo de comida");
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = requerido(hora, "hora de registro");
    }

    @Override
    public String toString() {
        return "Orden: " + codigo
                + " | Cliente: " + cliente
                + " | Platillo: " + platillo
                + " | Tipo: " + tipo
                + String.format(" | Monto: S/ %.2f", monto)
                + " | Hora: " + hora;
    }
}
