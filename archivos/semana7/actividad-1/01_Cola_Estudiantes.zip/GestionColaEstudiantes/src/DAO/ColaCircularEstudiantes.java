package DAO;

import Modelo.Estudiante;

public class ColaCircularEstudiantes {

    private final Estudiante[] datos;
    private int frente;
    private int finalCola;
    private int cantidad;

    public ColaCircularEstudiantes(int capacidad) {
        if (capacidad <= 0) {
            throw new IllegalArgumentException("La capacidad debe ser mayor que cero.");
        }
        datos = new Estudiante[capacidad];
        frente = 0;
        finalCola = -1;
        cantidad = 0;
    }

    public boolean estaVacia() {
        return cantidad == 0;
    }

    public boolean estaLlena() {
        return cantidad == datos.length;
    }

    public int tamanio() {
        return cantidad;
    }

    public int capacidad() {
        return datos.length;
    }

    public void encolar(Estudiante estudiante) {
        if (estudiante == null) {
            throw new IllegalArgumentException("El estudiante no puede ser null.");
        }
        if (estaLlena()) {
            throw new IllegalStateException("Overflow: la cola está llena.");
        }
        finalCola = (finalCola + 1) % datos.length;
        datos[finalCola] = estudiante;
        cantidad++;
    }

    public Estudiante desencolar() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        Estudiante e = datos[frente];
        datos[frente] = null;
        frente = (frente + 1) % datos.length;
        cantidad--;
        if (cantidad == 0) {
            frente = 0;
            finalCola = -1;
        }
        return e;
    }

    public Estudiante consultarFrente() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        return datos[frente];
    }

    public void listarTodos() {
        if (estaVacia()) {
            System.out.println("No hay estudiantes registrados.");
            return;
        }
        System.out.println("\n--- ESTUDIANTES EN LA COLA ---");
        for (int i = 0; i < cantidad; i++) {
            System.out.println((i + 1) + ". " + datos[(frente + i) % datos.length]);
        }
    }

    public Estudiante buscarPorId(String id) {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID a buscar es obligatorio.");
        }
        for (int i = 0; i < cantidad; i++) {
            Estudiante e = datos[(frente + i) % datos.length];
            if (e.getId().equalsIgnoreCase(id.trim())) {
                return e;
            }
        }
        return null;
    }

    public double calcularPromedioGeneral() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        double suma = 0;
        for (int i = 0; i < cantidad; i++) {
            suma += datos[(frente + i) % datos.length].getNotaFinal();
        }
        return suma / cantidad;
    }

    public int filtrarPorRendimiento(double umbral) {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        System.out.println("\n--- ESTUDIANTES CON PROMEDIO >= " + umbral + " ---");
        int encontrados = 0;
        for (int i = 0; i < cantidad; i++) {
            Estudiante e = datos[(frente + i) % datos.length];
            if (e.getNotaFinal() >= umbral) {
                System.out.println((++encontrados) + ". " + e);
            }
        }
        if (encontrados == 0) {
            System.out.println("Ningún estudiante alcanza ese umbral.");
        }
        return encontrados;
    }

    public Estudiante[] obtenerMayorYMenor() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        Estudiante mayor = datos[frente];
        Estudiante menor = datos[frente];
        for (int i = 1; i < cantidad; i++) {
            Estudiante e = datos[(frente + i) % datos.length];
            if (e.getNotaFinal() > mayor.getNotaFinal()) {
                mayor = e;
            }
            if (e.getNotaFinal() < menor.getNotaFinal()) {
                menor = e;
            }
        }
        return new Estudiante[]{mayor, menor};
    }

    public void invertir() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        Estudiante[] pila = new Estudiante[cantidad];
        int tope = -1;
        int total = cantidad;
        while (!estaVacia()) {
            pila[++tope] = desencolar();
        }
        for (int i = 0; i < total; i++) {
            encolar(pila[tope--]);
        }
    }

    public Estudiante eliminarPorId(String id) {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID es obligatorio.");
        }
        int posicion = -1;
        for (int i = 0; i < cantidad; i++) {
            if (datos[(frente + i) % datos.length].getId()
                    .equalsIgnoreCase(id.trim())) {
                posicion = i;
                break;
            }
        }
        if (posicion == -1) {
            return null;
        }
        Estudiante eliminado = datos[(frente + posicion) % datos.length];
        for (int i = posicion; i < cantidad - 1; i++) {
            datos[(frente + i) % datos.length]
                    = datos[(frente + i + 1) % datos.length];
        }
        datos[(frente + cantidad - 1) % datos.length] = null;
        cantidad--;
        if (cantidad == 0) {
            frente = 0;
            finalCola = -1;
        } else {
            finalCola = (frente + cantidad - 1) % datos.length;
        }
        return eliminado;
    }
}
