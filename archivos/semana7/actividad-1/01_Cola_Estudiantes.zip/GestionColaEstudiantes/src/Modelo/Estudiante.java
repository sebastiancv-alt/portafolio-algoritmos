package Modelo;

public class Estudiante {

    private String id;
    private String nombreCompleto;
    private int anios;
    private double notaFinal;

    public Estudiante() {
    }

    public Estudiante(String id, String nombreCompleto, int anios, double notaFinal) {
        setId(id);
        setNombreCompleto(nombreCompleto);
        setAnios(anios);
        setNotaFinal(notaFinal);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID es obligatorio.");
        }
        this.id = id.trim();
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        if (nombreCompleto == null || nombreCompleto.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio.");
        }
        this.nombreCompleto = nombreCompleto.trim();
    }

    public int getAnios() {
        return anios;
    }

    public void setAnios(int anios) {
        if (anios <= 0 || anios > 120) {
            throw new IllegalArgumentException("La edad debe estar entre 1 y 120.");
        }
        this.anios = anios;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        if (!Double.isFinite(notaFinal) || notaFinal < 0 || notaFinal > 20) {
            throw new IllegalArgumentException("El promedio debe estar entre 0 y 20.");
        }
        this.notaFinal = notaFinal;
    }

    @Override
    public String toString() {
        return "ID: " + id
                + " | Nombre: " + nombreCompleto
                + " | Edad: " + anios
                + " | Promedio: " + notaFinal;
    }
}
