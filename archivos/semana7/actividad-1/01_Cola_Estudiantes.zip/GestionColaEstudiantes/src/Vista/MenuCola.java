package Vista;

import java.util.Scanner;
import DAO.ColaCircularEstudiantes;
import Modelo.Estudiante;

public class MenuCola {

    private static final Scanner teclado = new Scanner(System.in);
    private static ColaCircularEstudiantes cola;

    public static void main(String[] args) {
        System.out.println("==================================");
        System.out.println(" GESTIÓN DE ESTUDIANTES CON COLA");
        System.out.println(" Estructura de datos: COLA FIFO");
        System.out.println("==================================");

        int capacidad;
        while (true) {
            capacidad = leerEntero("Ingrese la capacidad de la cola: ");
            if (capacidad > 0) {
                break;
            }
            System.out.println("La capacidad debe ser mayor que cero.");
        }
        cola = new ColaCircularEstudiantes(capacidad);
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1:
                        registrarEstudiante();
                        break;
                    case 2:
                        Estudiante retirado = cola.desencolar();
                        System.out.println("Estudiante retirado de la cola:");
                        System.out.println(retirado);
                        break;
                    case 3:
                        System.out.println("Estudiante ubicado en el frente:");
                        System.out.println(cola.consultarFrente());
                        break;
                    case 4:
                        cola.listarTodos();
                        break;
                    case 5:
                        System.out.println(cola.estaVacia()
                                ? "La cola está vacía."
                                : "La cola contiene estudiantes.");
                        break;
                    case 6:
                        System.out.println(cola.estaLlena()
                                ? "La cola está llena."
                                : "La cola tiene espacio disponible.");
                        break;
                    case 7:
                        System.out.println("Estudiantes registrados: "
                                + cola.tamanio() + " de " + cola.capacidad());
                        break;
                    case 8:
                        buscarEstudiante();
                        break;
                    case 9:
                        System.out.printf("Promedio general del grupo: %.2f%n",
                                cola.calcularPromedioGeneral());
                        break;
                    case 10:
                        double umbral = leerDecimal("Ingrese el umbral de nota: ");
                        cola.filtrarPorRendimiento(umbral);
                        break;
                    case 11:
                        Estudiante[] extremos = cola.obtenerMayorYMenor();
                        System.out.println("Mayor promedio: " + extremos[0]);
                        System.out.println("Menor promedio: " + extremos[1]);
                        break;
                    case 12:
                        cola.invertir();
                        System.out.println("Cola invertida correctamente.");
                        cola.listarTodos();
                        break;
                    case 13:
                        eliminarPorId();
                        break;
                    case 0:
                        System.out.println("Fin del programa.");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 0);
        teclado.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n====================================");
        System.out.println("1. Registrar estudiante (encolar)");
        System.out.println("2. Retirar del frente (desencolar)");
        System.out.println("3. Consultar frente");
        System.out.println("4. Listar todos");
        System.out.println("5. ¿Está vacía?");
        System.out.println("6. ¿Está llena?");
        System.out.println("7. Tamaño y capacidad");
        System.out.println("8. Buscar por ID");
        System.out.println("9. Promedio general");
        System.out.println("10. Filtrar por rendimiento");
        System.out.println("11. Mayor y menor promedio");
        System.out.println("12. Invertir cola");
        System.out.println("13. Eliminar por ID");
        System.out.println("0. Salir");
        System.out.println("====================================");
    }

    private static void registrarEstudiante() {
        System.out.println("\n--- REGISTRAR ESTUDIANTE ---");
        if (cola.estaLlena()) {
            throw new IllegalStateException("Overflow: la cola está llena.");
        }
        String id = leerTexto("ID: ");
        String nombre = leerTexto("Nombre completo: ");
        int anios = leerEntero("Edad: ");
        double nota = leerDecimal("Promedio (0-20): ");
        cola.encolar(new Estudiante(id, nombre, anios, nota));
        System.out.println("Estudiante registrado correctamente.");
    }

    private static void buscarEstudiante() {
        String id = leerTexto("ID a buscar: ");
        Estudiante e = cola.buscarPorId(id);
        System.out.println(e != null ? "Estudiante encontrado:\n" + e
                : "No existe un estudiante con ese ID.");
    }

    private static void eliminarPorId() {
        String id = leerTexto("ID del estudiante a eliminar: ");
        Estudiante e = cola.eliminarPorId(id);
        System.out.println(e != null ? "Estudiante eliminado:\n" + e
                : "No existe un estudiante con ese ID.");
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("El campo no puede estar vacío.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero válido.");
            }
        }
    }

    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim().replace(',', '.');
            try {
                double valor = Double.parseDouble(entrada);
                if (Double.isFinite(valor)) {
                    return valor;
                }
                System.out.println("Ingrese un número decimal finito.");
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número decimal válido.");
            }
        }
    }
}
