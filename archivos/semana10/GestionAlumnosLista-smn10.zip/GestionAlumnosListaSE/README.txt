GestionAlumnosListaSE - Sistema de gestion de alumnos con LISTA SIMPLEMENTE ENLAZADA
(Algoritmos y Estructura de Datos - UPLA)

COMO ABRIR EN NETBEANS
  File > Open Project > seleccionar la carpeta GestionAlumnosListaSE > clic derecho > Run (F6).
  Clase principal: Vista.Principal
  Pruebas: ejecutar Pruebas/SuitePruebasLista.java (25 casos).

ESTRUCTURA
  Modelo/Alumno.java           codigo (unico), nombre y promedio (0 a 20).
  Modelo/Nodo.java             nodo: un Alumno y la referencia al siguiente.
  DAO/ListaAlumnosSE.java      operaciones de la lista (p = primer nodo, tope = cantidad).
  Vista/MenuListaVista.java    menu de 13 opciones por consola.
  Vista/Principal.java         inicia la aplicacion.
  Pruebas/SuitePruebasLista.java  casos de prueba.

MENU -> METODO DEL DAO
  1 insertarInicio   2 insertarFinal   3 insertarPosicion   4 insertarReferencia
  5 eliminar         6 buscar          7 mostrar            8 ordenarPorCodigo
  9 ordenarPorPromedio  10 intercambiar  11 cantidad  12 modificar  13 estaVacia

NOTAS
  - El codigo del alumno es unico (no se permiten repetidos).
  - Ordenar por codigo: menor a mayor. Ordenar por promedio: mayor a menor.
  - Ordenar e intercambiar reenlazan los nodos (no copian los datos).
