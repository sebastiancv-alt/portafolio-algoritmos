package Modelo;

/**
 * Datos de un alumno: codigo unico, nombre y promedio (escala 0 a 20).
 */
public class Alumno {

    private final int codigo;
    private String nombre;
    private double promedio;

    public Alumno(int codigo, String nombre, double promedio) {
        if (codigo <= 0) {
            throw new IllegalArgumentException("El codigo debe ser un entero positivo.");
        }
        validarNombre(nombre);
        validarPromedio(promedio);
        this.codigo = codigo;
        this.nombre = nombre.trim();
        this.promedio = promedio;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre.trim();
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        validarPromedio(promedio);
        this.promedio = promedio;
    }

    private static void validarNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio.");
        }
    }

    private static void validarPromedio(double promedio) {
        if (promedio < 0 || promedio > 20) {
            throw new IllegalArgumentException("El promedio debe estar entre 0 y 20.");
        }
    }

    @Override
    public String toString() {
        return codigo + " - " + nombre + " (promedio " + String.format(java.util.Locale.US, "%.2f", promedio) + ")";
    }
}
