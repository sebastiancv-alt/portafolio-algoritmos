package DAO;

import Modelo.Alumno;
import Modelo.Nodo;
import java.util.Comparator;

/**
 * Lista simplemente enlazada de alumnos.
 * p apunta al primer nodo; tope guarda la cantidad de alumnos.
 * El codigo de cada alumno es unico dentro de la lista.
 */
public class ListaAlumnosSE {

    private Nodo p;
    private int tope;

    public ListaAlumnosSE() {
        p = null;
        tope = 0;
    }

    // ---------------------------------------------------------
    // 13. Verificar si la lista esta vacia
    // ---------------------------------------------------------
    public boolean estaVacia() {
        return p == null;
    }

    // ---------------------------------------------------------
    // 11. Cantidad de alumnos
    // ---------------------------------------------------------
    public int cantidad() {
        return tope;
    }

    // ---------------------------------------------------------
    // 1. Insertar al inicio
    // ---------------------------------------------------------
    public void insertarInicio(Alumno a) {
        verificarNoExiste(a.getCodigo());
        Nodo nuevo = new Nodo(a);
        nuevo.setSig(p);
        p = nuevo;
        tope++;
    }

    // ---------------------------------------------------------
    // 2. Insertar al final
    // ---------------------------------------------------------
    public void insertarFinal(Alumno a) {
        verificarNoExiste(a.getCodigo());
        Nodo nuevo = new Nodo(a);
        if (estaVacia()) {
            p = nuevo;
        } else {
            Nodo temp = p;
            while (temp.getSig() != null) {
                temp = temp.getSig();
            }
            temp.setSig(nuevo);
        }
        tope++;
    }

    // ---------------------------------------------------------
    // 3. Insertar en la posicion X (la primera posicion es 1)
    // ---------------------------------------------------------
    public void insertarPosicion(int pos, Alumno a) {
        if (pos < 1 || pos > tope + 1) {
            throw new IllegalArgumentException("Posicion no valida (1 a " + (tope + 1) + ").");
        }
        if (pos == 1) {
            insertarInicio(a);
            return;
        }
        verificarNoExiste(a.getCodigo());
        Nodo anterior = p;
        for (int i = 1; i < pos - 1; i++) {
            anterior = anterior.getSig();
        }
        Nodo nuevo = new Nodo(a);
        nuevo.setSig(anterior.getSig());
        anterior.setSig(nuevo);
        tope++;
    }

    // ---------------------------------------------------------
    // 4. Insertar por referencia: despues del alumno con el codigo indicado
    // ---------------------------------------------------------
    public void insertarReferencia(int codigoReferencia, Alumno a) {
        Nodo ref = buscarNodo(codigoReferencia);
        if (ref == null) {
            throw new IllegalArgumentException("No existe el alumno de referencia " + codigoReferencia + ".");
        }
        verificarNoExiste(a.getCodigo());
        Nodo nuevo = new Nodo(a);
        nuevo.setSig(ref.getSig());
        ref.setSig(nuevo);
        tope++;
    }

    // ---------------------------------------------------------
    // 5. Eliminar por codigo
    // ---------------------------------------------------------
    public Alumno eliminar(int codigo) {
        if (estaVacia()) {
            throw new IllegalStateException("La lista esta vacia.");
        }
        Nodo eliminado;
        if (p.getDato().getCodigo() == codigo) {
            eliminado = p;
            p = p.getSig();
        } else {
            Nodo anterior = p;
            while (anterior.getSig() != null && anterior.getSig().getDato().getCodigo() != codigo) {
                anterior = anterior.getSig();
            }
            if (anterior.getSig() == null) {
                throw new IllegalArgumentException("No existe el alumno con codigo " + codigo + ".");
            }
            eliminado = anterior.getSig();
            anterior.setSig(eliminado.getSig());
        }
        tope--;
        return eliminado.getDato();
    }

    // ---------------------------------------------------------
    // 6. Buscar por codigo (devuelve el alumno o null)
    // ---------------------------------------------------------
    public Alumno buscar(int codigo) {
        Nodo n = buscarNodo(codigo);
        return (n == null) ? null : n.getDato();
    }

    /** Posicion (desde 1) del alumno, o 0 si no existe. */
    public int posicionDe(int codigo) {
        int pos = 1;
        for (Nodo t = p; t != null; t = t.getSig(), pos++) {
            if (t.getDato().getCodigo() == codigo) {
                return pos;
            }
        }
        return 0;
    }

    // ---------------------------------------------------------
    // 7. Mostrar todos los alumnos
    // ---------------------------------------------------------
    public String mostrar() {
        StringBuilder sb = new StringBuilder("p -> ");
        for (Nodo t = p; t != null; t = t.getSig()) {
            sb.append("[").append(t.getDato().getCodigo()).append(" ")
              .append(t.getDato().getNombre()).append(" ")
              .append(String.format(java.util.Locale.US, "%.2f", t.getDato().getPromedio()))
              .append("] -> ");
        }
        return sb.append("null").toString();
    }

    // ---------------------------------------------------------
    // 8. Ordenar por codigo (ascendente)
    // ---------------------------------------------------------
    public void ordenarPorCodigo() {
        ordenar(new Comparator<Alumno>() {
            @Override
            public int compare(Alumno x, Alumno y) {
                return Integer.compare(x.getCodigo(), y.getCodigo());
            }
        });
    }

    // ---------------------------------------------------------
    // 9. Ordenar por promedio (de mayor a menor)
    // ---------------------------------------------------------
    public void ordenarPorPromedio() {
        ordenar(new Comparator<Alumno>() {
            @Override
            public int compare(Alumno x, Alumno y) {
                return Double.compare(y.getPromedio(), x.getPromedio());
            }
        });
    }

    /**
     * Ordenamiento por insercion enlazando nodos (no copia datos).
     * Es estable: los alumnos con igual criterio conservan su orden.
     */
    private void ordenar(Comparator<Alumno> criterio) {
        if (tope < 2) {
            return;
        }
        Nodo ordenada = null;
        Nodo actual = p;
        while (actual != null) {
            Nodo siguiente = actual.getSig();
            if (ordenada == null || criterio.compare(actual.getDato(), ordenada.getDato()) < 0) {
                actual.setSig(ordenada);
                ordenada = actual;
            } else {
                Nodo t = ordenada;
                while (t.getSig() != null
                        && criterio.compare(t.getSig().getDato(), actual.getDato()) <= 0) {
                    t = t.getSig();
                }
                actual.setSig(t.getSig());
                t.setSig(actual);
            }
            actual = siguiente;
        }
        p = ordenada;
    }

    // ---------------------------------------------------------
    // 10. Intercambiar dos alumnos (se reenlazan los nodos)
    // ---------------------------------------------------------
    public void intercambiar(int codigo1, int codigo2) {
        if (codigo1 == codigo2) {
            throw new IllegalArgumentException("Los codigos son iguales, no hay cambios.");
        }
        Nodo pa = null, a = p;
        while (a != null && a.getDato().getCodigo() != codigo1) {
            pa = a;
            a = a.getSig();
        }
        Nodo pb = null, b = p;
        while (b != null && b.getDato().getCodigo() != codigo2) {
            pb = b;
            b = b.getSig();
        }
        if (a == null || b == null) {
            throw new IllegalArgumentException("Alguno de los codigos no existe en la lista.");
        }
        // Si b esta justo antes de a, se invierten los papeles
        if (b.getSig() == a) {
            Nodo t = a; a = b; b = t;
            t = pa; pa = pb; pb = t;
        }
        if (a.getSig() == b) {              // nodos contiguos
            if (pa != null) {
                pa.setSig(b);
            } else {
                p = b;
            }
            a.setSig(b.getSig());
            b.setSig(a);
        } else {                            // nodos separados
            if (pa != null) {
                pa.setSig(b);
            } else {
                p = b;
            }
            if (pb != null) {
                pb.setSig(a);
            } else {
                p = a;
            }
            Nodo t = a.getSig();
            a.setSig(b.getSig());
            b.setSig(t);
        }
    }

    // ---------------------------------------------------------
    // 12. Modificar los datos de un alumno (el codigo no cambia)
    // ---------------------------------------------------------
    public void modificar(int codigo, String nuevoNombre, double nuevoPromedio) {
        Nodo n = buscarNodo(codigo);
        if (n == null) {
            throw new IllegalArgumentException("No existe el alumno con codigo " + codigo + ".");
        }
        Alumno a = n.getDato();
        // Se validan ambos datos antes de cambiar cualquiera
        new Alumno(a.getCodigo(), nuevoNombre, nuevoPromedio);
        a.setNombre(nuevoNombre);
        a.setPromedio(nuevoPromedio);
    }

    // ---------------------------------------------------------
    // Apoyo
    // ---------------------------------------------------------
    private Nodo buscarNodo(int codigo) {
        Nodo t = p;
        while (t != null && t.getDato().getCodigo() != codigo) {
            t = t.getSig();
        }
        return t;
    }

    private void verificarNoExiste(int codigo) {
        if (buscarNodo(codigo) != null) {
            throw new IllegalArgumentException("Ya existe un alumno con codigo " + codigo + ".");
        }
    }
}
