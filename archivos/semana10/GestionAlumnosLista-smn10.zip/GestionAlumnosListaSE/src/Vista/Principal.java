package Vista;

public class Principal {

    public static void main(String[] args) {
        MenuListaVista menu = new MenuListaVista();
        menu.iniciar();
    }
}
