package Vista;

import DAO.ListaAlumnosSE;
import Modelo.Alumno;
import java.util.Scanner;

/**
 * Menu de consola del sistema de gestion de alumnos (lista simplemente enlazada).
 */
public class MenuListaVista {

    private static final String LINEA = "==================================================";

    private final Scanner teclado = new Scanner(System.in);
    private final ListaAlumnosSE lista = new ListaAlumnosSE();

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerOpcion();
            try {
                ejecutar(opcion);
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IllegalStateException e) {
                System.out.println("Aviso: " + e.getMessage());
            }
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n" + LINEA);
        System.out.println("      SISTEMA DE GESTION DE ALUMNOS CON LISTA ENLAZADA CON LISTA ENLAZADA");
        System.out.println("      Estructura: Lista Simplemente Enlazada");
        System.out.println(LINEA);
        System.out.println(" 1. Insertar alumno al inicio de la lista de la lista");
        System.out.println(" 2. Insertar alumno al final de la lista de la lista");
        System.out.println(" 3. Insertar alumno en una posicion especifica");
        System.out.println(" 4. Insertar alumno despues de un codigo de referencia");
        System.out.println(" 5. Eliminar alumno por codigo");
        System.out.println(" 6. Buscar alumno por codigo");
        System.out.println(" 7. Mostrar lista completa de alumnos");
        System.out.println(" 8. Ordenar alumnos por codigo");
        System.out.println(" 9. Ordenar alumnos por promedio");
        System.out.println("10. Intercambiar posiciones de dos alumnos");
        System.out.println("11. Mostrar cantidad de alumnos");
        System.out.println("12. Modificar datos de un alumno");
        System.out.println("13. Verificar si la lista se encuentra vacia");
        System.out.println(" 0. Salir del sistema");
        System.out.println(LINEA);
        System.out.print("Seleccione una opcion: ");
    }

    private void ejecutar(int opcion) {
        switch (opcion) {
            case 1:
                lista.insertarInicio(leerAlumno());
                System.out.println("Alumno insertado al inicio.");
                break;
            case 2:
                lista.insertarFinal(leerAlumno());
                System.out.println("Alumno insertado al final.");
                break;
            case 3:
                int pos = leerEntero("Posicion (1 a " + (lista.cantidad() + 1) + "): ");
                lista.insertarPosicion(pos, leerAlumno());
                System.out.println("Alumno insertado en la posicion " + pos + ".");
                break;
            case 4:
                if (lista.estaVacia()) {
                    throw new IllegalStateException("La lista esta vacia.");
                }
                int ref = leerEntero("Codigo del alumno de referencia (se insertara despues de el): ");
                lista.insertarReferencia(ref, leerAlumno());
                System.out.println("Alumno insertado despues del codigo " + ref + ".");
                break;
            case 5:
                Alumno eliminado = lista.eliminar(leerEntero("Codigo del alumno a eliminar: "));
                System.out.println("Eliminado: " + eliminado);
                break;
            case 6:
                buscar();
                break;
            case 7:
                mostrar();
                break;
            case 8:
                lista.ordenarPorCodigo();
                System.out.println("Alumnos ordenados por codigo (menor a mayor).");
                break;
            case 9:
                lista.ordenarPorPromedio();
                System.out.println("Alumnos ordenados por promedio (mayor a menor).");
                break;
            case 10:
                int c1 = leerEntero("Codigo del primer alumno: ");
                int c2 = leerEntero("Codigo del segundo alumno: ");
                lista.intercambiar(c1, c2);
                System.out.println("Se intercambiaron los alumnos " + c1 + " y " + c2 + ".");
                break;
            case 11:
                System.out.println("Cantidad de alumnos: " + lista.cantidad());
                break;
            case 12:
                modificar();
                break;
            case 13:
                System.out.println(lista.estaVacia() ? "La lista esta vacia." : "La lista NO esta vacia.");
                break;
            case 0:
                System.out.println("Fin del programa.");
                break;
            default:
                System.out.println("Opcion no valida.");
        }
    }

    private void buscar() {
        int codigo = leerEntero("Codigo a buscar: ");
        Alumno a = lista.buscar(codigo);
        if (a == null) {
            System.out.println("No existe el alumno con codigo " + codigo + ".");
        } else {
            System.out.println("Encontrado en la posicion " + lista.posicionDe(codigo) + ": " + a);
        }
    }

    private void mostrar() {
        if (lista.estaVacia()) {
            System.out.println("La lista esta vacia.");
        } else {
            System.out.println(lista.mostrar());
        }
    }

    private void modificar() {
        if (lista.estaVacia()) {
            throw new IllegalStateException("La lista esta vacia.");
        }
        int codigo = leerEntero("Codigo del alumno a modificar: ");
        if (lista.buscar(codigo) == null) {
            throw new IllegalArgumentException("No existe el alumno con codigo " + codigo + ".");
        }
        String nombre = leerTexto("Nuevo nombre: ");
        double promedio = leerDecimal("Nuevo promedio (0 a 20): ");
        lista.modificar(codigo, nombre, promedio);
        System.out.println("Datos modificados: " + lista.buscar(codigo));
    }

    // ---------------------------------------------------------
    // Lectura de datos
    // ---------------------------------------------------------
    private Alumno leerAlumno() {
        int codigo = leerEntero("Codigo: ");
        String nombre = leerTexto("Nombre: ");
        double promedio = leerDecimal("Promedio (0 a 20): ");
        return new Alumno(codigo, nombre, promedio);
    }

    private int leerOpcion() {
        if (!teclado.hasNextLine()) {
            return 0;
        }
        try {
            return Integer.parseInt(teclado.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine();
    }

    private int leerEntero(String mensaje) {
        try {
            return Integer.parseInt(leerTexto(mensaje).trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Debe ingresar un numero entero.");
        }
    }

    private double leerDecimal(String mensaje) {
        try {
            return Double.parseDouble(leerTexto(mensaje).trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Debe ingresar un numero valido.");
        }
    }
}
