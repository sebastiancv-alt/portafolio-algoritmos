package Pruebas;

import DAO.ListaAlumnosSE;
import Modelo.Alumno;

/** Casos de prueba ejecutables de los 13 metodos de la lista. */
public class SuitePruebasLista {

    private static int ok = 0, total = 0;

    private static void verificar(String desc, boolean cond) {
        total++;
        if (cond) {
            ok++;
        }
        System.out.println((cond ? "[OK]    " : "[FALLO] ") + desc);
    }

    private static boolean falla(Runnable r) {
        try {
            r.run();
            return false;
        } catch (RuntimeException e) {
            return true;
        }
    }

    private static Alumno al(int c, String n, double p) {
        return new Alumno(c, n, p);
    }

    private static ListaAlumnosSE base() {
        ListaAlumnosSE l = new ListaAlumnosSE();
        l.insertarFinal(al(103, "Lucia", 14.5));
        l.insertarFinal(al(101, "Pedro", 17.0));
        l.insertarFinal(al(102, "Sofia", 12.25));
        return l;
    }

    private static String codigos(ListaAlumnosSE l) {
        return l.mostrar().replaceAll("\\[(\\d+) [^\\]]*\\]", "$1").replace("p -> ", "").replace(" -> ", ",");
    }

    public static void main(String[] args) {
        System.out.println("--- CASOS DE PRUEBA: LISTA SIMPLEMENTE ENLAZADA DE ALUMNOS ---");
        ListaAlumnosSE l = new ListaAlumnosSE();
        verificar("13. Lista nueva esta vacia", l.estaVacia());
        verificar("11. Cantidad inicial = 0", l.cantidad() == 0);

        l.insertarInicio(al(2, "B", 10));
        l.insertarInicio(al(1, "A", 15));
        verificar("1. Insertar al inicio: 1,2,null", codigos(l).equals("1,2,null"));
        l.insertarFinal(al(3, "C", 18));
        verificar("2. Insertar al final: 1,2,3,null", codigos(l).equals("1,2,3,null"));
        l.insertarPosicion(2, al(9, "X", 11));
        verificar("3. Insertar en posicion 2: 1,9,2,3,null", codigos(l).equals("1,9,2,3,null"));
        l.insertarReferencia(2, al(7, "R", 13));
        verificar("4. Insertar despues del codigo 2: 1,9,2,7,3,null", codigos(l).equals("1,9,2,7,3,null"));
        verificar("11. Cantidad = 5", l.cantidad() == 5);
        verificar("13. Con datos NO esta vacia", !l.estaVacia());

        verificar("6. Buscar codigo 7 -> posicion 4", l.buscar(7) != null && l.posicionDe(7) == 4);
        verificar("6. Buscar codigo 55 -> no existe", l.buscar(55) == null);

        l.eliminar(1);
        verificar("5. Eliminar el primero: 9,2,7,3,null", codigos(l).equals("9,2,7,3,null"));
        l.eliminar(3);
        verificar("5. Eliminar el ultimo: 9,2,7,null", codigos(l).equals("9,2,7,null"));
        l.eliminar(2);
        verificar("5. Eliminar uno del medio: 9,7,null", codigos(l).equals("9,7,null"));

        ListaAlumnosSE o = base();
        o.ordenarPorCodigo();
        verificar("8. Ordenar por codigo: 101,102,103", codigos(o).equals("101,102,103,null"));
        o.ordenarPorPromedio();
        verificar("9. Ordenar por promedio (mayor a menor): 101,103,102", codigos(o).equals("101,103,102,null"));

        ListaAlumnosSE x = base();
        x.intercambiar(103, 102);
        verificar("10. Intercambiar extremos: 102,101,103", codigos(x).equals("102,101,103,null"));
        x = base();
        x.intercambiar(103, 101);
        verificar("10. Intercambiar contiguos: 101,103,102", codigos(x).equals("101,103,102,null"));
        x = base();
        x.intercambiar(102, 101);
        verificar("10. Intercambiar contiguos al reves: 103,102,101", codigos(x).equals("103,102,101,null"));

        ListaAlumnosSE m = base();
        m.modificar(101, "Pedro Maria", 19.5);
        verificar("12. Modificar datos del codigo 101",
                m.buscar(101).getNombre().equals("Pedro Maria") && m.buscar(101).getPromedio() == 19.5);

        final ListaAlumnosSE v = new ListaAlumnosSE();
        verificar("Rechaza eliminar en lista vacia", falla(new Runnable() { public void run() { v.eliminar(1); } }));
        final ListaAlumnosSE b = base();
        verificar("Rechaza codigo duplicado", falla(new Runnable() { public void run() { b.insertarFinal(al(101, "Dup", 10)); } }));
        verificar("Rechaza posicion fuera de rango", falla(new Runnable() { public void run() { b.insertarPosicion(9, al(5, "P", 10)); } }));
        verificar("Rechaza referencia inexistente", falla(new Runnable() { public void run() { b.insertarReferencia(999, al(5, "P", 10)); } }));
        verificar("Rechaza promedio mayor a 20", falla(new Runnable() { public void run() { al(6, "Z", 25); } }));
        verificar("Rechaza intercambiar un codigo inexistente", falla(new Runnable() { public void run() { b.intercambiar(101, 999); } }));

        System.out.println("Resultado: " + ok + " correctas, " + (total - ok) + " fallidas.");
    }
}
