package DAO;

import Modelo.Estudiante;
import Modelo.NodoEstudiante;

public class ListaDobleEstudiantes {

    private NodoEstudiante cabeza;
    private NodoEstudiante cola;
    private int tamaño;

    // Constructor
    public ListaDobleEstudiantes() {
        cabeza = null;
        cola = null;
        tamaño = 0;
    }

    // =====================================
    // 1. INSERTAR AL INICIO
    // =====================================
    public void insertarInicio(Estudiante dato) {

        NodoEstudiante nuevo = new NodoEstudiante(dato);

        if (cabeza == null) {

            cabeza = nuevo;
            cola = nuevo;

        } else {

            nuevo.siguiente = cabeza;
            cabeza.anterior = nuevo;
            cabeza = nuevo;
        }

        tamaño++;
    }

    // =====================================
    // 2. INSERTAR AL FINAL
    // =====================================
    public void insertarFinal(Estudiante dato) {

        NodoEstudiante nuevo = new NodoEstudiante(dato);

        if (cola == null) {

            cabeza = nuevo;
            cola = nuevo;

        } else {

            nuevo.anterior = cola;
            cola.siguiente = nuevo;
            cola = nuevo;
        }

        tamaño++;
    }

    // =====================================
    // 3. OBTENER NODO POR POSICION
    // =====================================
    private NodoEstudiante obtenerNodoEstudiante(int indice) {

        if (indice < 0 || indice >= tamaño) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida");
        }

        NodoEstudiante actual;

        if (indice < tamaño / 2) {

            actual = cabeza;

            for (int i = 0; i < indice; i++) {
                actual = actual.siguiente;
            }

        } else {

            actual = cola;

            for (int i = tamaño - 1; i > indice; i--) {
                actual = actual.anterior;
            }
        }

        return actual;
    }

    // =====================================
    // 4. INSERTAR EN UNA POSICION
    // =====================================
    public void insertarPosicion(int indice, Estudiante dato) {

        if (indice < 0 || indice > tamaño) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida");
        }

        if (indice == 0) {
            insertarInicio(dato);
            return;
        }

        if (indice == tamaño) {
            insertarFinal(dato);
            return;
        }

        NodoEstudiante actual = obtenerNodoEstudiante(indice);
        NodoEstudiante nuevo = new NodoEstudiante(dato);

        nuevo.anterior = actual.anterior;
        nuevo.siguiente = actual;

        actual.anterior.siguiente = nuevo;
        actual.anterior = nuevo;

        tamaño++;
    }

    // =====================================
    // 5. INSERTAR DESPUES DE UN CODIGO
    // =====================================
    public boolean insertarDespuesDe(
            String codigo, Estudiante dato) {

        NodoEstudiante actual = cabeza;

        while (actual != null) {

            if (actual.dato.getCodigo().equals(codigo)) {

                if (actual == cola) {
                    insertarFinal(dato);
                    return true;
                }

                NodoEstudiante nuevo = new NodoEstudiante(dato);

                nuevo.anterior = actual;
                nuevo.siguiente = actual.siguiente;

                actual.siguiente.anterior = nuevo;
                actual.siguiente = nuevo;

                tamaño++;

                return true;
            }

            actual = actual.siguiente;
        }

        return false;
    }

    // =====================================
    // 6. ELIMINAR AL INICIO
    // =====================================
    public Estudiante eliminarInicio() {

        if (cabeza == null) {
            return null;
        }

        Estudiante eliminado = cabeza.dato;

        cabeza = cabeza.siguiente;

        if (cabeza == null) {

            cola = null;

        } else {

            cabeza.anterior = null;
        }

        tamaño--;

        return eliminado;
    }

    // =====================================
    // 7. ELIMINAR AL FINAL
    // =====================================
    public Estudiante eliminarFinal() {

        if (cola == null) {
            return null;
        }

        Estudiante eliminado = cola.dato;

        cola = cola.anterior;

        if (cola == null) {

            cabeza = null;

        } else {

            cola.siguiente = null;
        }

        tamaño--;

        return eliminado;
    }

    // =====================================
    // 8. ELIMINAR POR POSICION
    // =====================================
    public Estudiante eliminarPosicion(int indice) {

        if (indice < 0 || indice >= tamaño) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida");
        }

        if (indice == 0) {
            return eliminarInicio();
        }

        if (indice == tamaño - 1) {
            return eliminarFinal();
        }

        NodoEstudiante actual = obtenerNodoEstudiante(indice);

        actual.anterior.siguiente = actual.siguiente;
        actual.siguiente.anterior = actual.anterior;

        tamaño--;

        return actual.dato;
    }

    // =====================================
    // 9. ELIMINAR POR CODIGO
    // =====================================
    public boolean eliminarPorCodigo(String codigo) {

        NodoEstudiante actual = cabeza;

        while (actual != null) {

            if (actual.dato.getCodigo().equals(codigo)) {

                if (actual == cabeza) {

                    eliminarInicio();

                } else if (actual == cola) {

                    eliminarFinal();

                } else {

                    actual.anterior.siguiente = actual.siguiente;
                    actual.siguiente.anterior = actual.anterior;

                    tamaño--;
                }

                return true;
            }

            actual = actual.siguiente;
        }

        return false;
    }

    // =====================================
    // 10. BUSCAR POR CODIGO
    // =====================================
    public Estudiante buscarPorCodigo(String codigo) {

        NodoEstudiante actual = cabeza;

        while (actual != null) {

            if (actual.dato.getCodigo().equals(codigo)) {
                return actual.dato;
            }

            actual = actual.siguiente;
        }

        return null;
    }

    // =====================================
    // 11. BUSCAR POR POSICION
    // =====================================
    public Estudiante buscarPosicion(int indice) {

        return obtenerNodoEstudiante(indice).dato;
    }

    // =====================================
    // 12. RECORRER DE IZQUIERDA A DERECHA
    // =====================================
    public void recorrerAdelante() {

        NodoEstudiante actual = cabeza;

        while (actual != null) {

            System.out.println(actual.dato);

            actual = actual.siguiente;
        }
    }

    // =====================================
    // 13. RECORRER DE DERECHA A IZQUIERDA
    // =====================================
    public void recorrerAtras() {

        NodoEstudiante actual = cola;

        while (actual != null) {

            System.out.println(actual.dato);

            actual = actual.anterior;
        }
    }

    // =====================================
    // 14. ORDENAR POR PROMEDIO
    // DE MAYOR A MENOR
    // =====================================
    public void ordenarPorPromedio() {

        if (tamaño < 2) {
            return;
        }

        boolean intercambio;

        do {

            intercambio = false;

            NodoEstudiante actual = cabeza;

            while (actual.siguiente != null) {

                if (actual.dato.getPromedio()
                        < actual.siguiente.dato.getPromedio()) {

                    Estudiante temporal = actual.dato;

                    actual.dato = actual.siguiente.dato;

                    actual.siguiente.dato = temporal;

                    intercambio = true;
                }

                actual = actual.siguiente;
            }

        } while (intercambio);
    }

    // =====================================
    // 15. INTERCAMBIAR DOS POSICIONES
    // =====================================
    public void intercambiar(int indice1, int indice2) {

        NodoEstudiante nodo1 = obtenerNodoEstudiante(indice1);
        NodoEstudiante nodo2 = obtenerNodoEstudiante(indice2);

        Estudiante temporal = nodo1.dato;

        nodo1.dato = nodo2.dato;
        nodo2.dato = temporal;
    }

    // =====================================
    // 16. MODIFICAR ALUMNO
    // =====================================
    public boolean modificarEstudiante(
            String codigo, Estudiante nuevoDato) {

        NodoEstudiante actual = cabeza;

        while (actual != null) {

            if (actual.dato.getCodigo().equals(codigo)) {

                actual.dato.setNombre(nuevoDato.getNombre());
                actual.dato.setEdad(nuevoDato.getEdad());
                actual.dato.setPromedio(nuevoDato.getPromedio());

                return true;
            }

            actual = actual.siguiente;
        }

        return false;
    }

    // =====================================
    // 17. OBTENER TAMAÑO
    // =====================================
    public int obtenerTamaño() {

        return tamaño;
    }

    // =====================================
    // 18. VERIFICAR SI ESTA VACIA
    // =====================================
    public boolean estaVacia() {

        return cabeza == null;
    }
}
