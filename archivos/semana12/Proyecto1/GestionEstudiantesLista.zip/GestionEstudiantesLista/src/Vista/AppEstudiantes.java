package Vista;

import DAO.ListaDobleEstudiantes;

public class AppEstudiantes {

    public static void main(String[] args) {

        // Crear la estructura de datos
        ListaDobleEstudiantes lista = new ListaDobleEstudiantes();

        // Crear el menú
        MenuGestion menu = new MenuGestion(lista);

        // Ejecutar la aplicación
        menu.mostrarMenu();
    }
}
