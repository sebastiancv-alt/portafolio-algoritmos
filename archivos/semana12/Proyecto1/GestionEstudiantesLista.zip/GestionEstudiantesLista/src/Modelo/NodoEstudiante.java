
package Modelo;

public class NodoEstudiante {

    // Información del estudiante
    public Estudiante dato;

    // Referencia al nodo anterior
    public NodoEstudiante anterior;

    // Referencia al nodo siguiente
    public NodoEstudiante siguiente;

    // Constructor
    public NodoEstudiante(Estudiante dato) {

        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }
}
