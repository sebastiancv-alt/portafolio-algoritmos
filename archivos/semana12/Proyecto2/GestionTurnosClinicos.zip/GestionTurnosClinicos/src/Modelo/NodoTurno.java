package Modelo;

/** NodoTurno de lista DOBLEMENTE enlazada: anterior, dato y siguiente. */
public class NodoTurno {
    public TurnoClinico dato;
    public NodoTurno anterior;
    public NodoTurno siguiente;

    public NodoTurno(TurnoClinico dato) {
        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }
}
