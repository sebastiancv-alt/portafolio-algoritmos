package Modelo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Cada turno contiene los ocho datos solicitados en el enunciado. */
public class TurnoClinico {
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/uuuu");
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");

    private String codigo;
    private String dni;
    private String nombresApellidos;
    private String especialidad;
    private String medico;
    private LocalDate fechaAtencion;
    private LocalTime horaAtencion;
    private String estado;

    public TurnoClinico() {
    }

    public TurnoClinico(String codigo, String dni, String nombresApellidos,
            String especialidad, String medico, LocalDate fechaAtencion,
            LocalTime horaAtencion, String estado) {
        this.codigo = codigo;
        this.dni = dni;
        this.nombresApellidos = nombresApellidos;
        this.especialidad = especialidad;
        this.medico = medico;
        this.fechaAtencion = fechaAtencion;
        this.horaAtencion = horaAtencion;
        setEstado(estado);
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public String getNombresApellidos() { return nombresApellidos; }
    public void setNombresApellidos(String nombresApellidos) { this.nombresApellidos = nombresApellidos; }
    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
    public String getMedico() { return medico; }
    public void setMedico(String medico) { this.medico = medico; }
    public LocalDate getFechaAtencion() { return fechaAtencion; }
    public void setFechaAtencion(LocalDate fechaAtencion) { this.fechaAtencion = fechaAtencion; }
    public LocalTime getHoraAtencion() { return horaAtencion; }
    public void setHoraAtencion(LocalTime horaAtencion) { this.horaAtencion = horaAtencion; }
    public String getEstado() { return estado; }

    /** Estados utilizados por el conteo del requerimiento 10. */
    public void setEstado(String estado) {
        if (estado == null) throw new IllegalArgumentException("El estado es obligatorio.");
        switch (estado.trim().toLowerCase(Locale.ROOT)) {
            case "registrada": this.estado = "Registrada"; break;
            case "atendida": this.estado = "Atendida"; break;
            case "cancelada": this.estado = "Cancelada"; break;
            default: throw new IllegalArgumentException("Estado: Registrada, Atendida o Cancelada.");
        }
    }

    @Override
    public String toString() {
        return "Código: " + codigo + " | DNI: " + dni
            + " | Paciente: " + nombresApellidos
            + " | Especialidad: " + especialidad
            + " | Médico: " + medico
            + " | Fecha: " + (fechaAtencion == null ? "-" : fechaAtencion.format(FECHA))
            + " | Hora: " + (horaAtencion == null ? "-" : horaAtencion.format(HORA))
            + " | Estado: " + estado;
    }
}
