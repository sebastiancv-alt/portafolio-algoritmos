package vista;

import Modelo.TurnoClinico;
import dao.ListaDobleTurnos;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Scanner;

/** Vista: 10 requerimientos funcionales del Proyecto 02. */
public class AppTurnos {
    private static final Scanner teclado = new Scanner(System.in);
    private static final ListaDobleTurnos lista = new ListaDobleTurnos();
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/uuuu")
            .withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm")
            .withResolverStyle(ResolverStyle.STRICT);

    public static void main(String[] args) {
        int opcion;
        do {
            MenuTurnos.mostrar();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                ejecutar(opcion);
            } catch (IllegalArgumentException error) {
                System.out.println("[Error] " + error.getMessage());
            }
        } while (opcion != 0);
        System.out.println("Sistema finalizado.");
    }

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine().trim();
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            String entrada = leerTexto(mensaje);
            try { return Integer.parseInt(entrada); }
            catch (NumberFormatException e) { System.out.println("[Error] Ingrese un número entero."); }
        }
    }

    private static LocalDate leerFecha() {
        while (true) {
            try { return LocalDate.parse(leerTexto("Fecha de atención (dd/MM/aaaa): "), FECHA); }
            catch (DateTimeParseException e) { System.out.println("[Error] Formato de fecha incorrecto."); }
        }
    }

    private static LocalTime leerHora() {
        while (true) {
            try { return LocalTime.parse(leerTexto("Hora de atención (HH:mm, 24 h): "), HORA); }
            catch (DateTimeParseException e) { System.out.println("[Error] Hora inválida. Ejemplo: 10:30."); }
        }
    }

    private static String leerEstado() {
        while (true) {
            System.out.println("Estado: 1. Registrada   2. Atendida   3. Cancelada");
            switch (leerEntero("Seleccione el estado: ")) {
                case 1: return "Registrada";
                case 2: return "Atendida";
                case 3: return "Cancelada";
                default: System.out.println("[Error] Elija del 1 al 3.");
            }
        }
    }

    private static TurnoClinico leerCita() {
        String codigo = leerTexto("Código de turno: ");
        String dni = leerTexto("DNI del paciente: ");
        String nombres = leerTexto("Nombres y apellidos: ");
        String especialidad = leerTexto("Especialidad médica: ");
        String medico = leerTexto("Nombre del médico: ");
        LocalDate fecha = leerFecha();
        LocalTime hora = leerHora();
        String estado = leerEstado();
        return new TurnoClinico(codigo, dni, nombres, especialidad, medico, fecha, hora, estado);
    }

    private static void registrarCita() {
        MenuTurnos.mostrarRegistro();
        int alternativa = leerEntero("Seleccione una opción: ");
        if (alternativa != 1 && alternativa != 2) {
            if (alternativa != 0) System.out.println("[Error] Alternativa no válida.");
            return;
        }
        TurnoClinico turno = leerCita();
        if (alternativa == 1) {
            lista.registrarAlInicio(cita);
            System.out.println("[Éxito] Turno registrado al inicio.");
        } else {
            lista.registrarAlFinal(cita);
            System.out.println("[Éxito] Turno registrado al final.");
        }
    }

    private static void cancelarOEliminar() {
        MenuTurnos.mostrarCancelacion();
        int alternativa = leerEntero("Seleccione una opción: ");
        if (alternativa == 1) {
            System.out.println(lista.cancelarCita(leerTexto("Código de turno a cancelar: "))
                    ? "[Éxito] Turno cancelado (se conserva para el conteo)."
                    : "[Error] Turno no encontrado.");
        } else if (alternativa == 2) {
            TurnoClinico eliminada = lista.eliminarCita(leerTexto("Código de turno a eliminar: "));
            System.out.println(eliminada == null ? "[Error] Turno no encontrado."
                    : "[Éxito] Turno eliminado: " + eliminada.getCodigo());
        } else if (alternativa != 0) {
            System.out.println("[Error] Alternativa no válida.");
        }
    }

    private static void ejecutar(int opcion) {
        switch (opcion) {
            case 1: // Registrar un turno al inicio o al final
                registrarCita();
                break;
            case 2: { // Insertar en una posición
                int posicion = leerEntero("Posición (desde 1): ");
                TurnoClinico turno = leerCita();
                System.out.println(lista.insertarEnPosicion(posicion, cita)
                        ? "[Éxito] Turno insertado." : "[Error] Posición fuera de rango.");
                break;
            }
            case 3: { // Buscar por código o DNI
                TurnoClinico encontrada = lista.buscarPorCodigoODni(
                        leerTexto("Código de turno o DNI del paciente: "));
                System.out.println(encontrada == null ? "[Aviso] Turno no encontrado."
                        : "[Resultado] " + encontrada);
                break;
            }
            case 4: { // Modificar un turno
                String codigo = leerTexto("Código de el turno a modificar: ");
                if (lista.buscarPorCodigo(codigo) == null) {
                    System.out.println("[Error] No se encontró un turno con ese código.");
                    break;
                }
                System.out.println("Ingrese los datos actualizados:");
                TurnoClinico turno = leerCita();
                System.out.println(lista.modificarCita(codigo, cita)
                        ? "[Éxito] Información del turno modificada."
                        : "[Error] Turno no encontrado.");
                break;
            }
            case 5: // Cancelar o eliminar
                cancelarOEliminar();
                break;
            case 6: // Mostrar desde la primera hasta la última
                System.out.println("\n--- TURNOS: PRIMERA A ÚLTIMA ---");
                System.out.println(lista.mostrarInicioFin());
                break;
            case 7: // Mostrar en orden inverso
                System.out.println("\n--- TURNOS: ÚLTIMA A PRIMERA ---");
                System.out.println(lista.mostrarFinInicio());
                break;
            case 8: // Ordenar por fecha y hora
                lista.ordenarPorFechaHora();
                System.out.println("[Éxito] Turnos ordenados por fecha y hora ascendente.");
                System.out.println(lista.mostrarInicioFin());
                break;
            case 9: // Buscar turnos de un médico
                System.out.println(lista.buscarCitasPorMedico(
                        leerTexto("Nombre o parte del nombre del médico: ")));
                break;
            case 10: // Contabilizar turnos por estado
                System.out.println("[Conteo] " + lista.contabilizarPorEstado());
                break;
            case 0:
                break;
            default:
                System.out.println("[Error] Opción inválida.");
        }
    }
}
