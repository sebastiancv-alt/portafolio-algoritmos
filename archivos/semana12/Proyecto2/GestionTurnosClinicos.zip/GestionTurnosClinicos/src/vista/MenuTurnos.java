package vista;

/** Menú del Proyecto 02: exactamente los 10 requerimientos de la guía. */
public class MenuTurnos {
    private MenuTurnos() { }

    public static void mostrar() {
        System.out.println("\n=========================================================");
        System.out.println("  PROYECTO 02 - SISTEMA DE GESTIÓN DE CITAS MÉDICAS");
        System.out.println("       LISTA DOBLEMENTE ENLAZADA - CENTRO DE SALUD");
        System.out.println("=========================================================");
        System.out.println(" 1. Registrar turno al inicio o al final de la lista");
        System.out.println(" 2. Insertar turno en una posición determinada");
        System.out.println(" 3. Buscar turno por código o DNI del paciente");
        System.out.println(" 4. Modificar información de un turno clínico");
        System.out.println(" 5. Cancelar o eliminar un turno");
        System.out.println(" 6. Mostrar turnos desde la primera hasta la última");
        System.out.println(" 7. Mostrar turnos en orden inverso");
        System.out.println(" 8. Ordenar turnos por fecha y hora de atención");
        System.out.println(" 9. Buscar turnos de un médico determinado");
        System.out.println("10. Contabilizar turnos registradas, atendidas y canceladas");
        System.out.println(" 0. Salir");
    }

    public static void mostrarRegistro() {
        System.out.println("\n--- REQUERIMIENTO 1: REGISTRAR UNA CITA ---");
        System.out.println("1. Registrar al inicio de la lista");
        System.out.println("2. Registrar al final de la lista");
        System.out.println("0. Volver al menú principal");
    }

    public static void mostrarCancelacion() {
        System.out.println("\n--- REQUERIMIENTO 5: CANCELAR O ELIMINAR ---");
        System.out.println("1. Cancelar turno (mantener registro y cambiar estado)");
        System.out.println("2. Eliminar turno (retirar el nodo de la lista)");
        System.out.println("0. Volver al menú principal");
    }
}
