package dao;

import Modelo.TurnoClinico;
import Modelo.NodoTurno;
import java.time.LocalDateTime;
import java.util.Locale;

/**
 * DAO del Proyecto 02: implementación manual de lista doblemente enlazada.
 * Posiciones desde 1; los turnos viven solo en memoria RAM.
 */
public class ListaDobleTurnos {
    private NodoTurno cabeza;
    private NodoTurno cola;
    private int tamano;

    public ListaDobleTurnos() {
        cabeza = null;
        cola = null;
        tamano = 0;
    }

    public boolean estaVacia() { return cabeza == null; }
    public int getTamano() { return tamano; }

    private static boolean igual(String a, String b) {
        return a != null && b != null && a.trim().equalsIgnoreCase(b.trim());
    }

    private static boolean tieneTexto(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }

    private void validarCita(TurnoClinico cita, String codigoActual) {
        if (cita == null || !tieneTexto(cita.getCodigo()) || !tieneTexto(cita.getDni())
                || !tieneTexto(cita.getNombresApellidos())
                || !tieneTexto(cita.getEspecialidad()) || !tieneTexto(cita.getMedico())
                || cita.getFechaAtencion() == null || cita.getHoraAtencion() == null
                || !tieneTexto(cita.getEstado())) {
            throw new IllegalArgumentException("Complete los ocho datos del turno clínico.");
        }
        NodoTurno repetido = nodoPorCodigo(cita.getCodigo());
        if (repetido != null && !igual(repetido.dato.getCodigo(), codigoActual)) {
            throw new IllegalArgumentException("Ya existe un turno con ese código.");
        }
    }

    private NodoTurno nodoPorCodigo(String codigo) {
        for (NodoTurno actual = cabeza; actual != null; actual = actual.siguiente) {
            if (igual(actual.dato.getCodigo(), codigo)) return actual;
        }
        return null;
    }

    private NodoTurno nodoEn(int posicion) {
        if (posicion < 1 || posicion > tamano) return null;
        if (posicion <= tamano / 2) {
            NodoTurno actual = cabeza;
            for (int i = 1; i < posicion; i++) actual = actual.siguiente;
            return actual;
        }
        NodoTurno actual = cola;
        for (int i = tamano; i > posicion; i--) actual = actual.anterior;
        return actual;
    }

    // REQUERIMIENTO 1: registrar nuevo turno al inicio
    public void registrarAlInicio(TurnoClinico cita) {
        validarCita(cita, null);
        NodoTurno nuevo = new NodoTurno(cita);
        if (estaVacia()) cabeza = cola = nuevo;
        else {
            nuevo.siguiente = cabeza;
            cabeza.anterior = nuevo;
            cabeza = nuevo;
        }
        tamano++;
    }

    // REQUERIMIENTO 1: registrar nuevo turno al final
    public void registrarAlFinal(TurnoClinico cita) {
        validarCita(cita, null);
        NodoTurno nuevo = new NodoTurno(cita);
        if (estaVacia()) cabeza = cola = nuevo;
        else {
            nuevo.anterior = cola;
            cola.siguiente = nuevo;
            cola = nuevo;
        }
        tamano++;
    }

    // REQUERIMIENTO 2: insertar turno en posición determinada
    public boolean insertarEnPosicion(int posicion, TurnoClinico cita) {
        if (posicion < 1 || posicion > tamano + 1) return false;
        validarCita(cita, null);
        if (posicion == 1) registrarAlInicio(cita);
        else if (posicion == tamano + 1) registrarAlFinal(cita);
        else {
            NodoTurno siguiente = nodoEn(posicion);
            NodoTurno anterior = siguiente.anterior;
            NodoTurno nuevo = new NodoTurno(cita);
            nuevo.anterior = anterior;
            nuevo.siguiente = siguiente;
            anterior.siguiente = nuevo;
            siguiente.anterior = nuevo;
            tamano++;
        }
        return true;
    }

    /** Búsqueda exacta por código, útil para modificar un turno específica. */
    public TurnoClinico buscarPorCodigo(String codigo) {
        NodoTurno nodo = nodoPorCodigo(codigo);
        return nodo == null ? null : nodo.dato;
    }

    // REQUERIMIENTO 3: buscar por código o DNI del paciente
    public TurnoClinico buscarPorCodigoODni(String criterio) {
        for (NodoTurno actual = cabeza; actual != null; actual = actual.siguiente) {
            if (igual(actual.dato.getCodigo(), criterio) || igual(actual.dato.getDni(), criterio))
                return actual.dato;
        }
        return null;
    }

    // REQUERIMIENTO 4: modificar todos los datos de el turno, incluido su estado
    public boolean modificarCita(String codigoAnterior, TurnoClinico nuevosDatos) {
        NodoTurno nodo = nodoPorCodigo(codigoAnterior);
        if (nodo == null) return false;
        validarCita(nuevosDatos, codigoAnterior);
        nodo.dato.setCodigo(nuevosDatos.getCodigo());
        nodo.dato.setDni(nuevosDatos.getDni());
        nodo.dato.setNombresApellidos(nuevosDatos.getNombresApellidos());
        nodo.dato.setEspecialidad(nuevosDatos.getEspecialidad());
        nodo.dato.setMedico(nuevosDatos.getMedico());
        nodo.dato.setFechaAtencion(nuevosDatos.getFechaAtencion());
        nodo.dato.setHoraAtencion(nuevosDatos.getHoraAtencion());
        nodo.dato.setEstado(nuevosDatos.getEstado());
        return true;
    }

    // REQUERIMIENTO 5: cancelar un turno SIN borrarla (estado = Cancelada)
    public boolean cancelarCita(String codigo) {
        NodoTurno nodo = nodoPorCodigo(codigo);
        if (nodo == null) return false;
        nodo.dato.setEstado("Cancelada");
        return true;
    }

    // REQUERIMIENTO 5: eliminar físicamente un turno
    public TurnoClinico eliminarCita(String codigo) {
        NodoTurno nodo = nodoPorCodigo(codigo);
        if (nodo == null) return null;
        NodoTurno anterior = nodo.anterior;
        NodoTurno siguiente = nodo.siguiente;
        if (anterior != null) anterior.siguiente = siguiente;
        else cabeza = siguiente;
        if (siguiente != null) siguiente.anterior = anterior;
        else cola = anterior;
        nodo.anterior = null;
        nodo.siguiente = null;
        tamano--;
        return nodo.dato;
    }

    // REQUERIMIENTO 6: recorrido desde primera a última
    public String mostrarInicioFin() {
        if (estaVacia()) return "No hay turnos clínicos registradas.";
        StringBuilder salida = new StringBuilder();
        NodoTurno actual = cabeza;
        int numero = 1;
        while (actual != null) {
            salida.append(numero++).append(". ").append(actual.dato).append('\n');
            actual = actual.siguiente;
        }
        return salida.toString();
    }

    // REQUERIMIENTO 7: recorrido en orden inverso
    public String mostrarFinInicio() {
        if (estaVacia()) return "No hay turnos clínicos registradas.";
        StringBuilder salida = new StringBuilder();
        NodoTurno actual = cola;
        int numero = tamano;
        while (actual != null) {
            salida.append(numero--).append(". ").append(actual.dato).append('\n');
            actual = actual.anterior;
        }
        return salida.toString();
    }

    private static LocalDateTime instante(TurnoClinico cita) {
        return LocalDateTime.of(cita.getFechaAtencion(), cita.getHoraAtencion());
    }

    // REQUERIMIENTO 8: ordenar por fecha, luego hora (más próxima primero)
    public void ordenarPorFechaHora() {
        if (tamano < 2) return;
        boolean intercambio;
        do {
            intercambio = false;
            for (NodoTurno actual = cabeza; actual.siguiente != null; actual = actual.siguiente) {
                if (instante(actual.dato).isAfter(instante(actual.siguiente.dato))) {
                    TurnoClinico temporal = actual.dato;
                    actual.dato = actual.siguiente.dato;
                    actual.siguiente.dato = temporal;
                    intercambio = true;
                }
            }
        } while (intercambio);
    }

    // REQUERIMIENTO 9: buscar TODAS los turnos de un médico
    public String buscarCitasPorMedico(String nombreMedico) {
        if (!tieneTexto(nombreMedico)) return "Ingrese un médico válido.";
        StringBuilder salida = new StringBuilder();
        String filtro = nombreMedico.trim().toLowerCase(Locale.ROOT);
        int encontradas = 0;
        for (NodoTurno actual = cabeza; actual != null; actual = actual.siguiente) {
            if (actual.dato.getMedico().toLowerCase(Locale.ROOT).contains(filtro)) {
                salida.append(++encontradas).append(". ").append(actual.dato).append('\n');
            }
        }
        return encontradas == 0 ? "No se encontraron turnos con ese médico." : salida.toString();
    }

    // REQUERIMIENTO 10: contabilizar turnos registradas, atendidas y canceladas
    public String contabilizarPorEstado() {
        int registradas = 0;
        int atendidas = 0;
        int canceladas = 0;
        for (NodoTurno actual = cabeza; actual != null; actual = actual.siguiente) {
            switch (actual.dato.getEstado()) {
                case "Registrada": registradas++; break;
                case "Atendida": atendidas++; break;
                case "Cancelada": canceladas++; break;
                default: break;
            }
        }
        return "Registradas: " + registradas + " | Atendidas: " + atendidas
                + " | Canceladas: " + canceladas + " | Total: " + tamano;
    }
}
