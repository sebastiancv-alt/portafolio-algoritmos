package pruebas;

import Modelo.TurnoClinico;
import dao.ListaDobleTurnos;
import java.time.LocalDate;
import java.time.LocalTime;

/** Pruebas de los diez requerimientos sin dependencias externas. */
public class PruebaTurnos {
    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) throw new AssertionError(mensaje);
    }

    private static TurnoClinico cita(String codigo, int dia, int hora, String medico, String estado) {
        return new TurnoClinico(codigo, "12345678", "Paciente " + codigo,
                "Cardiología", medico, LocalDate.of(2026, 11, dia),
                LocalTime.of(hora, 30), estado);
    }

    public static void main(String[] args) {
        ListaDobleTurnos l = new ListaDobleTurnos();
        comprobar(l.estaVacia(), "lista vacía");
        l.registrarAlInicio(cita("C002", 24, 12, "Dr. León", "Registrada"));
        l.registrarAlFinal(cita("C003", 22, 10, "Dra. Torres", "Atendida"));
        comprobar(l.insertarEnPosicion(2, cita("C001", 20, 8, "Dr. León", "Registrada")), "insertar posición");
        comprobar(l.getTamano() == 3, "tamaño inicial");
        comprobar(l.buscarPorCodigoODni("C001") != null, "buscar código");
        comprobar(l.buscarPorCodigoODni("12345678") != null, "buscar DNI");
        comprobar(l.mostrarInicioFin().indexOf("C002") < l.mostrarInicioFin().indexOf("C003"), "recorrido adelante");
        comprobar(l.mostrarFinInicio().indexOf("C003") < l.mostrarFinInicio().indexOf("C002"), "recorrido inverso");
        comprobar(l.buscarCitasPorMedico("león").contains("C001"), "buscar por médico");
        comprobar(l.cancelarCita("C002"), "cancelar");
        comprobar(l.getTamano() == 3, "cancelar mantiene cita");
        comprobar(l.contabilizarPorEstado().contains("Canceladas: 1"), "conteo canceladas");
        comprobar(l.modificarCita("C001", cita("C009", 21, 9, "Dra. Torres", "Atendida")), "modificar");
        comprobar(l.buscarPorCodigoODni("C009") != null && l.buscarPorCodigoODni("C001") == null, "modificación de código");
        comprobar(l.contabilizarPorEstado().contains("Atendidas: 2"), "conteo atendidas");
        l.ordenarPorFechaHora();
        comprobar(l.mostrarInicioFin().indexOf("C009") < l.mostrarInicioFin().indexOf("C003"), "orden fecha/hora");
        comprobar(l.eliminarCita("C003") != null, "eliminar físicamente");
        comprobar(l.getTamano() == 2 && l.buscarPorCodigoODni("C003") == null, "lista y tamaño al eliminar");
        comprobar(l.eliminarCita("C009") != null && l.eliminarCita("C002") != null, "eliminar hasta vacía");
        comprobar(l.estaVacia() && l.getTamano() == 0, "extremos al quedar vacía");
        System.out.println("OK: 10 requerimientos de Gestión de Turnos Clínicos verificados.");
    }
}
