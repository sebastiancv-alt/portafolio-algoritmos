PROYECTO 04 - SistemaCostosCompuestos (Algoritmos y Estructura de Datos - UPLA)
Sistema de calculo de costos de productos compuestos en una empresa manufacturera.

COMO ABRIR EN NETBEANS
  File > Open Project > seleccionar la carpeta del proyecto > clic derecho > Run (F6).
  Clase principal: Vista.Principal
  (Alternativa: crear un proyecto Java Application, crear los paquetes Modelo, DAO y
   Vista y copiar los .java de src/<paquete>/ en cada paquete.)

ESTRUCTURA
  Modelo/Producto.java       Producto o componente (codigo, nombre, costo propio).
  Modelo/Componente.java     Relacion producto-componente con su cantidad.
  DAO/CostosDAO.java         Registro, verificacion de ciclos y calculo recursivo.
  Vista/MenuCostosVista.java Menu de consola y casos de prueba.
  Vista/Principal.java       Inicia la aplicacion.

REGLA DE COSTO
  costoTotal(P) = costoPropio(P) + SUMA( cantidad x costoTotal(componente) )
  Un componente basico no tiene componentes: su costo total es su costo propio.
  En un compuesto, el costo propio representa el ensamblaje (puede ser 0).

USO RAPIDO
  Opcion 7: carga datos de ejemplo (DESK, SERV, PLACA, ALMA y componentes).
  Opcion 4: ingrese DESK -> reporte con desglose por niveles, materiales base y total (991.00).
  Opcion 5: componentes compartidos. Opcion 8: casos de prueba.

RECURSIVIDAD
  - calcularCosto / costoTotal: recorrido recursivo por todos los niveles.
  - desglose: recorrido recursivo con el nivel como parametro.
  - agregarComponente: rechaza ciclos buscando recursivamente si el componente ya
    depende del producto (RF08). tieneCiclos() revisa toda la estructura con un
    conjunto de visitados y otro de nodos en exploracion.

COMPLEJIDAD
  Sea n el numero de elementos y r el numero de relaciones.
  - Calculo de costo sin memorizar: O(numero de caminos del DAG desde el producto);
    cada componente compartido se recalcula por cada camino. Con memorizacion
    (Map codigo -> costo) bajaria a O(n + r).
  - Deteccion de ciclos: O(n + r).  - Espacio de pila: O(profundidad de la jerarquia).
  - Se usa BigDecimal para evitar errores de redondeo en costos.
