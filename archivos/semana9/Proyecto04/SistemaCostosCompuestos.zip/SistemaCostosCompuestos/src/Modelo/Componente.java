package Modelo;

/**
 * Relacion entre un producto y uno de sus componentes, con la cantidad requerida.
 */
public class Componente {

    private final Producto producto;
    private int cantidad;

    public Componente(Producto producto, int cantidad) {
        if (producto == null) {
            throw new IllegalArgumentException("El componente no puede ser nulo.");
        }
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    /** Se usa cuando el mismo componente se registra mas de una vez. */
    public void aumentarCantidad(int adicional) {
        if (adicional <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        this.cantidad += adicional;
    }
}
