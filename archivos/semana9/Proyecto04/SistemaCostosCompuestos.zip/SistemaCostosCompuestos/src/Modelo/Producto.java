package Modelo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa un producto o componente.
 *
 * costoUnitario es el costo propio del elemento:
 *  - en un componente basico, su precio de compra o fabricacion;
 *  - en un producto compuesto, el costo propio de ensamblaje (puede ser 0).
 * El costo total de un compuesto = costo propio + suma(cantidad x costo total de cada componente).
 */
public class Producto {

    private final String codigo;
    private final String nombre;
    private final BigDecimal costoUnitario;
    private final List<Componente> componentes;

    public Producto(String codigo, String nombre, BigDecimal costoUnitario) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El codigo no puede estar vacio.");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio.");
        }
        if (costoUnitario == null || costoUnitario.signum() < 0) {
            throw new IllegalArgumentException("El costo unitario no puede ser negativo.");
        }
        this.codigo = codigo.trim().toUpperCase();
        this.nombre = nombre.trim();
        this.costoUnitario = costoUnitario;
        this.componentes = new ArrayList<Componente>();
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public BigDecimal getCostoUnitario() {
        return costoUnitario;
    }

    public List<Componente> getComponentes() {
        return Collections.unmodifiableList(componentes);
    }

    public boolean esCompuesto() {
        return !componentes.isEmpty();
    }

    /** Agrega el componente; si ya existia, suma la cantidad. */
    public void agregarComponente(Producto hijo, int cantidad) {
        for (Componente c : componentes) {
            if (c.getProducto() == hijo) {
                c.aumentarCantidad(cantidad);
                return;
            }
        }
        componentes.add(new Componente(hijo, cantidad));
    }
}
