package DAO;

import Modelo.Componente;
import Modelo.Producto;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Registra productos y componentes, verifica ciclos y calcula costos
 * mediante recorridos recursivos sobre la estructura jerarquica.
 */
public class CostosDAO {

    private final Map<String, Producto> productos =
            new LinkedHashMap<String, Producto>();

    // ------------------------------------------------------------------
    // RF01, RF02, RF09: registro con validaciones
    // ------------------------------------------------------------------
    public Producto registrarProducto(String codigo, String nombre, BigDecimal costo) {
        Producto p = new Producto(codigo, nombre, costo);
        if (productos.containsKey(p.getCodigo())) {
            throw new IllegalArgumentException("Ya existe un elemento con el codigo " + p.getCodigo() + ".");
        }
        productos.put(p.getCodigo(), p);
        return p;
    }

    public Producto obtener(String codigo) {
        if (codigo == null) {
            throw new IllegalArgumentException("El codigo no puede ser nulo.");
        }
        Producto p = productos.get(codigo.trim().toUpperCase());
        if (p == null) {
            throw new IllegalArgumentException("No existe el codigo " + codigo.trim().toUpperCase() + ".");
        }
        return p;
    }

    public Collection<Producto> listar() {
        return productos.values();
    }

    // ------------------------------------------------------------------
    // RF03, RF04, RF08: composicion rechazando ciclos
    // ------------------------------------------------------------------
    public void agregarComponente(String codigoProducto, String codigoComponente, int cantidad) {
        Producto padre = obtener(codigoProducto);
        Producto hijo = obtener(codigoComponente);

        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        // Si desde el componente se puede llegar al producto, se formaria un ciclo.
        if (padre == hijo || alcanza(hijo, padre, new HashSet<String>())) {
            throw new IllegalArgumentException("Ciclo detectado: " + hijo.getCodigo()
                    + " ya depende de " + padre.getCodigo() + ".");
        }
        padre.agregarComponente(hijo, cantidad);
    }

    /** Busqueda recursiva: Se puede llegar a 'objetivo' desde 'desde'? */
    private boolean alcanza(Producto desde, Producto objetivo, Set<String> visitados) {
        if (desde == objetivo) {
            return true;
        }
        if (!visitados.add(desde.getCodigo())) {
            return false;
        }
        for (Componente c : desde.getComponentes()) {
            if (alcanza(c.getProducto(), objetivo, visitados)) {
                return true;
            }
        }
        return false;
    }

    /** RF08: verifica toda la estructura (visitados + en exploracion). */
    public boolean tieneCiclos() {
        Set<String> visitados = new HashSet<String>();
        Set<String> enExploracion = new HashSet<String>();
        for (Producto p : productos.values()) {
            if (dfsCiclo(p, visitados, enExploracion)) {
                return true;
            }
        }
        return false;
    }

    private boolean dfsCiclo(Producto p, Set<String> visitados, Set<String> enExploracion) {
        if (enExploracion.contains(p.getCodigo())) {
            return true;
        }
        if (visitados.contains(p.getCodigo())) {
            return false;
        }
        visitados.add(p.getCodigo());
        enExploracion.add(p.getCodigo());
        for (Componente c : p.getComponentes()) {
            if (dfsCiclo(c.getProducto(), visitados, enExploracion)) {
                return true;
            }
        }
        enExploracion.remove(p.getCodigo());
        return false;
    }

    // ------------------------------------------------------------------
    // RF05: costo total recursivo
    // ------------------------------------------------------------------
    public BigDecimal calcularCosto(String codigo) {
        return costoTotal(obtener(codigo));
    }

    private BigDecimal costoTotal(Producto p) {
        BigDecimal total = p.getCostoUnitario();
        for (Componente c : p.getComponentes()) {
            BigDecimal costoComponente = costoTotal(c.getProducto());
            total = total.add(costoComponente.multiply(BigDecimal.valueOf(c.getCantidad())));
        }
        return total;
    }

    // ------------------------------------------------------------------
    // RF06: desglose por niveles
    // ------------------------------------------------------------------
    public String desglose(String codigo) {
        StringBuilder sb = new StringBuilder();
        desglosar(obtener(codigo), 1, 0, sb);
        return sb.toString();
    }

    private void desglosar(Producto p, int cantidad, int nivel, StringBuilder sb) {
        for (int i = 0; i < nivel; i++) {
            sb.append("    ");
        }
        BigDecimal total = costoTotal(p);
        sb.append("[N").append(nivel).append("] ");
        if (nivel > 0) {
            sb.append(cantidad).append(" x ");
        }
        sb.append(p.getNombre()).append(" (").append(p.getCodigo()).append(")");
        if (p.esCompuesto()) {
            sb.append(" | propio: ").append(dinero(p.getCostoUnitario()));
        }
        sb.append(" | costo unitario: ").append(dinero(total));
        if (nivel > 0) {
            sb.append(" | subtotal: ")
              .append(dinero(total.multiply(BigDecimal.valueOf(cantidad))));
        }
        sb.append("\n");
        for (Componente c : p.getComponentes()) {
            desglosar(c.getProducto(), c.getCantidad(), nivel + 1, sb);
        }
    }

    // ------------------------------------------------------------------
    // Materiales base acumulados (apoya el reporte)
    // ------------------------------------------------------------------
    public Map<String, Long> materialesBase(String codigo) {
        Map<String, Long> acumulado = new LinkedHashMap<String, Long>();
        acumularBase(obtener(codigo), 1L, acumulado);
        return acumulado;
    }

    private void acumularBase(Producto p, long multiplicador, Map<String, Long> acumulado) {
        if (!p.esCompuesto()) {
            Long actual = acumulado.get(p.getCodigo());
            acumulado.put(p.getCodigo(), (actual == null ? 0L : actual) + multiplicador);
            return;
        }
        for (Componente c : p.getComponentes()) {
            acumularBase(c.getProducto(), multiplicador * c.getCantidad(), acumulado);
        }
    }

    // ------------------------------------------------------------------
    // RF07: componentes usados directamente por dos o mas productos
    // ------------------------------------------------------------------
    public Map<String, List<String>> componentesCompartidos() {
        Map<String, Set<String>> usos = new LinkedHashMap<String, Set<String>>();
        for (Producto p : productos.values()) {
            for (Componente c : p.getComponentes()) {
                Set<String> padres = usos.get(c.getProducto().getCodigo());
                if (padres == null) {
                    padres = new LinkedHashSet<String>();
                    usos.put(c.getProducto().getCodigo(), padres);
                }
                padres.add(p.getCodigo());
            }
        }
        Map<String, List<String>> compartidos = new LinkedHashMap<String, List<String>>();
        for (Map.Entry<String, Set<String>> e : usos.entrySet()) {
            if (e.getValue().size() >= 2) {
                compartidos.put(e.getKey(), new ArrayList<String>(e.getValue()));
            }
        }
        return compartidos;
    }

    // ------------------------------------------------------------------
    // RF10: reporte del costo estimado de fabricacion
    // ------------------------------------------------------------------
    public String reporte(String codigo) {
        Producto p = obtener(codigo);
        StringBuilder sb = new StringBuilder();
        sb.append("=== REPORTE DE COSTO ESTIMADO DE FABRICACION ===\n");
        sb.append("Producto: ").append(p.getNombre()).append(" (").append(p.getCodigo()).append(")\n\n");
        sb.append("Desglose por niveles:\n").append(desglose(codigo)).append("\n");
        sb.append("Materiales base requeridos:\n");
        for (Map.Entry<String, Long> e : materialesBase(codigo).entrySet()) {
            Producto base = obtener(e.getKey());
            BigDecimal subtotal = base.getCostoUnitario().multiply(BigDecimal.valueOf(e.getValue()));
            sb.append("  ").append(e.getValue()).append(" x ").append(base.getNombre())
              .append(" (").append(base.getCodigo()).append(") = ").append(dinero(subtotal)).append("\n");
        }
        sb.append("\nCOSTO TOTAL ESTIMADO: ").append(dinero(calcularCosto(codigo))).append("\n");
        return sb.toString();
    }

    public static String dinero(BigDecimal valor) {
        return valor.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    // ------------------------------------------------------------------
    // Datos de ejemplo (computadora de escritorio y servidor)
    // ------------------------------------------------------------------
    public void cargarDatosEjemplo() {
        registrarProducto("MEM", "Modulo de memoria 8GB", new BigDecimal("80"));
        registrarProducto("SSD", "Unidad de estado solido 512GB", new BigDecimal("120"));
        registrarProducto("PROC", "Unidad central de proceso", new BigDecimal("200"));
        registrarProducto("PCB", "Circuito impreso base", new BigDecimal("150"));
        registrarProducto("TORN", "Tornillo estandar", new BigDecimal("0.50"));
        registrarProducto("FUEN", "Fuente de poder", new BigDecimal("90"));
        registrarProducto("CABL", "Cable de datos", new BigDecimal("5"));
        registrarProducto("ALMA", "Modulo de almacenamiento", new BigDecimal("15"));
        registrarProducto("PLACA", "Placa base ensamblada", new BigDecimal("40"));
        registrarProducto("DESK", "Estacion de trabajo", new BigDecimal("60"));
        registrarProducto("SERV", "Equipo servidor basico", new BigDecimal("80"));

        agregarComponente("ALMA", "SSD", 1);
        agregarComponente("ALMA", "CABL", 1);
        agregarComponente("ALMA", "TORN", 4);

        agregarComponente("PLACA", "PCB", 1);
        agregarComponente("PLACA", "PROC", 1);
        agregarComponente("PLACA", "MEM", 2);
        agregarComponente("PLACA", "TORN", 6);

        agregarComponente("DESK", "PLACA", 1);
        agregarComponente("DESK", "ALMA", 2);
        agregarComponente("DESK", "FUEN", 1);
        agregarComponente("DESK", "TORN", 8);

        agregarComponente("SERV", "PLACA", 1);
        agregarComponente("SERV", "ALMA", 4);
        agregarComponente("SERV", "FUEN", 2);
    }
}
