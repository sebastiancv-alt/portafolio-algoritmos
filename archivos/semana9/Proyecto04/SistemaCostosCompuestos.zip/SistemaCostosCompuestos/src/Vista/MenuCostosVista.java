package Vista;

import DAO.CostosDAO;
import Modelo.Componente;
import Modelo.Producto;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Interfaz de consola: solicita informacion y muestra el desglose de costos.
 */
public class MenuCostosVista {

    private final Scanner teclado;
    private final CostosDAO dao;

    public MenuCostosVista() {
        teclado = new Scanner(System.in);
        dao = new CostosDAO();
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerOpcion();
            try {
                switch (opcion) {
                    case 1:
                        registrar();
                        break;
                    case 2:
                        componer();
                        break;
                    case 3:
                        listar();
                        break;
                    case 4:
                        calcular();
                        break;
                    case 5:
                        compartidos();
                        break;
                    case 6:
                        verificarCiclos();
                        break;
                    case 7:
                        dao.cargarDatosEjemplo();
                        System.out.println("Datos de ejemplo cargados (DESK, SERV, PLACA, ALMA y componentes).");
                        break;
                    case 8:
                        ejecutarPruebas();
                        break;
                    case 0:
                        System.out.println("Fin del programa.");
                        break;
                    default:
                        System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (StackOverflowError e) {
                System.out.println("La estructura es demasiado profunda para el calculo recursivo.");
            }
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE CALCULO DE COSTOS DE PRODUCTOS COMPUESTOS ===");
        System.out.println("1. Registrar producto o componente basico");
        System.out.println("2. Definir estructura de composicion");
        System.out.println("3. Consultar productos registrados");
        System.out.println("4. Calcular costo total y reporte detallado");
        System.out.println("5. Identificar componentes compartidos");
        System.out.println("6. Detectar ciclos en la estructura");
        System.out.println("7. Cargar conjunto de datos de demostracion");
        System.out.println("8. Ejecutar suite de pruebas unitarias");
        System.out.println("0. Salir");
        System.out.print("Opcion: ");
    }

    private int leerOpcion() {
        if (!teclado.hasNextLine()) {
            return 0;
        }
        try {
            return Integer.parseInt(teclado.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine();
    }

    private BigDecimal leerDecimal(String mensaje) {
        try {
            return new BigDecimal(leerTexto(mensaje).trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Debe ingresar un numero valido.");
        }
    }

    private int leerEntero(String mensaje) {
        try {
            return Integer.parseInt(leerTexto(mensaje).trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Debe ingresar un numero entero valido.");
        }
    }

    private void registrar() {
        String codigo = leerTexto("Codigo unico: ");
        String nombre = leerTexto("Nombre: ");
        BigDecimal costo = leerDecimal("Costo unitario propio (>= 0): ");
        Producto p = dao.registrarProducto(codigo, nombre, costo);
        System.out.println("Registrado: " + p.getNombre() + " (" + p.getCodigo() + ")");
    }

    private void componer() {
        String padre = leerTexto("Codigo del producto compuesto: ");
        String hijo = leerTexto("Codigo del componente: ");
        int cantidad = leerEntero("Cantidad requerida (> 0): ");
        dao.agregarComponente(padre, hijo, cantidad);
        System.out.println("Composicion registrada.");
    }

    private void listar() {
        if (dao.listar().isEmpty()) {
            System.out.println("No hay elementos registrados.");
            return;
        }
        System.out.println("\n--- ELEMENTOS ---");
        for (Producto p : dao.listar()) {
            System.out.println(p.getCodigo() + " - " + p.getNombre()
                    + " | costo propio: " + CostosDAO.dinero(p.getCostoUnitario())
                    + (p.esCompuesto() ? " | COMPUESTO" : " | BASICO"));
            for (Componente c : p.getComponentes()) {
                System.out.println("      " + c.getCantidad() + " x "
                        + c.getProducto().getNombre() + " (" + c.getProducto().getCodigo() + ")");
            }
        }
    }

    private void calcular() {
        String codigo = leerTexto("Codigo del producto: ");
        System.out.println();
        System.out.print(dao.reporte(codigo));
    }

    private void compartidos() {
        Map<String, List<String>> mapa = dao.componentesCompartidos();
        if (mapa.isEmpty()) {
            System.out.println("No hay componentes compartidos entre productos.");
            return;
        }
        System.out.println("\n--- COMPONENTES COMPARTIDOS ---");
        for (Map.Entry<String, List<String>> e : mapa.entrySet()) {
            System.out.println(e.getKey() + " (" + dao.obtener(e.getKey()).getNombre()
                    + ") es usado por: " + e.getValue());
        }
    }

    private void verificarCiclos() {
        if (dao.tieneCiclos()) {
            System.out.println("ATENCION: la estructura contiene ciclos.");
        } else {
            System.out.println("La estructura no contiene ciclos.");
        }
    }

    // ------------------------------------------------------------------
    // Casos de prueba (usan su propio DAO para no alterar los datos del usuario)
    // ------------------------------------------------------------------
    private int correctas;
    private int total;

    private void verificar(String descripcion, boolean ok) {
        total++;
        if (ok) {
            correctas++;
        }
        System.out.println((ok ? "[OK]    " : "[FALLO] ") + descripcion);
    }

    private void ejecutarPruebas() {
        correctas = 0;
        total = 0;
        CostosDAO t = new CostosDAO();
        t.cargarDatosEjemplo();

        System.out.println("\n--- CASOS DE PRUEBA ---");
        verificar("Costo de TORN (basico) = 0.50", CostosDAO.dinero(t.calcularCosto("TORN")).equals("0.50"));
        verificar("Costo de ALMA = 142.00", CostosDAO.dinero(t.calcularCosto("ALMA")).equals("142.00"));
        verificar("Costo de PLACA = 553.00", CostosDAO.dinero(t.calcularCosto("PLACA")).equals("553.00"));
        verificar("Costo de DESK = 991.00", CostosDAO.dinero(t.calcularCosto("DESK")).equals("991.00"));
        verificar("Costo de SERV = 1381.00", CostosDAO.dinero(t.calcularCosto("SERV")).equals("1381.00"));
        verificar("TORN es compartido por 3 elementos",
                t.componentesCompartidos().get("TORN") != null
                && t.componentesCompartidos().get("TORN").size() == 3);
        verificar("CABL no es compartido", t.componentesCompartidos().get("CABL") == null);
        verificar("DESK requiere 22 tornillos en total (8 + 6 + 2 x 4)",
                Long.valueOf(22L).equals(t.materialesBase("DESK").get("TORN")));
        verificar("La estructura de ejemplo no tiene ciclos", !t.tieneCiclos());

        verificar("Rechaza ciclo ALMA -> DESK", falla(t, "ALMA", "DESK", 1));
        verificar("Rechaza autorreferencia ALMA -> ALMA", falla(t, "ALMA", "ALMA", 1));
        verificar("Rechaza cantidad negativa", falla(t, "DESK", "CABL", -2));
        verificar("Rechaza codigo inexistente", falla(t, "DESK", "XXX", 1));

        boolean costoNegativo = false;
        try {
            t.registrarProducto("NEG", "Negativo", new BigDecimal("-5"));
        } catch (IllegalArgumentException e) {
            costoNegativo = true;
        }
        verificar("Rechaza costo negativo", costoNegativo);

        boolean duplicado = false;
        try {
            t.registrarProducto("pc", "Duplicado", BigDecimal.ONE);
        } catch (IllegalArgumentException e) {
            duplicado = true;
        }
        verificar("Rechaza codigo duplicado", duplicado);

        System.out.println("Pruebas correctas: " + correctas + " de " + total);
    }

    private boolean falla(CostosDAO t, String padre, String hijo, int cantidad) {
        try {
            t.agregarComponente(padre, hijo, cantidad);
            return false;
        } catch (IllegalArgumentException e) {
            return true;
        }
    }
}
