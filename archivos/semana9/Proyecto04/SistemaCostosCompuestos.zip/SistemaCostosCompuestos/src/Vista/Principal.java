package Vista;

public class Principal {

    public static void main(String[] args) {
        MenuCostosVista vista = new MenuCostosVista();
        vista.iniciar();
    }
}
