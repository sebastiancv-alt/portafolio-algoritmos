PROYECTO 03 - EvaluadorFormulasNegocio (Algoritmos y Estructura de Datos - UPLA)

COMO ABRIR EN NETBEANS
  File > Open Project > seleccionar la carpeta del proyecto > clic derecho > Run (F6).
  Clase principal: Vista.Principal
  (Alternativa: crear un proyecto Java Application, crear los paquetes Modelo, DAO y
   Vista y copiar los .java de src/<paquete>/ en cada paquete.)

ESTRUCTURA
  Modelo/Expresion.java            Almacena la expresion y el resultado.
  DAO/EvaluadorDAO.java            Analizador recursivo descendente.
  Vista/MenuEvaluadorVista.java    Menu de consola, historial y pruebas.
  Vista/Principal.java             Inicia la aplicacion.

GRAMATICA (recursividad)
  expresion := termino { (+|-) termino }
  termino   := factor  { (*|/) factor }
  factor    := (+|-) factor | numero | '(' expresion ')'

  factor() invoca a expresion() al encontrar '(' -> parentesis anidados.

COMPLEJIDAD
  Tiempo: O(n), n = longitud de la expresion (cada caracter se consume una vez).
  Espacio: O(d), d = profundidad de anidamiento (marcos de la pila de llamadas).
  Se limita la longitud (500) y la anidacion (200) para evitar StackOverflowError.

NOTA EMPRESARIAL
  Prototipo academico con double. Para calculos financieros reales usar BigDecimal
  y definir redondeo monetario.
