package Modelo;

/**
 * Almacena la expresion matematica ingresada y su resultado.
 */
public class Expresion {

    private final String expresion;
    private double resultado;

    public Expresion(String expresion) {
        if (expresion == null || expresion.trim().isEmpty()) {
            throw new IllegalArgumentException("La expresion no puede estar vacia.");
        }
        this.expresion = expresion.trim();
    }

    public String getExpresion() {
        return expresion;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }
}
