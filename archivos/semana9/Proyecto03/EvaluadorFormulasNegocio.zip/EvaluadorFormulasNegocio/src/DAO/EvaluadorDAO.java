package DAO;

/**
 * Analizador recursivo descendente para expresiones aritmeticas.
 *
 * Gramatica:
 *   expresion := termino { ('+' | '-') termino }
 *   termino   := factor  { ('*' | '/') factor }
 *   factor    := ('+' | '-') factor | numero | '(' expresion ')'
 *
 * Cuando factor() encuentra '(' invoca a expresion(), lo que permite
 * procesar parentesis anidados (recursividad estructural).
 */
public class EvaluadorDAO {

    private static final int LONGITUD_MAXIMA = 500;
    private static final int PROFUNDIDAD_MAXIMA = 200;

    // Estado del analisis de la expresion actual
    private String texto;
    private int pos;
    private int profundidad;

    /**
     * Valida y evalua la expresion.
     *
     * @throws IllegalArgumentException si la sintaxis es invalida
     * @throws ArithmeticException      si hay division por cero
     */
    public double evaluar(String expresion) {
        validar(expresion);

        this.texto = expresion.replaceAll("\\s+", "");
        this.pos = 0;
        this.profundidad = 0;

        double valor = expresion();

        if (pos < texto.length()) {
            char c = texto.charAt(pos);
            if (c == ')') {
                throw new IllegalArgumentException(
                        "Parentesis de cierre sin su apertura (posicion " + (pos + 1) + ").");
            }
            throw new IllegalArgumentException(
                    "Simbolo inesperado '" + c + "' (posicion " + (pos + 1) + ").");
        }
        return valor;
    }


    /**
     * RF10: valida una expresion SIN incorporarla a ningun proceso.
     * Revisa longitud, simbolos, parentesis, sintaxis y division por cero.
     *
     * @return "VALIDA" o "INVALIDA: motivo"
     */
    public String validarExpresion(String expresion) {
        try {
            evaluar(expresion);
            return "VALIDA";
        } catch (ArithmeticException e) {
            return "INVALIDA: " + e.getMessage();
        } catch (IllegalArgumentException e) {
            return "INVALIDA: " + e.getMessage();
        } catch (StackOverflowError e) {
            return "INVALIDA: excede la profundidad permitida.";
        }
    }

    /**
     * Regla comercial del enunciado:  Pf = (Pb - D) * (1 + I)
     * Pb = precio base, D = descuento monetario, I = tasa de impuesto (0.18 = 18%).
     * La formula se construye como texto y se evalua con el analizador recursivo.
     */
    public double precioFinal(double pb, double d, double i) {
        if (pb < 0 || d < 0 || i < 0) {
            throw new IllegalArgumentException("Pb, D e I deben ser no negativos.");
        }
        if (d > pb) {
            throw new IllegalArgumentException("El descuento no puede superar el precio base.");
        }
        return evaluar("(" + plano(pb) + " - " + plano(d) + ") * (1 + " + plano(i) + ")");
    }

    private String plano(double v) {
        return new java.math.BigDecimal(Double.toString(v)).toPlainString();
    }

    /** RF06 / RF10: validaciones previas a la evaluacion. */
    private void validar(String expresion) {
        if (expresion == null || expresion.trim().isEmpty()) {
            throw new IllegalArgumentException("La expresion no puede estar vacia.");
        }
        if (expresion.length() > LONGITUD_MAXIMA) {
            throw new IllegalArgumentException(
                    "La expresion supera el limite de " + LONGITUD_MAXIMA + " caracteres.");
        }
        int balance = 0;
        for (int i = 0; i < expresion.length(); i++) {
            char c = expresion.charAt(i);
            if (!(Character.isDigit(c) || c == '.' || c == '+' || c == '-'
                    || c == '*' || c == '/' || c == '(' || c == ')'
                    || Character.isWhitespace(c))) {
                throw new IllegalArgumentException("Caracter no permitido: '" + c + "'.");
            }
            if (c == '(') {
                balance++;
            } else if (c == ')') {
                balance--;
                if (balance < 0) {
                    throw new IllegalArgumentException(
                            "Parentesis de cierre sin su apertura.");
                }
            }
        }
        if (balance > 0) {
            throw new IllegalArgumentException("Parentesis sin cerrar.");
        }
    }

    // expresion := termino { ('+' | '-') termino }
    private double expresion() {
        double valor = termino();
        while (pos < texto.length()
                && (texto.charAt(pos) == '+' || texto.charAt(pos) == '-')) {
            char operador = texto.charAt(pos++);
            double derecho = termino();
            valor = (operador == '+') ? valor + derecho : valor - derecho;
        }
        return valor;
    }

    // termino := factor { ('*' | '/') factor }
    private double termino() {
        double valor = factor();
        while (pos < texto.length()
                && (texto.charAt(pos) == '*' || texto.charAt(pos) == '/')) {
            char operador = texto.charAt(pos++);
            double derecho = factor();
            if (operador == '*') {
                valor = valor * derecho;
            } else {
                if (derecho == 0) {
                    throw new ArithmeticException("Division por cero.");
                }
                valor = valor / derecho;
            }
        }
        return valor;
    }

    // factor := ('+'|'-') factor | numero | '(' expresion ')'
    private double factor() {
        if (pos >= texto.length()) {
            throw new IllegalArgumentException("La expresion esta incompleta.");
        }

        char c = texto.charAt(pos);

        // Signo unario
        if (c == '-') {
            pos++;
            return -factor();
        }
        if (c == '+') {
            pos++;
            return factor();
        }

        // Parentesis: llamada recursiva a expresion()
        if (c == '(') {
            pos++;
            profundidad++;
            if (profundidad > PROFUNDIDAD_MAXIMA) {
                throw new IllegalArgumentException(
                        "Demasiados parentesis anidados (maximo " + PROFUNDIDAD_MAXIMA + ").");
            }
            double valor = expresion();
            if (pos >= texto.length() || texto.charAt(pos) != ')') {
                throw new IllegalArgumentException("Parentesis sin cerrar.");
            }
            pos++; // consume ')'
            profundidad--;
            return valor;
        }

        // Numero
        if (Character.isDigit(c) || c == '.') {
            return numero();
        }

        throw new IllegalArgumentException(
                "Expresion mal formada: se esperaba un numero o '(' y se encontro '"
                + c + "' (posicion " + (pos + 1) + ").");
    }

    private double numero() {
        int inicio = pos;
        boolean punto = false;
        while (pos < texto.length()
                && (Character.isDigit(texto.charAt(pos)) || texto.charAt(pos) == '.')) {
            if (texto.charAt(pos) == '.') {
                if (punto) {
                    throw new IllegalArgumentException(
                            "Numero mal formado (dos puntos decimales).");
                }
                punto = true;
            }
            pos++;
        }
        String s = texto.substring(inicio, pos);
        if (s.equals(".")) {
            throw new IllegalArgumentException("Numero mal formado.");
        }
        return Double.parseDouble(s);
    }
}
