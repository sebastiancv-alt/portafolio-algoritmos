package Vista;

import DAO.EvaluadorDAO;
import Modelo.Expresion;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 * Interfaz de consola: solicita expresiones y muestra resultados.
 */
public class MenuEvaluadorVista {

    private final Scanner teclado;
    private final EvaluadorDAO dao;
    private final List<Expresion> historial;

    public MenuEvaluadorVista() {
        teclado = new Scanner(System.in);
        dao = new EvaluadorDAO();
        historial = new ArrayList<Expresion>();
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerOpcion();
            switch (opcion) {
                case 1:
                    evaluarExpresion();
                    break;
                case 2:
                    mostrarHistorial();
                    break;
                case 3:
                    ejecutarPruebas();
                    break;
                case 4:
                    validarSolo();
                    break;
                case 5:
                    calcularPrecioFinal();
                    break;
                case 0:
                    System.out.println("Fin del programa.");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n=== EVALUADOR DE FORMULAS Y REGLAS DE NEGOCIO ===");
        System.out.println("1. Evaluar formula o expresion");
        System.out.println("2. Consultar historial de evaluaciones");
        System.out.println("3. Ejecutar suite de pruebas");
        System.out.println("4. Validar sintaxis de expresion");
        System.out.println("5. Precio final = (Pb - D) * (1 + I)");
        System.out.println("0. Salir");
        System.out.print("Opcion: ");
    }

    private int leerOpcion() {
        if (!teclado.hasNextLine()) {
            return 0;
        }
        try {
            return Integer.parseInt(teclado.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void evaluarExpresion() {
        System.out.println("Operadores: + - * /  y parentesis. Ejemplo: (100 - 10) * (1 + 0.18)");
        System.out.print("Ingrese la expresion: ");
        String texto = teclado.nextLine();

        try {
            Expresion modelo = new Expresion(texto);
            double resultado = dao.evaluar(modelo.getExpresion());
            modelo.setResultado(resultado);
            historial.add(modelo);

            System.out.println("\n--- RESULTADO ---");
            System.out.println("Expresion = " + modelo.getExpresion());
            System.out.println("Resultado = " + formatear(modelo.getResultado()));
        } catch (ArithmeticException e) {
            System.out.println("Error matematico: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Error de sintaxis: " + e.getMessage());
        } catch (StackOverflowError e) {
            System.out.println("La expresion excedio la capacidad de la pila.");
        }
    }

    /** RF10: validar antes de incorporar la expresion a un proceso comercial. */
    private void validarSolo() {
        System.out.print("Ingrese la expresion a validar: ");
        String texto = teclado.nextLine();
        System.out.println("Expresion: " + texto);
        System.out.println("Estado   : " + dao.validarExpresion(texto));
    }

    /** Ejemplo del enunciado: Pf = (Pb - D) * (1 + I). */
    private void calcularPrecioFinal() {
        try {
            System.out.print("Precio base Pb: ");
            double pb = Double.parseDouble(teclado.nextLine().trim());
            System.out.print("Descuento monetario D: ");
            double d = Double.parseDouble(teclado.nextLine().trim());
            System.out.print("Tasa de impuesto I (ej. 0.18 = 18%): ");
            double i = Double.parseDouble(teclado.nextLine().trim());

            double pf = dao.precioFinal(pb, d, i);
            String expr = "(" + formatear(pb) + " - " + formatear(d) + ") * (1 + " + formatear(i) + ")";
            Expresion modelo = new Expresion(expr);
            modelo.setResultado(pf);
            historial.add(modelo);

            System.out.println("\n--- PRECIO FINAL ---");
            System.out.println("Expresion = " + expr);
            System.out.println("Pf        = " + formatear(pf));
        } catch (NumberFormatException e) {
            System.out.println("Error: debe ingresar valores numericos.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void mostrarHistorial() {
        if (historial.isEmpty()) {
            System.out.println("Aun no hay evaluaciones en esta sesion.");
            return;
        }
        System.out.println("\n--- HISTORIAL ---");
        int i = 1;
        for (Expresion m : historial) {
            System.out.println(i++ + ") " + m.getExpresion()
                    + " = " + formatear(m.getResultado()));
        }
    }

    /** Casos de prueba: {expresion, resultado esperado o ERROR}. */
    private void ejecutarPruebas() {
        String[][] casos = {
            {"2 + 3 * 4", "14"},
            {"(2 + 3) * 4", "20"},
            {"((2 + 3) * (4 - 1)) / 5", "3"},
            {"(100 - 10) * (1 + 0.18)", "106.2"},
            {"-(3 + 2) * 2", "-10"},
            {"10 / 4", "2.5"},
            {"((((7))))", "7"},
            {"10 / (5 - 5)", "ERROR"},
            {"(2 + 3", "ERROR"},
            {"2 + 3)", "ERROR"},
            {"2 + * 3", "ERROR"},
            {"2 $ 3", "ERROR"},
            {"", "ERROR"},
            {"(1 + 2) * ((3 + 4) * (5 - 2)) - 10 / (4 / 2)", "58"},
            {"(1000 - 100) * (1 + 0.18)", "1062"},
            {"abc", "ERROR"}
        };

        System.out.println("\n--- CASOS DE PRUEBA ---");
        int correctos = 0;
        for (String[] caso : casos) {
            String obtenido;
            try {
                obtenido = formatear(dao.evaluar(caso[0]));
            } catch (RuntimeException e) {
                obtenido = "ERROR";
            }
            boolean ok = obtenido.equals(caso[1]);
            if (ok) {
                correctos++;
            }
            System.out.println((ok ? "[OK]    " : "[FALLO] ") + "\"" + caso[0]
                    + "\" -> esperado: " + caso[1] + " | obtenido: " + obtenido);
        }
        System.out.println("Pruebas correctas: " + correctos + " de " + casos.length);
    }

    private String formatear(double valor) {
        if (valor == Math.rint(valor) && Math.abs(valor) < 1e15) {
            return String.valueOf((long) valor);
        }
        String s = String.format(Locale.US, "%.6f", valor);
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}
