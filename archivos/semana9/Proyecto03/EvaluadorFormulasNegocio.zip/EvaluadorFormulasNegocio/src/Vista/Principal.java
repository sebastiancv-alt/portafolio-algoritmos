package Vista;

public class Principal {

    public static void main(String[] args) {
        MenuEvaluadorVista vista = new MenuEvaluadorVista();
        vista.iniciar();
    }
}
