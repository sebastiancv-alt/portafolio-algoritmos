package DAO;

import Modelo.Proyecto;
import Modelo.Tarea;
import Modelo.Tarea.Estado;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Registra dependencias, recorre el grafo y detecta ciclos.
 *
 * Direccion de las aristas: TAREA -> PREREQUISITO.
 * (si T05 requiere T04, la arista es T05 -> T04).
 */
public class DependenciasTareasDAO {

    private final Proyecto proyecto;

    public DependenciasTareasDAO(Proyecto proyecto) {
        this.proyecto = proyecto;
    }

    public Proyecto getProyecto() {
        return proyecto;
    }

    // ------------------------------------------------------------------
    // RF01 - RF02: registro
    // ------------------------------------------------------------------

    public void registrarTarea(String codigo, String descripcion, Estado estado) {
        Tarea tarea = new Tarea(codigo, descripcion, estado);
        if (!proyecto.agregar(tarea)) {
            throw new IllegalArgumentException(
                "Ya existe una tarea con el codigo " + tarea.getCodigo() + ".");
        }
    }

    /** Registra que {@code codigoTarea} requiere a {@code codigoPrerequisito}. */
    public void registrarDependencia(String codigoTarea, String codigoPrerequisito) {
        Tarea tarea = requerir(codigoTarea);
        Tarea prerequisito = requerir(codigoPrerequisito);

        if (tarea.getCodigo().equals(prerequisito.getCodigo())) {
            throw new IllegalArgumentException("Una tarea no puede depender de si misma.");
        }
        if (!tarea.agregarPrerequisito(prerequisito.getCodigo())) {
            throw new IllegalArgumentException("Esa dependencia ya estaba registrada.");
        }
    }

    public void cambiarEstado(String codigo, Estado nuevoEstado) {
        requerir(codigo).setEstado(nuevoEstado);
    }

    // ------------------------------------------------------------------
    // RF03: dependencias directas
    // ------------------------------------------------------------------

    public List<String> dependenciasDirectas(String codigo) {
        return new ArrayList<>(requerir(codigo).getPrerequisitos());
    }

    // ------------------------------------------------------------------
    // RF04: dependencias indirectas (recursivo)
    // ------------------------------------------------------------------

    /** Todas las tareas de las que depende (directa o indirectamente) la tarea indicada. */
    public List<String> todasLasDependencias(String codigo) {
        requerir(codigo);
        Set<String> visitados = new LinkedHashSet<>();
        recolectar(normalizar(codigo), visitados);
        return new ArrayList<>(visitados);
    }

    private void recolectar(String codigo, Set<String> visitados) {
        for (String prerequisito : proyecto.obtener(codigo).getPrerequisitos()) {
            if (visitados.add(prerequisito)) {      // evita repetir y protege ante ciclos
                recolectar(prerequisito, visitados);
            }
        }
    }

    /** Arbol de dependencias con sangria, una linea por relacion. */
    public List<String> arbolDependencias(String codigo) {
        requerir(codigo);
        List<String> lineas = new ArrayList<>();
        Set<String> ruta = new LinkedHashSet<>();
        String raiz = normalizar(codigo);
        ruta.add(raiz);
        construirArbol(raiz, 1, ruta, lineas);
        return lineas;
    }

    private void construirArbol(String codigo, int nivel, Set<String> ruta, List<String> lineas) {
        String sangria = "    ".repeat(nivel);
        for (String prerequisito : proyecto.obtener(codigo).getPrerequisitos()) {
            Tarea t = proyecto.obtener(prerequisito);
            if (ruta.contains(prerequisito)) {
                lineas.add(sangria + "+-- " + t + "  <-- CICLO");
                continue;
            }
            lineas.add(sangria + "+-- " + t);
            ruta.add(prerequisito);
            construirArbol(prerequisito, nivel + 1, ruta, lineas);
            ruta.remove(prerequisito);
        }
    }

    // ------------------------------------------------------------------
    // RF05: profundidad maxima con RECURSIVIDAD ANIDADA ESTRICTA
    // ------------------------------------------------------------------

    /**
     * Profundidad de la cadena de prerequisitos mas larga que parte de la tarea.
     * Una tarea sin prerequisitos tiene profundidad 0.
     *
     * @throws IllegalStateException si hay un ciclo alcanzable desde la tarea
     */
    public int profundidadMaxima(String codigo) {
        requerir(codigo);
        String id = normalizar(codigo);
        List<String> ciclo = buscarCiclo(id, new LinkedHashSet<>(), new LinkedHashSet<>(),
                                         new ArrayList<>());
        if (ciclo != null) {
            throw new IllegalStateException(
                "No se puede calcular la profundidad: hay un ciclo (" + String.join(" -> ", ciclo) + ").");
        }
        return profundidad(id, 0, 0);
    }

    /**
     * Recorre los prerequisitos de {@code codigo} desde el indice {@code i}.
     *
     * f(codigo, i, acum) = acum                                                  si i == total
     * f(codigo, i, acum) = f(codigo, i+1, max(acum, 1 + f(hijo_i, 0, 0)))        en otro caso
     *
     * La llamada interior f(hijo_i, 0, 0) se evalua primero y su resultado pasa a ser
     * parte del argumento de la llamada exterior: recursividad anidada.
     *
     * Terminacion: dentro de una tarea, i crece hasta el total; entre tareas se avanza
     * hacia prerequisitos y, al no haber ciclos (validado antes), la cadena es finita.
     */
    private int profundidad(String codigo, int i, int acumulado) {
        List<String> hijos = new ArrayList<>(proyecto.obtener(codigo).getPrerequisitos());

        if (i >= hijos.size()) {                      // caso base
            return acumulado;
        }
        return profundidad(                           // llamada exterior
            codigo,
            i + 1,
            Math.max(acumulado, 1 + profundidad(hijos.get(i), 0, 0))   // llamada interior
        );
    }

    // ------------------------------------------------------------------
    // RF06: deteccion de ciclos (DFS con "visitados" y "en exploracion")
    // ------------------------------------------------------------------

    /** @return la ruta del primer ciclo hallado (ej. T01, T02, T01) o lista vacia si no hay. */
    public List<String> detectarCiclo() {
        Set<String> visitados = new LinkedHashSet<>();
        Set<String> enExploracion = new LinkedHashSet<>();
        for (Tarea tarea : proyecto.getTareas()) {
            if (!visitados.contains(tarea.getCodigo())) {
                List<String> ciclo = buscarCiclo(tarea.getCodigo(), visitados,
                                                 enExploracion, new ArrayList<>());
                if (ciclo != null) {
                    return ciclo;
                }
            }
        }
        return new ArrayList<>();
    }

    private List<String> buscarCiclo(String codigo, Set<String> visitados,
                                     Set<String> enExploracion, List<String> ruta) {
        visitados.add(codigo);
        enExploracion.add(codigo);
        ruta.add(codigo);

        for (String prerequisito : proyecto.obtener(codigo).getPrerequisitos()) {
            if (enExploracion.contains(prerequisito)) {         // arista de retorno => ciclo
                List<String> ciclo = new ArrayList<>(
                    ruta.subList(ruta.indexOf(prerequisito), ruta.size()));
                ciclo.add(prerequisito);
                return ciclo;
            }
            if (!visitados.contains(prerequisito)) {
                List<String> ciclo = buscarCiclo(prerequisito, visitados, enExploracion, ruta);
                if (ciclo != null) {
                    return ciclo;
                }
            }
        }

        enExploracion.remove(codigo);
        ruta.remove(ruta.size() - 1);
        return null;
    }

    // ------------------------------------------------------------------
    // RF07 - RF08: bloqueadas y reporte
    // ------------------------------------------------------------------

    /** Tareas PENDIENTES que tienen al menos un prerequisito directo sin completar. */
    public Map<String, List<String>> tareasBloqueadas() {
        Map<String, List<String>> bloqueadas = new LinkedHashMap<>();
        for (Tarea tarea : proyecto.getTareas()) {
            if (tarea.estaCompletada()) {
                continue;
            }
            List<String> faltantes = new ArrayList<>();
            for (String p : tarea.getPrerequisitos()) {
                if (!proyecto.obtener(p).estaCompletada()) {
                    faltantes.add(p);
                }
            }
            if (!faltantes.isEmpty()) {
                bloqueadas.put(tarea.getCodigo(), faltantes);
            }
        }
        return bloqueadas;
    }

    public List<Tarea> tareasCompletadas() {
        List<Tarea> lista = new ArrayList<>();
        for (Tarea t : proyecto.getTareas()) {
            if (t.estaCompletada()) {
                lista.add(t);
            }
        }
        return lista;
    }

    /** Pendientes que pueden iniciarse ya (todos sus prerequisitos estan completados). */
    public List<Tarea> tareasPendientesLibres() {
        Map<String, List<String>> bloqueadas = tareasBloqueadas();
        List<Tarea> lista = new ArrayList<>();
        for (Tarea t : proyecto.getTareas()) {
            if (!t.estaCompletada() && !bloqueadas.containsKey(t.getCodigo())) {
                lista.add(t);
            }
        }
        return lista;
    }

    // ------------------------------------------------------------------
    // Datos de ejemplo (caso de la empresa: autenticacion, clientes, ...)
    // ------------------------------------------------------------------

    public void cargarEjemplo() {
        registrarTarea("TA1", "Servicio de autenticacion de usuarios", Estado.COMPLETADA);
        registrarTarea("TA2", "Gestion de clientes y contactos", Estado.PENDIENTE);
        registrarTarea("TA3", "Control de inventario de productos", Estado.COMPLETADA);
        registrarTarea("TA4", "Proceso de ventas y pedidos", Estado.PENDIENTE);
        registrarTarea("TA5", "Generacion de reportes gerenciales", Estado.PENDIENTE);
        registrarTarea("TA6", "Pruebas de integracion del sistema", Estado.PENDIENTE);

        registrarDependencia("TA2", "TA1");
        registrarDependencia("TA3", "TA1");
        registrarDependencia("TA4", "TA2");
        registrarDependencia("TA4", "TA3");
        registrarDependencia("TA5", "TA4");
        registrarDependencia("TA6", "TA5");
        registrarDependencia("TA6", "TA4");
    }

    // ------------------------------------------------------------------
    // utilidades
    // ------------------------------------------------------------------

    private String normalizar(String codigo) {
        return codigo == null ? "" : codigo.trim().toUpperCase();
    }

    private Tarea requerir(String codigo) {
        Tarea tarea = proyecto.obtener(normalizar(codigo));
        if (tarea == null) {
            throw new IllegalArgumentException("No existe la tarea " + normalizar(codigo) + ".");
        }
        return tarea;
    }
}
