package Vista;

import DAO.DependenciasTareasDAO;
import Modelo.Proyecto;
import Modelo.Tarea;
import Modelo.Tarea.Estado;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Gestiona la interaccion con el usuario por consola. */
public class MenuDependenciasVista {

    private final Scanner teclado;
    private final DependenciasTareasDAO dao;

    public MenuDependenciasVista() {
        teclado = new Scanner(System.in);
        dao = new DependenciasTareasDAO(new Proyecto("Sistema de informacion empresarial"));
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerOpcion();
            try {
                ejecutar(opcion);
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (StackOverflowError e) {
                System.out.println("El recorrido excedio la capacidad de la pila.");
            }
        } while (opcion != 0);
        System.out.println("Fin del programa.");
    }

    private void mostrarMenu() {
        System.out.println("\n=== SISTEMA INTELIGENTE DE ANALISIS DE DEPENDENCIAS DE TAREAS ===");
        System.out.println("1. Registrar nueva tarea");
        System.out.println("2. Definir dependencia entre tareas");
        System.out.println("3. Listar dependencias directas");
        System.out.println("4. Analizar dependencias indirectas (DFS)");
        System.out.println("5. Calcular profundidad maxima de cadena");
        System.out.println("6. Detectar presencia de ciclos");
        System.out.println("7. Identificar tareas bloqueadas");
        System.out.println("8. Generar reporte completo de tareas");
        System.out.println("9. Actualizar estado de tarea");
        System.out.println("10. Cargar datos de demostracion");
        System.out.println("0. Salir");
    }

    private int leerOpcion() {
        System.out.print("Opcion: ");
        try {
            return Integer.parseInt(teclado.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private String leer(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine();
    }

    private void ejecutar(int opcion) {
        switch (opcion) {
            case 1:  registrarTarea();       break;
            case 2:  registrarDependencia(); break;
            case 3:  directas();             break;
            case 4:  indirectas();           break;
            case 5:  profundidad();          break;
            case 6:  ciclos();               break;
            case 7:  bloqueadas();           break;
            case 8:  reporte();              break;
            case 9:  cambiarEstado();        break;
            case 10:
                dao.cargarEjemplo();
                System.out.println("Datos de ejemplo cargados (TA1..TA6).");
                break;
            case 0:  break;
            default: System.out.println("Opcion no valida.");
        }
    }

    private Estado leerEstado() {
        String texto = leer("Estado (P = pendiente, C = completada): ").trim().toUpperCase();
        if (texto.equals("P")) {
            return Estado.PENDIENTE;
        }
        if (texto.equals("C")) {
            return Estado.COMPLETADA;
        }
        throw new IllegalArgumentException("Estado no valido. Use P o C.");
    }

    // RF01
    private void registrarTarea() {
        String codigo = leer("Codigo: ");
        String descripcion = leer("Descripcion: ");
        Estado estado = leerEstado();
        dao.registrarTarea(codigo, descripcion, estado);
        System.out.println("Tarea registrada.");
    }

    // RF02
    private void registrarDependencia() {
        String tarea = leer("Codigo de la tarea que depende: ");
        String prerequisito = leer("Codigo de la tarea prerequisito: ");
        dao.registrarDependencia(tarea, prerequisito);
        System.out.println("Dependencia registrada: " + tarea.trim().toUpperCase()
            + " requiere " + prerequisito.trim().toUpperCase() + ".");
    }

    // RF03
    private void directas() {
        String codigo = leer("Codigo de la tarea: ");
        List<String> lista = dao.dependenciasDirectas(codigo);
        if (lista.isEmpty()) {
            System.out.println("La tarea no tiene dependencias directas.");
        } else {
            System.out.println("Dependencias directas: " + String.join(", ", lista));
        }
    }

    // RF04
    private void indirectas() {
        String codigo = leer("Codigo de la tarea: ");
        List<String> arbol = dao.arbolDependencias(codigo);
        if (arbol.isEmpty()) {
            System.out.println("La tarea no tiene dependencias.");
            return;
        }
        System.out.println(codigo.trim().toUpperCase());
        arbol.forEach(System.out::println);
        System.out.println("Total de tareas distintas de las que depende: "
            + dao.todasLasDependencias(codigo).size());
    }

    // RF05
    private void profundidad() {
        String codigo = leer("Codigo de la tarea: ");
        int p = dao.profundidadMaxima(codigo);
        System.out.println("Profundidad maxima de la cadena de " + codigo.trim().toUpperCase()
            + ": " + p);
    }

    // RF06
    private void ciclos() {
        List<String> ciclo = dao.detectarCiclo();
        if (ciclo.isEmpty()) {
            System.out.println("No se detectaron ciclos. La planificacion es valida.");
        } else {
            System.out.println("CICLO DETECTADO: " + String.join(" requiere ", ciclo));
        }
    }

    // RF07
    private void bloqueadas() {
        Map<String, List<String>> bloqueadas = dao.tareasBloqueadas();
        if (bloqueadas.isEmpty()) {
            System.out.println("No hay tareas bloqueadas.");
            return;
        }
        bloqueadas.forEach((tarea, faltantes) ->
            System.out.println(tarea + " bloqueada por: " + String.join(", ", faltantes)));
    }

    // RF08
    private void reporte() {
        System.out.println("\n--- REPORTE DE TAREAS ---");
        System.out.println("Total de tareas: " + dao.getProyecto().cantidadTareas());

        System.out.println("\nCOMPLETADAS:");
        imprimir(dao.tareasCompletadas());

        System.out.println("\nPENDIENTES (listas para iniciar):");
        imprimir(dao.tareasPendientesLibres());

        System.out.println("\nBLOQUEADAS:");
        Map<String, List<String>> bloqueadas = dao.tareasBloqueadas();
        if (bloqueadas.isEmpty()) {
            System.out.println("  (ninguna)");
        } else {
            bloqueadas.forEach((codigo, faltantes) -> System.out.println("  "
                + dao.getProyecto().obtener(codigo) + "  <- espera: " + String.join(", ", faltantes)));
        }
    }

    private void imprimir(List<Tarea> lista) {
        if (lista.isEmpty()) {
            System.out.println("  (ninguna)");
            return;
        }
        lista.forEach(t -> System.out.println("  " + t));
    }

    private void cambiarEstado() {
        String codigo = leer("Codigo de la tarea: ");
        Estado estado = leerEstado();
        dao.cambiarEstado(codigo, estado);
        System.out.println("Estado actualizado.");
    }
}
