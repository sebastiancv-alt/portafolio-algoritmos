package Vista;

public class Principal {

    public static void main(String[] args) {
        MenuDependenciasVista vista = new MenuDependenciasVista();
        vista.iniciar();
    }
}
