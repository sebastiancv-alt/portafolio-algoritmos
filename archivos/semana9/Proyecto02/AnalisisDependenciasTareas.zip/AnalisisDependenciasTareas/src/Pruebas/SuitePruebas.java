package Pruebas;

import DAO.DependenciasTareasDAO;
import Modelo.Proyecto;
import Modelo.Tarea.Estado;

import java.util.Arrays;
import java.util.List;

/** Casos de prueba ejecutables (sin librerias externas). */
public class SuitePruebas {

    private static int ok = 0;
    private static int fallos = 0;

    public static void main(String[] args) {
        System.out.println("=== CASOS DE PRUEBA - AnalisisDependenciasTareas ===");

        DependenciasTareasDAO dao = nuevoEjemplo();

        verificar("CP01 Directas de TA4 = [TA2, TA3]",
            dao.dependenciasDirectas("TA4").equals(Arrays.asList("TA2", "TA3")));

        verificar("CP02 Directas de TA1 = []",
            dao.dependenciasDirectas("TA1").isEmpty());

        verificar("CP03 Indirectas de TA6 = {TA5,TA4,TA2,TA1,TA3}",
            conjuntoIgual(dao.todasLasDependencias("TA6"), "TA5", "TA4", "TA2", "TA1", "TA3"));

        verificar("CP04 Profundidad de TA1 = 0", dao.profundidadMaxima("TA1") == 0);
        verificar("CP05 Profundidad de TA2 = 1", dao.profundidadMaxima("TA2") == 1);
        verificar("CP06 Profundidad de TA4 = 2", dao.profundidadMaxima("TA4") == 2);
        verificar("CP07 Profundidad de TA6 = 4", dao.profundidadMaxima("TA6") == 4);

        verificar("CP08 Grafo de ejemplo sin ciclos", dao.detectarCiclo().isEmpty());

        verificar("CP09 Bloqueadas = {TA4, TA5, TA6}",
            conjuntoIgual(new java.util.ArrayList<>(dao.tareasBloqueadas().keySet()),
                          "TA4", "TA5", "TA6"));

        verificar("CP10 Pendiente libre = {TA2}",
            dao.tareasPendientesLibres().size() == 1
            && dao.tareasPendientesLibres().get(0).getCodigo().equals("TA2"));

        dao.cambiarEstado("TA2", Estado.COMPLETADA);
        verificar("CP11 Al completar TA2, TA4 se desbloquea",
            !dao.tareasBloqueadas().containsKey("TA4"));

        verificar("CP12 Tarea duplicada -> IllegalArgumentException",
            lanza(() -> dao.registrarTarea("t01", "Repetida", Estado.PENDIENTE),
                  IllegalArgumentException.class));

        verificar("CP13 Dependencia a tarea inexistente -> excepcion",
            lanza(() -> dao.registrarDependencia("TA1", "T99"), IllegalArgumentException.class));

        verificar("CP14 Autodependencia -> excepcion",
            lanza(() -> dao.registrarDependencia("TA1", "TA1"), IllegalArgumentException.class));

        verificar("CP15 Dependencia duplicada -> excepcion",
            lanza(() -> dao.registrarDependencia("TA2", "TA1"), IllegalArgumentException.class));

        // Ciclo: TA1 -> TA6 cierra TA1 -> TA6 -> TA5 -> TA4 -> TA2 -> TA1
        dao.registrarDependencia("TA1", "TA6");
        List<String> ciclo = dao.detectarCiclo();
        verificar("CP16 Se detecta el ciclo creado (" + String.join("->", ciclo) + ")",
            !ciclo.isEmpty() && ciclo.get(0).equals(ciclo.get(ciclo.size() - 1)));

        verificar("CP17 Profundidad con ciclo -> IllegalStateException",
            lanza(() -> dao.profundidadMaxima("TA6"), IllegalStateException.class));

        verificar("CP18 El arbol con ciclo termina y lo senala",
            dao.arbolDependencias("TA6").stream().anyMatch(l -> l.contains("CICLO")));

        // Cadena larga: profundidad = n-1
        Proyecto p = new Proyecto("cadena");
        DependenciasTareasDAO cadena = new DependenciasTareasDAO(p);
        int n = 500;
        for (int i = 1; i <= n; i++) {
            cadena.registrarTarea("C" + i, "Tarea " + i, Estado.PENDIENTE);
            if (i > 1) {
                cadena.registrarDependencia("C" + i, "C" + (i - 1));
            }
        }
        verificar("CP19 Cadena de " + n + " tareas: profundidad = " + (n - 1),
            cadena.profundidadMaxima("C" + n) == n - 1);

        System.out.println("\nResultado: " + ok + " correctas, " + fallos + " fallidas.");
        if (fallos > 0) {
            System.exit(1);
        }
    }

    private static DependenciasTareasDAO nuevoEjemplo() {
        DependenciasTareasDAO dao = new DependenciasTareasDAO(new Proyecto("ejemplo"));
        dao.cargarEjemplo();
        return dao;
    }

    private static boolean conjuntoIgual(List<String> obtenido, String... esperado) {
        return obtenido.size() == esperado.length && obtenido.containsAll(Arrays.asList(esperado));
    }

    private static boolean lanza(Runnable accion, Class<? extends Throwable> tipo) {
        try {
            accion.run();
            return false;
        } catch (Throwable t) {
            return tipo.isInstance(t);
        }
    }

    private static void verificar(String nombre, boolean condicion) {
        if (condicion) {
            ok++;
        } else {
            fallos++;
        }
        System.out.println((condicion ? "[OK]    " : "[FALLO] ") + nombre);
    }
}
