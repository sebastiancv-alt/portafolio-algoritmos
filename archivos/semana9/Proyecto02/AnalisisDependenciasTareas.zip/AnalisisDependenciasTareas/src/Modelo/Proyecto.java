package Modelo;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Almacena la lista de tareas del proyecto y, por medio de ellas, sus dependencias. */
public class Proyecto {

    private final String nombre;
    private final Map<String, Tarea> tareas = new LinkedHashMap<>();

    public Proyecto(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean existe(String codigo) {
        return tareas.containsKey(codigo);
    }

    public Tarea obtener(String codigo) {
        return tareas.get(codigo);
    }

    /** @return true si se agrego; false si el codigo ya existia. */
    public boolean agregar(Tarea tarea) {
        if (tareas.containsKey(tarea.getCodigo())) {
            return false;
        }
        tareas.put(tarea.getCodigo(), tarea);
        return true;
    }

    public Collection<Tarea> getTareas() {
        return Collections.unmodifiableCollection(tareas.values());
    }

    public int cantidadTareas() {
        return tareas.size();
    }
}
