package Modelo;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Representa una tarea del proyecto (nodo del grafo dirigido).
 * Las aristas se guardan como codigos de los prerequisitos:
 * "esta tarea requiere que X este completada".
 */
public class Tarea {

    public enum Estado { PENDIENTE, COMPLETADA }

    private final String codigo;
    private final String descripcion;
    private Estado estado;
    private final Set<String> prerequisitos = new LinkedHashSet<>();

    public Tarea(String codigo, String descripcion, Estado estado) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El codigo de la tarea es obligatorio.");
        }
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripcion de la tarea es obligatoria.");
        }
        if (estado == null) {
            throw new IllegalArgumentException("El estado de la tarea es obligatorio.");
        }
        this.codigo = codigo.trim().toUpperCase();
        this.descripcion = descripcion.trim();
        this.estado = estado;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        if (estado == null) {
            throw new IllegalArgumentException("El estado no puede ser nulo.");
        }
        this.estado = estado;
    }

    public Set<String> getPrerequisitos() {
        return Collections.unmodifiableSet(prerequisitos);
    }

    /** @return true si la dependencia se agrego; false si ya existia. */
    public boolean agregarPrerequisito(String codigoPrerequisito) {
        return prerequisitos.add(codigoPrerequisito);
    }

    public boolean estaCompletada() {
        return estado == Estado.COMPLETADA;
    }

    @Override
    public String toString() {
        return codigo + " - " + descripcion + " [" + estado + "]";
    }
}
