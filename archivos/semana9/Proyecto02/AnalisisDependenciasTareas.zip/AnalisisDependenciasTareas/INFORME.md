# Proyecto 02 – Sistema inteligente de análisis de dependencias de tareas
**Proyecto NetBeans:** `AnalisisDependenciasTareas` · **Curso:** Algoritmos y Estructura de Datos · Semana 09

## 1. Arquitectura (igual que el Proyecto 1)

| Paquete | Clase | Responsabilidad |
|---|---|---|
| Modelo | `Tarea.java` | Representa una tarea (código, descripción, estado, prerequisitos) |
| Modelo | `Proyecto.java` | Almacena las tareas del proyecto |
| DAO | `DependenciasTareasDAO.java` | Registra dependencias, recorre el grafo y detecta ciclos |
| Vista | `MenuDependenciasVista.java` | Menú de consola |
| Vista | `Principal.java` | Inicia la aplicación |
| Pruebas | `SuitePruebas.java` | 19 casos de prueba ejecutables |

El grafo es dirigido: la arista **TA5 → TA4** significa "TA5 requiere TA4".

## 2. Requerimientos → implementación

| RF | Método (DAO) | Técnica |
|---|---|---|
| RF01 | `registrarTarea` | Valida código único, descripción y estado |
| RF02 | `registrarDependencia` | Valida existencia, no autodependencia, no duplicada |
| RF03 | `dependenciasDirectas` | Lectura del conjunto de prerequisitos |
| RF04 | `arbolDependencias`, `todasLasDependencias` | Recursividad estructural (DFS) |
| RF05 | `profundidadMaxima` | **Recursividad anidada estricta** |
| RF06 | `detectarCiclo` | DFS con conjuntos *visitados* y *en exploración* |
| RF07 | `tareasBloqueadas` | Pendientes con algún prerequisito directo sin completar |
| RF08 | `tareasCompletadas`, `tareasPendientesLibres`, `tareasBloqueadas` | Reporte en la vista |

## 3. Recursividad anidada (RF05)

```java
private int profundidad(String codigo, int i, int acumulado) {
    List<String> hijos = new ArrayList<>(proyecto.obtener(codigo).getPrerequisitos());
    if (i >= hijos.size()) return acumulado;                 // caso base
    return profundidad(codigo, i + 1,                        // llamada EXTERIOR
           Math.max(acumulado, 1 + profundidad(hijos.get(i), 0, 0)));  // llamada INTERIOR
}
```

Definición: `f(c, i, a) = a` si `i = |hijos|`; `f(c, i, a) = f(c, i+1, max(a, 1 + f(hijo_i, 0, 0)))` en otro caso.
El resultado de la llamada interior `f(hijo_i, 0, 0)` se usa como parte del **argumento** de la llamada exterior (patrón `f(…, f(…))`).

**Traza para TA4** (prerequisitos TA2, TA3; TA2 → TA1; TA3 → TA1):

1. `f(TA4,0,0)` evalúa primero el argumento: `f(TA2,0,0)`
   - `f(TA2,0,0)` evalúa `f(TA1,0,0) = 0` → llama `f(TA2,1,max(0,1+0)) = f(TA2,1,1) = 1`
2. Argumento = `max(0, 1+1) = 2` → `f(TA4,1,2)`
3. Evalúa `f(TA3,0,0) = 1` → argumento `max(2, 1+1) = 2` → `f(TA4,2,2) = 2` (caso base)

**Terminación:** dentro de una tarea `i` crece hasta el total; entre tareas se avanza hacia prerequisitos. Como `profundidadMaxima` valida antes que no existan ciclos alcanzables, la cadena es finita. Con ciclo se lanza `IllegalStateException`.

## 4. Casos de prueba (ejecutados: 19/19 correctos)

Datos de ejemplo: TA1 Autenticación ✔, TA2 Clientes, TA3 Inventario ✔, TA4 Ventas, TA5 Reportes, TA6 Pruebas de integración. Dependencias: TA2→TA1, TA3→TA1, TA4→TA2, TA4→TA3, TA5→TA4, TA6→TA5, TA6→TA4.

| Caso | Entrada | Resultado esperado |
|---|---|---|
| CP01 | Directas de TA4 | TA2, TA3 |
| CP02 | Directas de TA1 | ninguna |
| CP03 | Indirectas de TA6 | TA5, TA4, TA2, TA1, TA3 |
| CP04–CP07 | Profundidad de TA1, TA2, TA4, TA6 | 0, 1, 2, 4 |
| CP08 | Detectar ciclos (ejemplo) | Sin ciclos |
| CP09 | Bloqueadas | TA4, TA5, TA6 |
| CP10 | Pendientes listas | TA2 |
| CP11 | Completar TA2 | TA4 deja de estar bloqueada |
| CP12–CP15 | Tarea duplicada / prerequisito inexistente / autodependencia / dependencia repetida | `IllegalArgumentException` |
| CP16 | Agregar TA1→TA6 | Ciclo TA1→TA6→TA5→TA4→TA2→TA1 |
| CP17 | Profundidad con ciclo | `IllegalStateException` |
| CP18 | Árbol con ciclo | Termina y marca `<-- CICLO` |
| CP19 | Cadena de 500 tareas | Profundidad 499 |

## 5. Análisis de complejidad (V = tareas, E = dependencias)

| Operación | Tiempo | Espacio |
|---|---|---|
| Registrar tarea / dependencia | O(1) | O(1) |
| Dependencias directas | O(k), k = prerequisitos de la tarea | O(k) |
| Dependencias indirectas (conjunto) | O(V + E) | O(V) |
| Árbol de dependencias | O(caminos); peor caso exponencial en grafos con muchos "rombos" | O(h) pila |
| Profundidad máxima (anidada) | O(V + E) para validar ciclos + O(caminos) para la recursión | O(h + k) pila |
| Detección de ciclos (DFS) | O(V + E) | O(V) |
| Tareas bloqueadas / reporte | O(V + E) | O(V) |

h = longitud de la cadena más larga. **Mejora posible:** memorizar la profundidad de cada tarea (`Map<String,Integer>`) reduce el cálculo a O(V + E). **Límite:** cadenas muy largas (miles de niveles) pueden provocar `StackOverflowError`, que la vista captura solo como protección didáctica.

## 6. Cómo ejecutar en NetBeans
1. File → New Project → Java with Ant → Java Application, nombre `AnalisisDependenciasTareas` (desmarcar *Create Main Class*).
2. Copiar las carpetas `Modelo`, `DAO`, `Vista`, `Pruebas` dentro de `src/`.
3. Ejecutar `Vista/Principal.java` (menú) o `Pruebas/SuitePruebas.java` (pruebas).
4. Para la demostración use la opción **10** (datos de ejemplo), luego **4**, **5**, **7** y **8**.
