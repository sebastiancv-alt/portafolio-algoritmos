package DAO;

import Modelo.RegistroEstudiante;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

public class GestorEstudiantes {

    private final ArrayList<RegistroEstudiante> coleccion;

    public GestorEstudiantes() {
        coleccion = new ArrayList<>();
    }

    public void registrar(RegistroEstudiante estudiante) {
        coleccion.add(estudiante);
    }

    public ArrayList<RegistroEstudiante> obtenerTodos() {
        return coleccion;
    }

    public RegistroEstudiante localizar(int id) {
        for (int i = 0; i < coleccion.size(); i++) {
            RegistroEstudiante est = coleccion.get(i);
            if (est.getId() == id) {
                return est;
            }
        }
        return null;
    }

    public boolean actualizar(int id, RegistroEstudiante nuevo) {
        for (int i = 0; i < coleccion.size(); i++) {
            RegistroEstudiante est = coleccion.get(i);
            if (est.getId() == id) {
                coleccion.set(i, nuevo);
                return true;
            }
        }
        return false;
    }

    public boolean borrar(int id) {
        for (int i = 0; i < coleccion.size(); i++) {
            RegistroEstudiante est = coleccion.get(i);
            if (est.getId() == id) {
                coleccion.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean hayRegistros() {
        return !coleccion.isEmpty();
    }

    public int totalRegistros() {
        return coleccion.size();
    }

    // Búsqueda parcial por nombre (ignora mayúsculas)
    public ArrayList<RegistroEstudiante> filtrarPorNombre(String nombre) {
        ArrayList<RegistroEstudiante> resultado = new ArrayList<>();
        String busqueda = nombre.toLowerCase();
        for (RegistroEstudiante est : coleccion) {
            if (est.getNombre().toLowerCase().contains(busqueda)) {
                resultado.add(est);
            }
        }
        return resultado;
    }

    // Filtrar por especialidad
    public ArrayList<RegistroEstudiante> filtrarPorEspecialidad(String especialidad) {
        ArrayList<RegistroEstudiante> resultado = new ArrayList<>();
        for (RegistroEstudiante est : coleccion) {
            if (est.getEspecialidad().equalsIgnoreCase(especialidad)) {
                resultado.add(est);
            }
        }
        return resultado;
    }

    // Orden alfabético por apellido y luego nombre
    public void ordenarAlfabetico() {
        Collator es = Collator.getInstance(Locale.forLanguageTag("es"));
        es.setStrength(Collator.SECONDARY);
        Collections.sort(coleccion,
                Comparator.comparing(RegistroEstudiante::getApellido, es)
                        .thenComparing(RegistroEstudiante::getNombre, es));
    }

    // Orden por edad ascendente
    public void ordenarPorEdad() {
        Collections.sort(coleccion,
                Comparator.comparingInt(RegistroEstudiante::getAnios));
    }

    // Invertir el orden actual
    public void invertirOrden() {
        Collections.reverse(coleccion);
    }

    public RegistroEstudiante primerRegistro() {
        if (coleccion.isEmpty()) {
            return null;
        }
        return coleccion.get(0);
    }

    public RegistroEstudiante ultimoRegistro() {
        if (coleccion.isEmpty()) {
            return null;
        }
        return coleccion.get(coleccion.size() - 1);
    }

    public int eliminarPorEspecialidad(String especialidad) {
        int eliminados = 0;
        for (int i = coleccion.size() - 1; i >= 0; i--) {
            if (coleccion.get(i).getEspecialidad().equalsIgnoreCase(especialidad)) {
                coleccion.remove(i);
                eliminados++;
            }
        }
        return eliminados;
    }

    public int contarPorEspecialidad(String especialidad) {
        int contador = 0;
        for (RegistroEstudiante est : coleccion) {
            if (est.getEspecialidad().equalsIgnoreCase(especialidad)) {
                contador++;
            }
        }
        return contador;
    }

    public ArrayList<RegistroEstudiante> extraerRango(int inicio, int fin) {
        ArrayList<RegistroEstudiante> resultado = new ArrayList<>();
        if (inicio < 1 || fin > coleccion.size() || inicio > fin) {
            return null;
        }
        resultado.addAll(coleccion.subList(inicio - 1, fin));
        return resultado;
    }
}
