package Vista;

import DAO.GestorEstudiantes;
import Modelo.RegistroEstudiante;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuGestion {

    static Scanner entrada = new Scanner(System.in);
    static GestorEstudiantes gestor = new GestorEstudiantes();

    public static void main(String[] args) {
        mostrarMenu();
    }

    public static void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n\tSISTEMA DE GESTIÓN DE ESTUDIANTES");
            System.out.println("=============================================");
            System.out.println("[1] Registrar nuevo estudiante");
            System.out.println("[2] Ver listado completo");
            System.out.println("[3] Consultar por ID");
            System.out.println("[4] Actualizar datos");
            System.out.println("[5] Eliminar registro");
            System.out.println("---------------------------------------------");
            System.out.println("[6] Buscar por nombre");
            System.out.println("[7] Filtrar por especialidad");
            System.out.println("[8] Ordenar alfabéticamente");
            System.out.println("[9] Ordenar por edad");
            System.out.println("[10] Invertir listado");
            System.out.println("[11] Ver primer registro");
            System.out.println("[12] Ver último registro");
            System.out.println("[13] Eliminar por especialidad");
            System.out.println("[14] Contar por especialidad");
            System.out.println("[15] Mostrar rango de posiciones");
            System.out.println("[16] Salir del sistema");
            System.out.println("=============================================");
            System.out.print("Seleccione opción: ");
            opcion = entrada.nextInt();
            entrada.nextLine();

            switch (opcion) {
                case 1:
                    registrarEstudiante();
                    break;
                case 2:
                    verListado();
                    break;
                case 3:
                    consultarPorId();
                    break;
                case 4:
                    actualizarDatos();
                    break;
                case 5:
                    eliminarRegistro();
                    break;
                case 6:
                    buscarPorNombre();
                    break;
                case 7:
                    filtrarEspecialidad();
                    break;
                case 8:
                    ordenarAlfabetico();
                    break;
                case 9:
                    ordenarEdad();
                    break;
                case 10:
                    invertirListado();
                    break;
                case 11:
                    verPrimero();
                    break;
                case 12:
                    verUltimo();
                    break;
                case 13:
                    eliminarPorEspecialidad();
                    break;
                case 14:
                    contarPorEspecialidad();
                    break;
                case 15:
                    mostrarRango();
                    break;
                case 16:
                    System.out.println("\nCerrando sistema. Hasta pronto.");
                    break;
                default:
                    System.out.println("\nOpción no válida. Intente de nuevo.");
            }
        } while (opcion != 16);
    }

    static void registrarEstudiante() {
        System.out.println("\n===== REGISTRO DE ESTUDIANTE =====");
        System.out.print("ID (código numérico): ");
        int id = entrada.nextInt();
        entrada.nextLine();
        System.out.print("Nombre(s): ");
        String nombre = entrada.nextLine();
        System.out.print("Apellido(s): ");
        String apellido = entrada.nextLine();
        System.out.print("Edad: ");
        int anios = entrada.nextInt();
        entrada.nextLine();
        System.out.print("Especialidad / Carrera: ");
        String especialidad = entrada.nextLine();

        RegistroEstudiante est = new RegistroEstudiante(
                id, nombre, apellido, anios, especialidad
        );
        gestor.registrar(est);
        System.out.println("\nEstudiante registrado con éxito.");
    }

    static void verListado() {
        System.out.println("\n===== LISTADO DE ESTUDIANTES =====");
        if (!gestor.hayRegistros()) {
            System.out.println("No hay estudiantes registrados.");
            return;
        }
        for (RegistroEstudiante est : gestor.obtenerTodos()) {
            System.out.println(est);
        }
        System.out.println("\nTotal registrados: " + gestor.totalRegistros());
    }

    static void consultarPorId() {
        System.out.println("\n===== CONSULTA POR ID =====");
        System.out.print("Ingrese ID del estudiante: ");
        int id = entrada.nextInt();
        entrada.nextLine();

        RegistroEstudiante est = gestor.localizar(id);
        if (est != null) {
            System.out.println("\nRegistro encontrado:");
            System.out.println(est);
        } else {
            System.out.println("\nNo se encontró el ID indicado.");
        }
    }

    static void actualizarDatos() {
        System.out.println("\n===== ACTUALIZAR DATOS =====");
        System.out.print("ID del estudiante a modificar: ");
        int id = entrada.nextInt();
        entrada.nextLine();

        RegistroEstudiante actual = gestor.localizar(id);
        if (actual == null) {
            System.out.println("\nID no encontrado.");
            return;
        }

        System.out.println("\nDatos actuales:");
        System.out.println(actual);
        System.out.println("\nIngrese los nuevos valores:");
        System.out.print("Nombre(s): ");
        String nombre = entrada.nextLine();
        System.out.print("Apellido(s): ");
        String apellido = entrada.nextLine();
        System.out.print("Edad: ");
        int anios = entrada.nextInt();
        entrada.nextLine();
        System.out.print("Especialidad: ");
        String especialidad = entrada.nextLine();

        RegistroEstudiante actualizado = new RegistroEstudiante(
                id, nombre, apellido, anios, especialidad
        );
        if (gestor.actualizar(id, actualizado)) {
            System.out.println("\nDatos actualizados correctamente.");
        } else {
            System.out.println("\nNo se pudo actualizar.");
        }
    }

    static void eliminarRegistro() {
        System.out.println("\n===== ELIMINAR REGISTRO =====");
        System.out.print("ID a eliminar: ");
        int id = entrada.nextInt();
        entrada.nextLine();

        if (gestor.borrar(id)) {
            System.out.println("\nRegistro eliminado.");
        } else {
            System.out.println("\nID no encontrado.");
        }
    }

    static void buscarPorNombre() {
        System.out.println("\n===== BÚSQUEDA POR NOMBRE =====");
        System.out.print("Nombre o parte del nombre: ");
        String nombre = entrada.nextLine();

        ArrayList<RegistroEstudiante> lista = gestor.filtrarPorNombre(nombre);
        if (lista.isEmpty()) {
            System.out.println("\nNo se encontraron coincidencias.");
        } else {
            System.out.println();
            mostrarColeccion(lista);
        }
    }

    static void filtrarEspecialidad() {
        System.out.println("\n===== FILTRAR POR ESPECIALIDAD =====");
        System.out.print("Especialidad: ");
        String esp = entrada.nextLine();

        ArrayList<RegistroEstudiante> lista = gestor.filtrarPorEspecialidad(esp);
        if (lista.isEmpty()) {
            System.out.println("\nNo hay estudiantes en esa especialidad.");
        } else {
            System.out.println();
            mostrarColeccion(lista);
        }
    }

    static void ordenarAlfabetico() {
        if (!gestor.hayRegistros()) {
            System.out.println("\nNo hay registros para ordenar.");
            return;
        }
        gestor.ordenarAlfabetico();
        System.out.println("\nListado ordenado alfabéticamente por apellido.");
        verListado();
    }

    static void ordenarEdad() {
        if (!gestor.hayRegistros()) {
            System.out.println("\nNo hay registros para ordenar.");
            return;
        }
        gestor.ordenarPorEdad();
        System.out.println("\nListado ordenado por edad (menor a mayor).");
        verListado();
    }

    static void invertirListado() {
        if (!gestor.hayRegistros()) {
            System.out.println("\nNo hay registros.");
            return;
        }
        gestor.invertirOrden();
        System.out.println("\nOrden del listado invertido.");
        verListado();
    }

    static void verPrimero() {
        System.out.println("\n===== PRIMER REGISTRO =====");
        RegistroEstudiante est = gestor.primerRegistro();
        if (est == null) {
            System.out.println("No existen registros.");
        } else {
            System.out.println(est);
        }
    }

    static void verUltimo() {
        System.out.println("\n===== ÚLTIMO REGISTRO =====");
        RegistroEstudiante est = gestor.ultimoRegistro();
        if (est == null) {
            System.out.println("No existen registros.");
        } else {
            System.out.println(est);
        }
    }

    static void eliminarPorEspecialidad() {
        System.out.println("\n===== ELIMINAR POR ESPECIALIDAD =====");
        System.out.print("Especialidad a eliminar: ");
        String esp = entrada.nextLine();

        int cantidad = gestor.contarPorEspecialidad(esp);
        if (cantidad == 0) {
            System.out.println("\nNo hay estudiantes en esa especialidad.");
            return;
        }

        System.out.print("\nSe eliminarán " + cantidad
                + " registro(s). ¿Confirmar? (S/N): ");
        String resp = entrada.nextLine();

        if (resp.equalsIgnoreCase("S")) {
            int elim = gestor.eliminarPorEspecialidad(esp);
            System.out.println("\nSe eliminaron " + elim + " registro(s).");
        } else {
            System.out.println("\nOperación cancelada.");
        }
    }

    static void contarPorEspecialidad() {
        System.out.println("\n===== CONTAR POR ESPECIALIDAD =====");
        System.out.print("Especialidad: ");
        String esp = entrada.nextLine();
        System.out.println("\nEstudiantes en " + esp + ": "
                + gestor.contarPorEspecialidad(esp));
    }

    static void mostrarRango() {
        System.out.println("\n===== RANGO DE POSICIONES =====");
        if (!gestor.hayRegistros()) {
            System.out.println("No existen registros.");
            return;
        }
        System.out.println("Total de registros: " + gestor.totalRegistros());
        System.out.print("Posición inicial: ");
        int inicio = entrada.nextInt();
        System.out.print("Posición final: ");
        int fin = entrada.nextInt();
        entrada.nextLine();

        ArrayList<RegistroEstudiante> lista = gestor.extraerRango(inicio, fin);
        if (lista == null) {
            System.out.println("\nRango inválido. Use valores entre 1 y "
                    + gestor.totalRegistros() + ", con inicio <= fin.");
        } else {
            System.out.println();
            mostrarColeccion(lista);
        }
    }

    static void mostrarColeccion(ArrayList<RegistroEstudiante> lista) {
        for (RegistroEstudiante est : lista) {
            System.out.println(est);
        }
        System.out.println("\nResultados mostrados: " + lista.size());
    }
}
