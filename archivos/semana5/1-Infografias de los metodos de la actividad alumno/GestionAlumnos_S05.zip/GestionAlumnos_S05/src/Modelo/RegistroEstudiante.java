package Modelo;

public class RegistroEstudiante {

    // Campos privados
    private int id;
    private String nombre;
    private String apellido;
    private int anios;
    private String especialidad;

    public RegistroEstudiante() {
    }

    public RegistroEstudiante(int id, String nombre, String apellido,
                              int anios, String especialidad) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.anios = anios;
        this.especialidad = especialidad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getAnios() {
        return anios;
    }

    public void setAnios(int anios) {
        this.anios = anios;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @Override
    public String toString() {
        return "ID: " + id
                + " | Nombre: " + nombre
                + " | Apellido: " + apellido
                + " | Edad: " + anios
                + " | Especialidad: " + especialidad;
    }
}
