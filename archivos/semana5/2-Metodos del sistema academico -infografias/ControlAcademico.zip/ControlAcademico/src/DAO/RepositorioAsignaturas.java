package DAO;

import Modelo.Asignatura;
import java.util.ArrayList;

public class RepositorioAsignaturas {

    private final ArrayList<Asignatura> lista;

    public RepositorioAsignaturas() {
        lista = new ArrayList<>();
    }

    public void registrar(Asignatura asig) {
        lista.add(asig);
    }

    public ArrayList<Asignatura> obtenerTodos() {
        return lista;
    }

    public Asignatura buscarPorCodigo(String codigo) {
        for (Asignatura a : lista) {
            if (a.getCodigo().equalsIgnoreCase(codigo)) {
                return a;
            }
        }
        return null;
    }

    public ArrayList<Asignatura> buscarPorTitulo(String titulo) {
        ArrayList<Asignatura> res = new ArrayList<>();
        for (Asignatura a : lista) {
            if (a.getTitulo().toLowerCase().contains(titulo.toLowerCase())) {
                res.add(a);
            }
        }
        return res;
    }

    public ArrayList<Asignatura> buscarPorProfesor(String profesor) {
        ArrayList<Asignatura> res = new ArrayList<>();
        for (Asignatura a : lista) {
            if (a.getProfesor().toLowerCase().contains(profesor.toLowerCase())) {
                res.add(a);
            }
        }
        return res;
    }

    public boolean actualizar(String codigo, String titulo, int creditos, String profesor) {
        Asignatura a = buscarPorCodigo(codigo);
        if (a == null) {
            return false;
        }
        a.setTitulo(titulo);
        a.setCreditos(creditos);
        a.setProfesor(profesor);
        return true;
    }

    public boolean eliminar(String codigo) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo().equalsIgnoreCase(codigo)) {
                lista.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean hayRegistros() {
        return !lista.isEmpty();
    }

    public int total() {
        return lista.size();
    }
}
