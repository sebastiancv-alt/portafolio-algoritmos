package DAO;

import Modelo.Alumno;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RepositorioAlumnos {

    private final ArrayList<Alumno> lista;

    public RepositorioAlumnos() {
        lista = new ArrayList<>();
    }

    public void registrar(Alumno alumno) {
        lista.add(alumno);
    }

    public ArrayList<Alumno> obtenerTodos() {
        return lista;
    }

    public Alumno buscarPorCodigo(int codigo) {
        for (Alumno a : lista) {
            if (a.getCodigo() == codigo) {
                return a;
            }
        }
        return null;
    }

    public Alumno buscarPorDocumento(String documento) {
        for (Alumno a : lista) {
            if (a.getDocumento().equals(documento)) {
                return a;
            }
        }
        return null;
    }

    public ArrayList<Alumno> buscarPorApellido(String apellido) {
        ArrayList<Alumno> res = new ArrayList<>();
        for (Alumno a : lista) {
            if (a.getApellido().toLowerCase().contains(apellido.toLowerCase())) {
                res.add(a);
            }
        }
        return res;
    }

    public boolean actualizar(int codigo, String nombre, String apellido,
                              int edad, String programa, int ciclo) {
        Alumno a = buscarPorCodigo(codigo);
        if (a == null) {
            return false;
        }
        a.setNombre(nombre);
        a.setApellido(apellido);
        a.setEdad(edad);
        a.setPrograma(programa);
        a.setCiclo(ciclo);
        return true;
    }

    public boolean eliminar(int codigo) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo() == codigo) {
                lista.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean hayRegistros() {
        return !lista.isEmpty();
    }

    public int total() {
        return lista.size();
    }

    public ArrayList<Alumno> listarPorPrograma(String programa) {
        ArrayList<Alumno> res = new ArrayList<>();
        for (Alumno a : lista) {
            if (a.getPrograma().equalsIgnoreCase(programa)) {
                res.add(a);
            }
        }
        return res;
    }

    public ArrayList<Alumno> ranking() {
        ArrayList<Alumno> res = new ArrayList<>();
        for (Alumno a : lista) {
            if (a.tieneInscripciones()) {
                res.add(a);
            }
        }
        Collections.sort(res,
                Comparator.comparingDouble(Alumno::calcularPromedio).reversed());
        return res;
    }

    public Alumno mejorPromedio() {
        Alumno mejor = null;
        for (Alumno a : lista) {
            if (a.tieneInscripciones()) {
                if (mejor == null || a.calcularPromedio() > mejor.calcularPromedio()) {
                    mejor = a;
                }
            }
        }
        return mejor;
    }
}
