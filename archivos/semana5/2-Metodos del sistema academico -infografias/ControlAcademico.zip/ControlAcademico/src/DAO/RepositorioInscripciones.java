package DAO;

import Modelo.Alumno;
import Modelo.Asignatura;
import Modelo.Inscripcion;
import java.util.ArrayList;

public class RepositorioInscripciones {

    private final ArrayList<Inscripcion> lista;

    public RepositorioInscripciones() {
        lista = new ArrayList<>();
    }

    public void registrar(Inscripcion ins) {
        lista.add(ins);
        ins.getAlumno().getInscripciones().add(ins);
    }

    public ArrayList<Inscripcion> obtenerTodos() {
        return lista;
    }

    public Inscripcion buscar(int codigoAlumno, String codigoAsignatura) {
        for (Inscripcion ins : lista) {
            if (ins.getAlumno().getCodigo() == codigoAlumno
                    && ins.getAsignatura().getCodigo().equalsIgnoreCase(codigoAsignatura)) {
                return ins;
            }
        }
        return null;
    }

    public ArrayList<Inscripcion> listarPorAlumno(Alumno alumno) {
        return alumno.getInscripciones();
    }

    public boolean actualizarNota(int codigoAlumno, String codigoAsignatura, double nuevaNota) {
        Inscripcion ins = buscar(codigoAlumno, codigoAsignatura);
        if (ins == null) {
            return false;
        }
        ins.setNota(nuevaNota);
        return true;
    }

    public boolean eliminar(int codigoAlumno, String codigoAsignatura) {
        Inscripcion ins = buscar(codigoAlumno, codigoAsignatura);
        if (ins == null) {
            return false;
        }
        lista.remove(ins);
        ins.getAlumno().getInscripciones().remove(ins);
        return true;
    }

    public boolean existenDeAsignatura(String codigoAsignatura) {
        for (Inscripcion ins : lista) {
            if (ins.getAsignatura().getCodigo().equalsIgnoreCase(codigoAsignatura)) {
                return true;
            }
        }
        return false;
    }

    public boolean hayRegistros() {
        return !lista.isEmpty();
    }

    public int total() {
        return lista.size();
    }

    public ArrayList<Inscripcion> listarDesaprobados() {
        ArrayList<Inscripcion> res = new ArrayList<>();
        for (Inscripcion ins : lista) {
            if (ins.getSituacion().equals("DESAPROBADO")) {
                res.add(ins);
            }
        }
        return res;
    }
}
