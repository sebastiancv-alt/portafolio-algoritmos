package Vista;

import DAO.RepositorioAlumnos;
import DAO.RepositorioAsignaturas;
import DAO.RepositorioInscripciones;
import Modelo.Alumno;
import Modelo.Asignatura;
import Modelo.Inscripcion;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Principal {

    static Scanner sc = new Scanner(System.in);
    static RepositorioAlumnos repoAlumnos = new RepositorioAlumnos();
    static RepositorioAsignaturas repoAsignaturas = new RepositorioAsignaturas();
    static RepositorioInscripciones repoInscripciones = new RepositorioInscripciones();

    static final boolean CARGAR_EJEMPLOS = false;

    public static void main(String[] args) {
        if (CARGAR_EJEMPLOS) {
            cargarEjemplos();
        }
        menuPrincipal();
    }

    // ---------- auxiliares ----------
    static int leerEntero(String msg) {
        while (true) {
            System.out.print(msg);
            String t = sc.nextLine().trim();
            try {
                return Integer.parseInt(t);
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido. Ingrese un numero entero.");
            }
        }
    }

    static double leerDecimal(String msg) {
        while (true) {
            System.out.print(msg);
            String t = sc.nextLine().trim().replace(',', '.');
            try {
                return Double.parseDouble(t);
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido. Ingrese un numero.");
            }
        }
    }

    static String leerTexto(String msg) {
        while (true) {
            System.out.print(msg);
            String t = sc.nextLine().trim();
            if (!t.isEmpty()) {
                return t;
            }
            System.out.println("El campo no puede estar vacio.");
        }
    }

    static double leerNota() {
        while (true) {
            double n = leerDecimal("Nota final (0-20): ");
            if (n >= 0 && n <= 20) {
                return n;
            }
            System.out.println("La nota debe estar entre 0 y 20.");
        }
    }

    static String linea(char c, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

    static String f2(double v) {
        return String.format(Locale.US, "%.2f", v);
    }

    // ---------- menú ----------
    static void menuPrincipal() {
        int op;
        do {
            System.out.println("\n" + linea('=', 52));
            System.out.println("             CONTROL ACADÉMICO");
            System.out.println(linea('=', 52));
            System.out.println("ALUMNOS");
            System.out.println("[1] Registrar alumno");
            System.out.println("[2] Listar alumnos");
            System.out.println("[3] Buscar alumno");
            System.out.println("[4] Modificar alumno");
            System.out.println("[5] Eliminar alumno");
            System.out.println("\nASIGNATURAS");
            System.out.println("[6] Registrar asignatura");
            System.out.println("[7] Listar asignaturas");
            System.out.println("[8] Buscar asignatura");
            System.out.println("[9] Modificar asignatura");
            System.out.println("[10] Eliminar asignatura");
            System.out.println("\nINSCRIPCIONES");
            System.out.println("[11] Registrar inscripción");
            System.out.println("[12] Listar inscripciones");
            System.out.println("[13] Consultar asignaturas de alumno");
            System.out.println("[14] Modificar nota");
            System.out.println("[15] Eliminar inscripción");
            System.out.println("\nREPORTES");
            System.out.println("[16] Promedio de alumno");
            System.out.println("[17] Ranking académico");
            System.out.println("[18] Alumnos por programa");
            System.out.println("[19] Alumnos desaprobados");
            System.out.println("[20] Mejor promedio");
            System.out.println("[21] Salir");
            System.out.println(linea('=', 52));
            op = leerEntero("Opción: ");

            switch (op) {
                case 1: registrarAlumno(); break;
                case 2: listarAlumnos(); break;
                case 3: buscarAlumno(); break;
                case 4: modificarAlumno(); break;
                case 5: eliminarAlumno(); break;
                case 6: registrarAsignatura(); break;
                case 7: listarAsignaturas(); break;
                case 8: buscarAsignatura(); break;
                case 9: modificarAsignatura(); break;
                case 10: eliminarAsignatura(); break;
                case 11: registrarInscripcion(); break;
                case 12: listarInscripciones(); break;
                case 13: consultarAsignaturasAlumno(); break;
                case 14: modificarNota(); break;
                case 15: eliminarInscripcion(); break;
                case 16: promedioAlumno(); break;
                case 17: ranking(); break;
                case 18: alumnosPorPrograma(); break;
                case 19: desaprobados(); break;
                case 20: mejorPromedio(); break;
                case 21:
                    System.out.println("\nPrograma finalizado...");
                    break;
                default:
                    System.out.println("\nOpción incorrecta.");
            }
        } while (op != 21);
    }

    // ---------- alumnos ----------
    static void registrarAlumno() {
        System.out.println("\n===== REGISTRAR ALUMNO =====");
        int codigo = leerEntero("Código: ");
        if (repoAlumnos.buscarPorCodigo(codigo) != null) {
            System.out.println("El código ya existe.");
            return;
        }
        String doc = leerTexto("Documento (8 dígitos): ");
        if (doc.length() != 8 || !doc.matches("\\d+")) {
            System.out.println("El documento debe tener 8 dígitos.");
            return;
        }
        if (repoAlumnos.buscarPorDocumento(doc) != null) {
            System.out.println("El documento ya está registrado.");
            return;
        }
        String nombre = leerTexto("Nombre: ");
        String apellido = leerTexto("Apellido: ");
        int edad = leerEntero("Edad: ");
        if (edad < 15 || edad > 99) {
            System.out.println("La edad debe estar entre 15 y 99.");
            return;
        }
        String programa = leerTexto("Programa / Carrera: ");
        int ciclo = leerEntero("Ciclo (1-10): ");
        if (ciclo < 1 || ciclo > 10) {
            System.out.println("El ciclo debe estar entre 1 y 10.");
            return;
        }
        repoAlumnos.registrar(new Alumno(codigo, doc, nombre, apellido, edad, programa, ciclo));
        System.out.println("\nAlumno registrado correctamente.");
    }

    static void listarAlumnos() {
        if (!repoAlumnos.hayRegistros()) {
            System.out.println("\nNo existen alumnos registrados.");
            return;
        }
        System.out.println("\n" + linea('=', 92));
        System.out.println("                                   LISTA DE ALUMNOS");
        System.out.println(linea('=', 92));
        for (Alumno a : repoAlumnos.obtenerTodos()) {
            System.out.println(a);
        }
        System.out.println(linea('=', 92));
        System.out.println("Total de alumnos: " + repoAlumnos.total());
    }

    static void buscarAlumno() {
        System.out.println("\n===== BUSCAR ALUMNO =====");
        System.out.println("[1] Por código");
        System.out.println("[2] Por documento");
        System.out.println("[3] Por apellido");
        int sub = leerEntero("Opción: ");
        if (sub == 1) {
            int cod = leerEntero("Código: ");
            Alumno a = repoAlumnos.buscarPorCodigo(cod);
            if (a == null) System.out.println("No encontrado.");
            else System.out.println(a);
        } else if (sub == 2) {
            String doc = leerTexto("Documento: ");
            Alumno a = repoAlumnos.buscarPorDocumento(doc);
            if (a == null) System.out.println("No encontrado.");
            else System.out.println(a);
        } else if (sub == 3) {
            String ap = leerTexto("Apellido (parcial): ");
            ArrayList<Alumno> lista = repoAlumnos.buscarPorApellido(ap);
            if (lista.isEmpty()) System.out.println("Sin coincidencias.");
            else for (Alumno a : lista) System.out.println(a);
        } else {
            System.out.println("Opción inválida.");
        }
    }

    static void modificarAlumno() {
        System.out.println("\n===== MODIFICAR ALUMNO =====");
        int cod = leerEntero("Código del alumno: ");
        Alumno a = repoAlumnos.buscarPorCodigo(cod);
        if (a == null) {
            System.out.println("No encontrado.");
            return;
        }
        System.out.println("Datos actuales: " + a);
        String nombre = leerTexto("Nuevo nombre: ");
        String apellido = leerTexto("Nuevo apellido: ");
        int edad = leerEntero("Nueva edad: ");
        String programa = leerTexto("Nuevo programa: ");
        int ciclo = leerEntero("Nuevo ciclo: ");
        if (repoAlumnos.actualizar(cod, nombre, apellido, edad, programa, ciclo)) {
            System.out.println("Alumno actualizado.");
        } else {
            System.out.println("No se pudo actualizar.");
        }
    }

    static void eliminarAlumno() {
        System.out.println("\n===== ELIMINAR ALUMNO =====");
        int cod = leerEntero("Código: ");
        Alumno a = repoAlumnos.buscarPorCodigo(cod);
        if (a == null) {
            System.out.println("No encontrado.");
            return;
        }
        if (a.tieneInscripciones()) {
            System.out.println("No se puede eliminar: tiene inscripciones asociadas.");
            return;
        }
        if (repoAlumnos.eliminar(cod)) {
            System.out.println("Alumno eliminado.");
        }
    }

    // ---------- asignaturas ----------
    static void registrarAsignatura() {
        System.out.println("\n===== REGISTRAR ASIGNATURA =====");
        String codigo = leerTexto("Código: ");
        if (repoAsignaturas.buscarPorCodigo(codigo) != null) {
            System.out.println("El código ya existe.");
            return;
        }
        String titulo = leerTexto("Título: ");
        int creditos = leerEntero("Créditos: ");
        String profesor = leerTexto("Profesor: ");
        repoAsignaturas.registrar(new Asignatura(codigo, titulo, creditos, profesor));
        System.out.println("Asignatura registrada.");
    }

    static void listarAsignaturas() {
        if (!repoAsignaturas.hayRegistros()) {
            System.out.println("\nNo existen asignaturas registradas.");
            return;
        }
        System.out.println("\n===== LISTA DE ASIGNATURAS =====");
        for (Asignatura a : repoAsignaturas.obtenerTodos()) {
            System.out.println(a);
        }
        System.out.println("Total: " + repoAsignaturas.total());
    }

    static void buscarAsignatura() {
        System.out.println("\n===== BUSCAR ASIGNATURA =====");
        System.out.println("[1] Por código");
        System.out.println("[2] Por título");
        System.out.println("[3] Por profesor");
        int sub = leerEntero("Opción: ");
        if (sub == 1) {
            String cod = leerTexto("Código: ");
            Asignatura a = repoAsignaturas.buscarPorCodigo(cod);
            if (a == null) System.out.println("No encontrada.");
            else System.out.println(a);
        } else if (sub == 2) {
            String t = leerTexto("Título (parcial): ");
            ArrayList<Asignatura> lista = repoAsignaturas.buscarPorTitulo(t);
            if (lista.isEmpty()) System.out.println("Sin coincidencias.");
            else for (Asignatura a : lista) System.out.println(a);
        } else if (sub == 3) {
            String p = leerTexto("Profesor (parcial): ");
            ArrayList<Asignatura> lista = repoAsignaturas.buscarPorProfesor(p);
            if (lista.isEmpty()) System.out.println("Sin coincidencias.");
            else for (Asignatura a : lista) System.out.println(a);
        } else {
            System.out.println("Opción inválida.");
        }
    }

    static void modificarAsignatura() {
        System.out.println("\n===== MODIFICAR ASIGNATURA =====");
        String cod = leerTexto("Código: ");
        Asignatura a = repoAsignaturas.buscarPorCodigo(cod);
        if (a == null) {
            System.out.println("No encontrada.");
            return;
        }
        System.out.println("Actual: " + a);
        String titulo = leerTexto("Nuevo título: ");
        int creditos = leerEntero("Nuevos créditos: ");
        String profesor = leerTexto("Nuevo profesor: ");
        if (repoAsignaturas.actualizar(cod, titulo, creditos, profesor)) {
            System.out.println("Asignatura actualizada.");
        }
    }

    static void eliminarAsignatura() {
        System.out.println("\n===== ELIMINAR ASIGNATURA =====");
        String cod = leerTexto("Código: ");
        if (repoAsignaturas.buscarPorCodigo(cod) == null) {
            System.out.println("No encontrada.");
            return;
        }
        if (repoInscripciones.existenDeAsignatura(cod)) {
            System.out.println("No se puede eliminar: tiene inscripciones asociadas.");
            return;
        }
        if (repoAsignaturas.eliminar(cod)) {
            System.out.println("Asignatura eliminada.");
        }
    }

    // ---------- inscripciones ----------
    static void registrarInscripcion() {
        System.out.println("\n===== REGISTRAR INSCRIPCIÓN =====");
        int codAl = leerEntero("Código del alumno: ");
        Alumno al = repoAlumnos.buscarPorCodigo(codAl);
        if (al == null) {
            System.out.println("Alumno no existe.");
            return;
        }
        String codAs = leerTexto("Código de asignatura: ");
        Asignatura as = repoAsignaturas.buscarPorCodigo(codAs);
        if (as == null) {
            System.out.println("Asignatura no existe.");
            return;
        }
        if (repoInscripciones.buscar(codAl, codAs) != null) {
            System.out.println("Ya existe esa inscripción.");
            return;
        }
        double nota = leerNota();
        repoInscripciones.registrar(new Inscripcion(al, as, nota));
        System.out.println("Inscripción registrada.");
    }

    static void listarInscripciones() {
        if (!repoInscripciones.hayRegistros()) {
            System.out.println("\nNo existen inscripciones.");
            return;
        }
        System.out.println("\n===== LISTA DE INSCRIPCIONES =====");
        for (Inscripcion i : repoInscripciones.obtenerTodos()) {
            System.out.println(i);
        }
        System.out.println("Total: " + repoInscripciones.total());
    }

    static void consultarAsignaturasAlumno() {
        System.out.println("\n===== ASIGNATURAS DEL ALUMNO =====");
        int cod = leerEntero("Código del alumno: ");
        Alumno a = repoAlumnos.buscarPorCodigo(cod);
        if (a == null) {
            System.out.println("Alumno no existe.");
            return;
        }
        ArrayList<Inscripcion> lista = repoInscripciones.listarPorAlumno(a);
        if (lista.isEmpty()) {
            System.out.println("El alumno no tiene inscripciones.");
            return;
        }
        for (Inscripcion i : lista) {
            System.out.println(i);
        }
    }

    static void modificarNota() {
        System.out.println("\n===== MODIFICAR NOTA =====");
        int codAl = leerEntero("Código alumno: ");
        String codAs = leerTexto("Código asignatura: ");
        if (repoInscripciones.buscar(codAl, codAs) == null) {
            System.out.println("Inscripción no encontrada.");
            return;
        }
        double nota = leerNota();
        if (repoInscripciones.actualizarNota(codAl, codAs, nota)) {
            System.out.println("Nota actualizada.");
        }
    }

    static void eliminarInscripcion() {
        System.out.println("\n===== ELIMINAR INSCRIPCIÓN =====");
        int codAl = leerEntero("Código alumno: ");
        String codAs = leerTexto("Código asignatura: ");
        if (repoInscripciones.eliminar(codAl, codAs)) {
            System.out.println("Inscripción eliminada.");
        } else {
            System.out.println("No se encontró la inscripción.");
        }
    }

    // ---------- reportes ----------
    static void promedioAlumno() {
        System.out.println("\n===== PROMEDIO DE ALUMNO =====");
        int cod = leerEntero("Código: ");
        Alumno a = repoAlumnos.buscarPorCodigo(cod);
        if (a == null) {
            System.out.println("No encontrado.");
            return;
        }
        if (!a.tieneInscripciones()) {
            System.out.println("Sin inscripciones. Promedio: 0.00");
            return;
        }
        System.out.println("Alumno: " + a.getNombreCompleto());
        System.out.println("Promedio: " + f2(a.calcularPromedio()));
    }

    static void ranking() {
        System.out.println("\n===== RANKING ACADÉMICO =====");
        ArrayList<Alumno> lista = repoAlumnos.ranking();
        if (lista.isEmpty()) {
            System.out.println("No hay alumnos con inscripciones.");
            return;
        }
        int pos = 1;
        for (Alumno a : lista) {
            System.out.println(pos + ". " + a.getNombreCompleto()
                    + " | Promedio: " + f2(a.calcularPromedio())
                    + " | Programa: " + a.getPrograma());
            pos++;
        }
    }

    static void alumnosPorPrograma() {
        System.out.println("\n===== ALUMNOS POR PROGRAMA =====");
        String prog = leerTexto("Programa: ");
        ArrayList<Alumno> lista = repoAlumnos.listarPorPrograma(prog);
        if (lista.isEmpty()) {
            System.out.println("No hay alumnos en ese programa.");
            return;
        }
        for (Alumno a : lista) {
            System.out.println(a);
        }
        System.out.println("Total: " + lista.size());
    }

    static void desaprobados() {
        System.out.println("\n===== INSCRIPCIONES DESAPROBADAS =====");
        ArrayList<Inscripcion> lista = repoInscripciones.listarDesaprobados();
        if (lista.isEmpty()) {
            System.out.println("No hay desaprobados.");
            return;
        }
        for (Inscripcion i : lista) {
            System.out.println(i);
        }
    }

    static void mejorPromedio() {
        System.out.println("\n" + linea('=', 52));
        System.out.println("            MEJOR RENDIMIENTO ACADÉMICO");
        System.out.println(linea('=', 52));
        Alumno mejor = repoAlumnos.mejorPromedio();
        if (mejor == null) {
            System.out.println("No hay datos suficientes.");
            return;
        }
        System.out.println("\nCódigo:   " + mejor.getCodigo());
        System.out.println("Alumno:   " + mejor.getNombreCompleto());
        System.out.println("Programa: " + mejor.getPrograma());
        System.out.println("Promedio: " + f2(mejor.calcularPromedio()));
    }

    // ---------- datos de ejemplo (diferentes a los originales) ----------
    static void cargarEjemplos() {
        repoAlumnos.registrar(new Alumno(2001, "81234567", "Luis", "Mendoza Vargas", 21, "Ingeniería de Software", 5));
        repoAlumnos.registrar(new Alumno(2002, "82345678", "Sofía", "Castro Ruiz", 20, "Diseño Digital", 4));
        repoAlumnos.registrar(new Alumno(2003, "83456789", "Diego", "Vargas Peña", 23, "Ingeniería de Software", 7));
        repoAlumnos.registrar(new Alumno(2004, "84567890", "Valeria", "Rojas Silva", 19, "Redes y Comunicaciones", 3));

        repoAsignaturas.registrar(new Asignatura("POO01", "Programación Orientada a Objetos", 4, "Ing. Morales"));
        repoAsignaturas.registrar(new Asignatura("BD002", "Fundamentos de Bases de Datos", 3, "Ing. Castro"));
        repoAsignaturas.registrar(new Asignatura("ALG02", "Estructuras de Datos", 4, "Ing. Paredes"));
        repoAsignaturas.registrar(new Asignatura("WEB02", "Desarrollo Web Frontend", 3, "Ing. Núñez"));

        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2001),
                repoAsignaturas.buscarPorCodigo("POO01"), 17));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2001),
                repoAsignaturas.buscarPorCodigo("BD002"), 15));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2001),
                repoAsignaturas.buscarPorCodigo("ALG02"), 18));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2002),
                repoAsignaturas.buscarPorCodigo("WEB02"), 16));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2002),
                repoAsignaturas.buscarPorCodigo("BD002"), 11));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2003),
                repoAsignaturas.buscarPorCodigo("POO01"), 9));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2003),
                repoAsignaturas.buscarPorCodigo("ALG02"), 14));
        repoInscripciones.registrar(new Inscripcion(
                repoAlumnos.buscarPorCodigo(2004),
                repoAsignaturas.buscarPorCodigo("WEB02"), 10));
    }
}
