package Modelo;

import java.util.ArrayList;

public class Alumno {

    private int codigo;
    private String documento;
    private String nombre;
    private String apellido;
    private int edad;
    private String programa;
    private int ciclo;

    private ArrayList<Inscripcion> inscripciones;

    public Alumno() {
        inscripciones = new ArrayList<>();
    }

    public Alumno(int codigo, String documento, String nombre, String apellido,
                  int edad, String programa, int ciclo) {
        this.codigo = codigo;
        this.documento = documento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.programa = programa;
        this.ciclo = ciclo;
        this.inscripciones = new ArrayList<>();
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getPrograma() {
        return programa;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    public int getCiclo() {
        return ciclo;
    }

    public void setCiclo(int ciclo) {
        this.ciclo = ciclo;
    }

    public ArrayList<Inscripcion> getInscripciones() {
        return inscripciones;
    }

    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    public boolean tieneInscripciones() {
        return !inscripciones.isEmpty();
    }

    public double calcularPromedio() {
        if (inscripciones.isEmpty()) {
            return 0;
        }
        double suma = 0;
        for (Inscripcion ins : inscripciones) {
            suma += ins.getNota();
        }
        return suma / inscripciones.size();
    }

    @Override
    public String toString() {
        return "Codigo: " + codigo
                + " | Documento: " + documento
                + " | Nombre: " + nombre
                + " | Apellido: " + apellido
                + " | Edad: " + edad
                + " | Programa: " + programa
                + " | Ciclo: " + ciclo;
    }
}
