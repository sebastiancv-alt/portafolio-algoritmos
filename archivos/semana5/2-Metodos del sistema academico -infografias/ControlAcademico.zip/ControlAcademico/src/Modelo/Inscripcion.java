package Modelo;

public class Inscripcion {

    private Alumno alumno;
    private Asignatura asignatura;
    private double nota;
    private String situacion;

    public Inscripcion() {
    }

    public Inscripcion(Alumno alumno, Asignatura asignatura, double nota) {
        this.alumno = alumno;
        this.asignatura = asignatura;
        setNota(nota);
    }

    public static String calcularSituacion(double nota) {
        if (nota >= 13) {
            return "APROBADO";
        } else if (nota >= 11) {
            return "RECUPERACIÓN";
        } else {
            return "DESAPROBADO";
        }
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Asignatura getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
        this.situacion = calcularSituacion(nota);
    }

    public String getSituacion() {
        return situacion;
    }

    @Override
    public String toString() {
        return "Alumno: " + alumno.getCodigo()
                + " | Asignatura: " + asignatura.getTitulo()
                + " | Nota: " + String.format(java.util.Locale.US, "%.2f", nota)
                + " | Situacion: " + situacion;
    }
}
