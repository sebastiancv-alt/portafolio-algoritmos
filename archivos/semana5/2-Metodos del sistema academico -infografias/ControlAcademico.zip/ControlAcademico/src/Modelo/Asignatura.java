package Modelo;

public class Asignatura {

    private String codigo;
    private String titulo;
    private int creditos;
    private String profesor;

    public Asignatura() {
    }

    public Asignatura(String codigo, String titulo, int creditos, String profesor) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.creditos = creditos;
        this.profesor = profesor;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public String getProfesor() {
        return profesor;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    @Override
    public String toString() {
        return "Codigo: " + codigo
                + " | Asignatura: " + titulo
                + " | Creditos: " + creditos
                + " | Profesor: " + profesor;
    }
}
