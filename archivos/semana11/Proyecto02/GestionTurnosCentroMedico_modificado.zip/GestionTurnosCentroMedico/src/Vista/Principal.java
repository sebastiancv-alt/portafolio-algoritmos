package Vista;

import DAO.ListaCircularTurnos;
import Modelo.Paciente;
import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {

        // Instanciar la lista circular
        ListaCircularTurnos lista = new ListaCircularTurnos();

        // Instanciar la vista
        MenuTurnosVista menu = new MenuTurnosVista();

        int opcion;

        do {

            menu.mostrarMenu();

            opcion = menu.leerEntero("Seleccione una opcion: ");

            switch (opcion) {

                // 1. REGISTRAR PACIENTE AL INICIO
                case 1: {

                    Paciente paciente = menu.leerPaciente();

                    if (lista.insertarInicio(paciente)) {
                        menu.mostrarMensaje(
                                "Paciente registrado al inicio.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo registrar. Codigo duplicado.");
                    }

                    break;
                }

                // 2. REGISTRAR PACIENTE AL FINAL
                case 2: {

                    Paciente paciente = menu.leerPaciente();

                    if (lista.insertarFinal(paciente)) {
                        menu.mostrarMensaje(
                                "Paciente registrado al final.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo registrar. Codigo duplicado.");
                    }

                    break;
                }

                // 3. INSERTAR PACIENTE EN POSICION X
                case 3: {

                    int posicion = menu.leerEntero(
                            "Ingrese la posicion donde insertar: ");

                    Paciente paciente = menu.leerPaciente();

                    if (lista.insertarPosicion(paciente, posicion)) {
                        menu.mostrarMensaje(
                                "Paciente insertado en la posicion "
                                + posicion + ".");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo insertar. Verifique la posicion "
                                + "o el codigo.");
                    }

                    break;
                }

                // 4. INSERTAR PACIENTE DESPUES DE OTRO
                case 4: {

                    String referencia = menu.leerTexto(
                            "Ingrese el codigo de referencia: ");

                    Paciente paciente = menu.leerPaciente();

                    if (lista.insertarReferencia(referencia, paciente)) {
                        menu.mostrarMensaje(
                                "Paciente insertado despues de la referencia.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo insertar. Verifique la referencia "
                                + "o el codigo.");
                    }

                    break;
                }

                // 5. ATENDER AL SIGUIENTE PACIENTE
                case 5: {

                    Paciente atendido = lista.atenderSiguiente();

                    if (atendido != null) {
                        menu.mostrarMensaje(
                                "Paciente atendido:\n" + atendido);
                    } else {
                        menu.mostrarMensaje(
                                "No hay pacientes pendientes.");
                    }

                    break;
                }

                // 6. ELIMINAR TURNO CANCELADO POR CODIGO
                case 6: {

                    String codigo = menu.leerTexto(
                            "Ingrese el codigo del paciente: ");

                    Paciente eliminado = lista.eliminarPorCodigo(codigo);

                    if (eliminado != null) {
                        menu.mostrarMensaje(
                                "Turno cancelado:\n" + eliminado);
                    } else {
                        menu.mostrarMensaje(
                                "No se encontro el paciente.");
                    }

                    break;
                }

                // 7. ELIMINAR EL PRIMER TURNO PENDIENTE
                case 7: {

                    Paciente eliminado = lista.eliminarInicio();

                    if (eliminado != null) {
                        menu.mostrarMensaje(
                                "Primer turno eliminado:\n" + eliminado);
                    } else {
                        menu.mostrarMensaje(
                                "No hay pacientes pendientes.");
                    }

                    break;
                }

                // 8. ELIMINAR EL ULTIMO TURNO PENDIENTE
                case 8: {

                    Paciente eliminado = lista.eliminarFinal();

                    if (eliminado != null) {
                        menu.mostrarMensaje(
                                "Ultimo turno eliminado:\n" + eliminado);
                    } else {
                        menu.mostrarMensaje(
                                "No hay pacientes pendientes.");
                    }

                    break;
                }

                // 9. REPROGRAMAR PACIENTE EN OTRA POSICION
                case 9: {

                    String codigo = menu.leerTexto(
                            "Ingrese el codigo del paciente: ");

                    int posicion = menu.leerEntero(
                            "Ingrese la nueva posicion: ");

                    if (lista.reprogramar(codigo, posicion)) {
                        menu.mostrarMensaje(
                                "Paciente reprogramado en la posicion "
                                + posicion + ".");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo reprogramar. Verifique el "
                                + "codigo o la posicion.");
                    }

                    break;
                }

                // 10. BUSCAR PACIENTE POR CODIGO
                case 10: {

                    String codigo = menu.leerTexto(
                            "Ingrese el codigo del paciente: ");

                    Paciente paciente = lista.buscar(codigo);

                    menu.mostrarPaciente(paciente);

                    break;
                }

                // 11. MOSTRAR PACIENTES PENDIENTES
                case 11: {

                    ArrayList<Paciente> pacientes = lista.recorrer();

                    menu.mostrarLista(pacientes);

                    break;
                }

                // 12. CANTIDAD DE PACIENTES REGISTRADOS
                case 12: {

                    menu.mostrarMensaje(
                            "Cantidad de pacientes registrados: "
                            + lista.getTamanio());

                    break;
                }

                // 13. MOSTRAR PROXIMO PACIENTE A ATENDER
                case 13: {

                    Paciente proximo = lista.verProximo();

                    if (proximo != null) {
                        menu.mostrarMensaje(
                                "Proximo paciente a atender:\n" + proximo);
                    } else {
                        menu.mostrarMensaje(
                                "No hay pacientes pendientes.");
                    }

                    break;
                }

                // 14. ORDENAR POR NUMERO DE TURNO
                case 14: {

                    lista.ordenar();

                    menu.mostrarMensaje(
                            "Lista ordenada por numero de turno.");

                    menu.mostrarLista(lista.recorrer());

                    break;
                }

                // 15. INTERCAMBIAR DOS PACIENTES
                case 15: {

                    int posicion1 = menu.leerEntero(
                            "Ingrese la primera posicion: ");

                    int posicion2 = menu.leerEntero(
                            "Ingrese la segunda posicion: ");

                    if (lista.intercambiar(posicion1, posicion2)) {

                        menu.mostrarMensaje(
                                "Pacientes intercambiados correctamente.");

                        menu.mostrarLista(lista.recorrer());

                    } else {

                        menu.mostrarMensaje(
                                "No se pudo realizar el intercambio. "
                                + "Verifique las posiciones.");
                    }

                    break;
                }

                // 16. MODIFICAR DATOS DE UN PACIENTE
                case 16: {

                    String codigo = menu.leerTexto(
                            "Ingrese el codigo del paciente a modificar: ");

                    String nombres = menu.leerTexto(
                            "Ingrese los nuevos nombres: ");

                    String apellidos = menu.leerTexto(
                            "Ingrese los nuevos apellidos: ");

                    String dni = menu.leerDni("Ingrese el nuevo DNI: ");

                    String especialidad = menu.leerTexto(
                            "Ingrese la nueva especialidad: ");

                    if (lista.modificar(codigo, nombres, apellidos,
                            dni, especialidad)) {

                        menu.mostrarMensaje(
                                "Datos del paciente modificados "
                                + "correctamente.");

                    } else {

                        menu.mostrarMensaje(
                                "No se encontro el paciente.");
                    }

                    break;
                }

                // SALIR
                case 0: {

                    menu.mostrarMensaje(
                            "Gracias por utilizar el sistema.");

                    break;
                }

                // OPCION INCORRECTA
                default: {

                    menu.mostrarMensaje(
                            "Opcion incorrecta. Intente nuevamente.");

                    break;
                }
            }

        } while (opcion != 0);
    }
}
