package Vista;

import Modelo.Paciente;
import Modelo.Turno;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuTurnosVista {

    private Scanner teclado;

    public MenuTurnosVista() {
        teclado = new Scanner(System.in);
    }

    // Mostrar menu principal
    public void mostrarMenu() {

        System.out.println("\n======================================");
        System.out.println("   SISTEMA DE GESTION DE TURNOS - CENTRO MEDICO");
        System.out.println("   Estructura: Lista Circular Simplemente Enlazada");
        System.out.println("======================================");

        System.out.println("\n--- REGISTRO DE PACIENTES ---");
        System.out.println("1. Registrar paciente al inicio de la lista");
        System.out.println("2. Registrar paciente al final de la lista");
        System.out.println("3. Insertar paciente en posicion especifica");
        System.out.println("4. Insertar paciente despues de un codigo de referencia");

        System.out.println("\n--- GESTION DE TURNOS ---");
        System.out.println("5. Atender al siguiente paciente en turno");
        System.out.println("6. Cancelar turno por codigo de paciente");
        System.out.println("7. Eliminar el primer turno pendiente");
        System.out.println("8. Eliminar el ultimo turno pendiente");
        System.out.println("9. Reprogramar paciente a otra posicion");

        System.out.println("\n--- CONSULTAS ---");
        System.out.println("10. Buscar paciente por codigo");
        System.out.println("11. Mostrar pacientes pendientes");
        System.out.println("12. Cantidad de pacientes registrados");
        System.out.println("13. Mostrar proximo paciente a atender");

        System.out.println("\n--- ADMINISTRACION ---");
        System.out.println("14. Ordenar pacientes por numero de turno");
        System.out.println("15. Intercambiar dos pacientes");
        System.out.println("16. Modificar datos de un paciente");

        System.out.println("\n0. Salir");

        System.out.println("======================================");
    }

    // Leer un numero entero
    public int leerEntero(String mensaje) {

        while (true) {

            System.out.print(mensaje);

            try {
                int numero = Integer.parseInt(
                        teclado.nextLine().trim());

                return numero;

            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero entero.");
            }
        }
    }

    // Leer una cadena no vacia
    public String leerTexto(String mensaje) {

        while (true) {

            System.out.print(mensaje);

            String texto = teclado.nextLine().trim();

            if (!texto.isEmpty()) {
                return texto;
            }

            System.out.println("El campo no puede estar vacio.");
        }
    }

    // Leer una cadena que cumpla un formato
    private String leerFormato(String mensaje, String patron,
                               String error) {

        while (true) {

            String texto = leerTexto(mensaje);

            if (texto.matches(patron)) {
                return texto;
            }

            System.out.println(error);
        }
    }

    // Leer un DNI (8 digitos)
    public String leerDni(String mensaje) {
        return leerFormato(mensaje, "\\d{8}",
                "El DNI debe tener 8 digitos.");
    }

    // Leer datos de un paciente con su turno
    public Paciente leerPaciente() {

        System.out.println("\n--- REGISTRO DE PACIENTE ---");

        String codigo = leerTexto("Ingrese codigo: ");

        String nombres = leerTexto("Ingrese nombres: ");

        String apellidos = leerTexto("Ingrese apellidos: ");

        String dni = leerDni("Ingrese DNI: ");

        String especialidad = leerTexto("Ingrese especialidad: ");

        int numero;

        do {
            numero = leerEntero("Ingrese numero de turno: ");

            if (numero < 1) {
                System.out.println(
                        "El numero de turno debe ser mayor que cero.");
            }

        } while (numero < 1);

        String fecha = leerFormato("Ingrese fecha (dd/mm/aaaa): ",
                "\\d{2}/\\d{2}/\\d{4}",
                "Formato de fecha incorrecto.");

        String hora = leerFormato("Ingrese hora (hh:mm): ",
                "([01]\\d|2[0-3]):[0-5]\\d",
                "Formato de hora incorrecto.");

        return new Paciente(codigo, nombres, apellidos, dni,
                especialidad, new Turno(numero, fecha, hora));
    }

    // Mostrar un paciente
    public void mostrarPaciente(Paciente paciente) {

        if (paciente == null) {
            System.out.println("\nNo se encontro el paciente.");
        } else {
            System.out.println("\n--- DATOS DEL PACIENTE ---");
            System.out.println(paciente);
        }
    }

    // Mostrar todos los pacientes pendientes
    public void mostrarLista(ArrayList<Paciente> pacientes) {

        if (pacientes.isEmpty()) {
            System.out.println("\nNo hay pacientes pendientes.");
            return;
        }

        System.out.println("\n===== LISTADO DE PACIENTES PENDIENTES =====");

        int posicion = 1;

        for (Paciente paciente : pacientes) {

            System.out.println("Posicion " + posicion);
            System.out.println(paciente);
            System.out.println("--------------------------------------");

            posicion++;
        }

        System.out.println("Total de pacientes: " + pacientes.size());
    }

    // Mostrar mensaje
    public void mostrarMensaje(String mensaje) {
        System.out.println("\n" + mensaje);
    }
}
