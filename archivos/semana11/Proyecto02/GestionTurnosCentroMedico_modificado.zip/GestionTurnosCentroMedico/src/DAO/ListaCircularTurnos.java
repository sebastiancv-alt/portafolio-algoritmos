package DAO;

import Modelo.Nodo;
import Modelo.Paciente;
import java.util.ArrayList;

public class ListaCircularTurnos {

    // 'ultimo' apunta al ultimo nodo; ultimo.getSiguiente() es el inicio
    private Nodo ultimo;
    private int tamanio;

    public ListaCircularTurnos() {
        ultimo = null;
        tamanio = 0;
    }

    // Verificar si la lista esta vacia
    public boolean estaVacia() {
        return ultimo == null;
    }

    // Validar que no existan codigos de paciente duplicados
    private boolean existeCodigo(String codigo) {
        return buscar(codigo) != null;
    }

    // Obtener un nodo segun su posicion (inicia en 1)
    private Nodo obtenerNodo(int posicion) {

        if (posicion < 1 || posicion > tamanio) {
            return null;
        }

        Nodo actual = ultimo.getSiguiente();

        for (int i = 1; i < posicion; i++) {
            actual = actual.getSiguiente();
        }

        return actual;
    }

    // BUSCAR UN NODO POR CODIGO
    private Nodo buscarNodo(String codigo) {

        if (estaVacia() || codigo == null) {
            return null;
        }

        Nodo actual = ultimo.getSiguiente();

        do {
            if (actual.getDato().getCodigo()
                    .equalsIgnoreCase(codigo)) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != ultimo.getSiguiente());

        return null;
    }

    // 1. REGISTRAR PACIENTE AL INICIO
    public boolean insertarInicio(Paciente paciente) {

        if (paciente == null || existeCodigo(paciente.getCodigo())) {
            return false;
        }

        Nodo nuevo = new Nodo(paciente);

        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
        }

        tamanio++;
        return true;
    }

    // 2. REGISTRAR PACIENTE AL FINAL
    public boolean insertarFinal(Paciente paciente) {

        if (paciente == null || existeCodigo(paciente.getCodigo())) {
            return false;
        }

        Nodo nuevo = new Nodo(paciente);

        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }

        tamanio++;
        return true;
    }

    // 3. INSERTAR PACIENTE EN UNA POSICION
    public boolean insertarPosicion(Paciente paciente, int posicion) {

        if (paciente == null || existeCodigo(paciente.getCodigo())
                || posicion < 1 || posicion > tamanio + 1) {
            return false;
        }

        if (posicion == 1) {
            return insertarInicio(paciente);
        }

        if (posicion == tamanio + 1) {
            return insertarFinal(paciente);
        }

        Nodo anterior = obtenerNodo(posicion - 1);
        Nodo nuevo = new Nodo(paciente);

        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);

        tamanio++;
        return true;
    }

    // 4. INSERTAR PACIENTE DESPUES DE OTRO (por codigo)
    public boolean insertarReferencia(String codigoReferencia,
                                     Paciente paciente) {

        if (paciente == null || existeCodigo(paciente.getCodigo())) {
            return false;
        }

        Nodo actual = buscarNodo(codigoReferencia);

        if (actual == null) {
            return false;
        }

        Nodo nuevo = new Nodo(paciente);

        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);

        if (actual == ultimo) {
            ultimo = nuevo;
        }

        tamanio++;
        return true;
    }

    // 5. ATENDER AL SIGUIENTE PACIENTE
    // Saca el primer nodo y el inicio pasa al siguiente registro
    public Paciente atenderSiguiente() {

        if (estaVacia()) {
            return null;
        }

        Nodo inicio = ultimo.getSiguiente();
        Paciente paciente = inicio.getDato();

        if (inicio == ultimo) {
            ultimo = null;
        } else {
            ultimo.setSiguiente(inicio.getSiguiente());
        }

        paciente.getTurno().setEstado("ATENDIDO");

        tamanio--;
        return paciente;
    }

    // 6. ELIMINAR TURNO CANCELADO (por codigo de paciente)
    public Paciente eliminarPorCodigo(String codigo) {

        if (estaVacia() || codigo == null) {
            return null;
        }

        Nodo anterior = ultimo;
        Nodo actual = ultimo.getSiguiente();

        for (int i = 0; i < tamanio; i++) {

            if (actual.getDato().getCodigo().equalsIgnoreCase(codigo)) {

                Paciente paciente = actual.getDato();

                if (tamanio == 1) {
                    ultimo = null;
                } else {
                    anterior.setSiguiente(actual.getSiguiente());

                    if (actual == ultimo) {
                        ultimo = anterior;
                    }
                }

                paciente.getTurno().setEstado("CANCELADO");

                tamanio--;
                return paciente;
            }

            anterior = actual;
            actual = actual.getSiguiente();
        }

        return null;
    }

    // 7. ELIMINAR EL PRIMER TURNO PENDIENTE
    public Paciente eliminarInicio() {

        if (estaVacia()) {
            return null;
        }

        Nodo inicio = ultimo.getSiguiente();
        Paciente paciente = inicio.getDato();

        if (inicio == ultimo) {
            ultimo = null;
        } else {
            ultimo.setSiguiente(inicio.getSiguiente());
        }

        paciente.getTurno().setEstado("CANCELADO");

        tamanio--;
        return paciente;
    }

    // 8. ELIMINAR EL ULTIMO TURNO PENDIENTE
    public Paciente eliminarFinal() {

        if (estaVacia()) {
            return null;
        }

        Paciente paciente = ultimo.getDato();

        if (ultimo.getSiguiente() == ultimo) {
            ultimo = null;
        } else {
            Nodo anterior = ultimo.getSiguiente();

            while (anterior.getSiguiente() != ultimo) {
                anterior = anterior.getSiguiente();
            }

            anterior.setSiguiente(ultimo.getSiguiente());
            ultimo = anterior;
        }

        paciente.getTurno().setEstado("CANCELADO");

        tamanio--;
        return paciente;
    }

    // 9. REPROGRAMAR PACIENTE (insertarlo en otra posicion)
    public boolean reprogramar(String codigo, int posicion) {

        if (estaVacia() || posicion < 1 || posicion > tamanio) {
            return false;
        }

        Paciente paciente = eliminarPorCodigo(codigo);

        if (paciente == null) {
            return false;
        }

        paciente.getTurno().setEstado("REPROGRAMADO");

        return insertarPosicion(paciente, posicion);
    }

    // 10. BUSCAR PACIENTE POR CODIGO
    public Paciente buscar(String codigo) {

        Nodo nodo = buscarNodo(codigo);

        if (nodo != null) {
            return nodo.getDato();
        }

        return null;
    }

    // 11. MOSTRAR PACIENTES PENDIENTES (recorrer la lista)
    public ArrayList<Paciente> recorrer() {

        ArrayList<Paciente> pacientes = new ArrayList<>();

        if (estaVacia()) {
            return pacientes;
        }

        Nodo actual = ultimo.getSiguiente();

        do {
            pacientes.add(actual.getDato());
            actual = actual.getSiguiente();

        } while (actual != ultimo.getSiguiente());

        return pacientes;
    }

    // 12. CANTIDAD DE PACIENTES REGISTRADOS
    public int getTamanio() {
        return tamanio;
    }

    // 13. PACIENTE QUE SERA ATENDIDO PROXIMAMENTE
    public Paciente verProximo() {

        if (estaVacia()) {
            return null;
        }

        return ultimo.getSiguiente().getDato();
    }

    // 14. ORDENAR POR NUMERO DE TURNO (ascendente)
    public void ordenar() {

        if (tamanio < 2) {
            return;
        }

        boolean huboCambio;

        do {
            huboCambio = false;
            Nodo actual = ultimo.getSiguiente();

            for (int i = 0; i < tamanio - 1; i++) {

                Nodo siguiente = actual.getSiguiente();

                if (actual.getDato().getTurno().getNumeroTurno()
                        > siguiente.getDato().getTurno().getNumeroTurno()) {

                    Paciente auxiliar = actual.getDato();
                    actual.setDato(siguiente.getDato());
                    siguiente.setDato(auxiliar);
                    huboCambio = true;
                }

                actual = siguiente;
            }

        } while (huboCambio);
    }

    // 15. INTERCAMBIAR LAS POSICIONES DE DOS PACIENTES
    public boolean intercambiar(int posicion1, int posicion2) {

        if (posicion1 < 1 || posicion1 > tamanio
                || posicion2 < 1 || posicion2 > tamanio) {
            return false;
        }

        if (posicion1 == posicion2) {
            return true;
        }

        Nodo nodo1 = obtenerNodo(posicion1);
        Nodo nodo2 = obtenerNodo(posicion2);

        Paciente auxiliar = nodo1.getDato();
        nodo1.setDato(nodo2.getDato());
        nodo2.setDato(auxiliar);

        return true;
    }

    // 16. MODIFICAR LOS DATOS DE UN PACIENTE
    public boolean modificar(String codigo, String nombres,
                             String apellidos, String dni,
                             String especialidad) {

        Nodo nodo = buscarNodo(codigo);

        if (nodo == null) {
            return false;
        }

        nodo.getDato().setNombres(nombres);
        nodo.getDato().setApellidos(apellidos);
        nodo.getDato().setDni(dni);
        nodo.getDato().setEspecialidad(especialidad);

        return true;
    }

}
