#!/bin/sh
mkdir -p out
javac -encoding UTF-8 -d out src/Modelo/*.java src/DAO/*.java src/Vista/*.java && java -Dfile.encoding=UTF-8 -cp out Vista.Principal
