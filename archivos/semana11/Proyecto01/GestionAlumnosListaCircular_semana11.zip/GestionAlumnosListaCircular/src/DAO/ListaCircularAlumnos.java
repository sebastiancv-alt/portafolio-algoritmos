package DAO;

import Modelo.Alumno;
import Modelo.Nodo;
import java.util.ArrayList;

public class ListaCircularAlumnos {

    private Nodo ultimo;
    private int tamanio;

    public ListaCircularAlumnos() {
        ultimo = null;
        tamanio = 0;
    }

    // Verificar si la lista esta vacia
    public boolean estaVacia() {
        return ultimo == null;
    }

    // Verificar si el codigo ya existe
    private boolean existeCodigo(String codigo) {
        return buscar(codigo) != null;
    }

    // Obtener un nodo segun su posicion (inicia en 1)
    private Nodo obtenerNodo(int posicion) {

        if (posicion < 1 || posicion > tamanio) {
            return null;
        }

        Nodo actual = ultimo.getSiguiente();

        for (int i = 1; i < posicion; i++) {
            actual = actual.getSiguiente();
        }

        return actual;
    }

    // 1. INSERTAR AL INICIO
    public boolean insertarInicio(Alumno alumno) {

        if (alumno == null || existeCodigo(alumno.getCodigo())) {
            return false;
        }

        Nodo nuevo = new Nodo(alumno);

        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
        }

        tamanio++;
        return true;
    }

    // 2. INSERTAR AL FINAL
    public boolean insertarFinal(Alumno alumno) {

        if (alumno == null || existeCodigo(alumno.getCodigo())) {
            return false;
        }

        Nodo nuevo = new Nodo(alumno);

        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }

        tamanio++;
        return true;
    }

    // 3. INSERTAR EN UNA POSICION
    public boolean insertarPosicion(Alumno alumno, int posicion) {

        if (alumno == null || existeCodigo(alumno.getCodigo())
                || posicion < 1 || posicion > tamanio + 1) {
            return false;
        }

        if (posicion == 1) {
            return insertarInicio(alumno);
        }

        if (posicion == tamanio + 1) {
            return insertarFinal(alumno);
        }

        Nodo anterior = obtenerNodo(posicion - 1);
        Nodo nuevo = new Nodo(alumno);

        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);

        tamanio++;
        return true;
    }

    // 4. INSERTAR POR REFERENCIA
    // Inserta despues del alumno indicado por su codigo
    public boolean insertarReferencia(String codigoReferencia,
                                     Alumno alumno) {

        if (alumno == null || existeCodigo(alumno.getCodigo())) {
            return false;
        }

        Nodo actual = buscarNodo(codigoReferencia);

        if (actual == null) {
            return false;
        }

        Nodo nuevo = new Nodo(alumno);

        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);

        if (actual == ultimo) {
            ultimo = nuevo;
        }

        tamanio++;
        return true;
    }
    
        // BUSCAR UN NODO POR CODIGO
    private Nodo buscarNodo(String codigo) {

        if (estaVacia() || codigo == null) {
            return null;
        }

        Nodo actual = ultimo.getSiguiente();

        do {
            if (actual.getDato().getCodigo()
                    .equalsIgnoreCase(codigo)) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != ultimo.getSiguiente());

        return null;
    }
    
        // 9. BUSCAR UN ALUMNO
    public Alumno buscar(String codigo) {

        Nodo nodo = buscarNodo(codigo);

        if (nodo != null) {
            return nodo.getDato();
        }

        return null;
    }
    
        // 10. RECORRER LA LISTA
    public ArrayList<Alumno> recorrer() {

        ArrayList<Alumno> alumnos = new ArrayList<>();

        if (estaVacia()) {
            return alumnos;
        }

        Nodo actual = ultimo.getSiguiente();

        do {
            alumnos.add(actual.getDato());
            actual = actual.getSiguiente();

        } while (actual != ultimo.getSiguiente());

        return alumnos;
    }

    // 5. ELIMINAR AL INICIO
    public Alumno eliminarInicio() {

        if (estaVacia()) {
            return null;
        }

        Nodo inicio = ultimo.getSiguiente();
        Alumno dato = inicio.getDato();

        if (inicio == ultimo) {
            ultimo = null;
        } else {
            ultimo.setSiguiente(inicio.getSiguiente());
        }

        tamanio--;
        return dato;
    }

    // 6. ELIMINAR AL FINAL
    public Alumno eliminarFinal() {

        if (estaVacia()) {
            return null;
        }

        Alumno dato = ultimo.getDato();

        if (ultimo.getSiguiente() == ultimo) {
            ultimo = null;
        } else {
            Nodo anterior = ultimo.getSiguiente();

            while (anterior.getSiguiente() != ultimo) {
                anterior = anterior.getSiguiente();
            }

            anterior.setSiguiente(ultimo.getSiguiente());
            ultimo = anterior;
        }

        tamanio--;
        return dato;
    }

    // 7. ELIMINAR EN UNA POSICION
    public Alumno eliminarPosicion(int posicion) {

        if (estaVacia() || posicion < 1 || posicion > tamanio) {
            return null;
        }

        if (posicion == 1) {
            return eliminarInicio();
        }

        if (posicion == tamanio) {
            return eliminarFinal();
        }

        Nodo anterior = obtenerNodo(posicion - 1);
        Nodo eliminado = anterior.getSiguiente();

        anterior.setSiguiente(eliminado.getSiguiente());

        tamanio--;
        return eliminado.getDato();
    }

    // 8. ELIMINAR POR REFERENCIA (codigo)
    public Alumno eliminarReferencia(String codigo) {

        if (estaVacia() || codigo == null) {
            return null;
        }

        Nodo anterior = ultimo;
        Nodo actual = ultimo.getSiguiente();

        for (int i = 0; i < tamanio; i++) {

            if (actual.getDato().getCodigo().equalsIgnoreCase(codigo)) {

                Alumno dato = actual.getDato();

                if (tamanio == 1) {
                    ultimo = null;
                } else {
                    anterior.setSiguiente(actual.getSiguiente());

                    if (actual == ultimo) {
                        ultimo = anterior;
                    }
                }

                tamanio--;
                return dato;
            }

            anterior = actual;
            actual = actual.getSiguiente();
        }

        return null;
    }

    // 11. ORDENAR LA LISTA (por codigo, ascendente)
    public void ordenar() {

        if (tamanio < 2) {
            return;
        }

        boolean huboCambio;

        do {
            huboCambio = false;
            Nodo actual = ultimo.getSiguiente();

            for (int i = 0; i < tamanio - 1; i++) {

                Nodo siguiente = actual.getSiguiente();

                if (actual.getDato().getCodigo().compareToIgnoreCase(
                        siguiente.getDato().getCodigo()) > 0) {

                    Alumno auxiliar = actual.getDato();
                    actual.setDato(siguiente.getDato());
                    siguiente.setDato(auxiliar);
                    huboCambio = true;
                }

                actual = siguiente;
            }

        } while (huboCambio);
    }

    // 12. INTERCAMBIAR DOS ELEMENTOS
    public boolean intercambiar(int posicion1, int posicion2) {

        if (posicion1 < 1 || posicion1 > tamanio
                || posicion2 < 1 || posicion2 > tamanio) {
            return false;
        }

        if (posicion1 == posicion2) {
            return true;
        }

        Nodo nodo1 = obtenerNodo(posicion1);
        Nodo nodo2 = obtenerNodo(posicion2);

        Alumno auxiliar = nodo1.getDato();
        nodo1.setDato(nodo2.getDato());
        nodo2.setDato(auxiliar);

        return true;
    }

    // 13. OBTENER EL TAMANIO
    public int getTamanio() {
        return tamanio;
    }

    // 14. MODIFICAR LOS DATOS DE UN ALUMNO
    public boolean modificar(String codigo, String nombres,
                             String carrera, int semestre) {

        Nodo nodo = buscarNodo(codigo);

        if (nodo == null) {
            return false;
        }

        nodo.getDato().setNombres(nombres);
        nodo.getDato().setCarrera(carrera);
        nodo.getDato().setSemestre(semestre);

        return true;
    }

}
