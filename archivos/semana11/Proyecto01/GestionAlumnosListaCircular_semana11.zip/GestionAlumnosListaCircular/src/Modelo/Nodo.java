package Modelo;

public class Nodo {

    private Alumno dato;
    private Nodo siguiente;

    public Nodo(Alumno dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public Alumno getDato() {
        return dato;
    }

    public void setDato(Alumno dato) {
        this.dato = dato;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
}
