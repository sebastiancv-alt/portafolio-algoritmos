@echo off
chcp 65001 >nul
if not exist out mkdir out
javac -encoding UTF-8 -d out src\Modelo\*.java src\DAO\*.java src\Vista\*.java
if errorlevel 1 pause & exit /b
java -Dfile.encoding=UTF-8 -cp out Vista.Principal
pause
