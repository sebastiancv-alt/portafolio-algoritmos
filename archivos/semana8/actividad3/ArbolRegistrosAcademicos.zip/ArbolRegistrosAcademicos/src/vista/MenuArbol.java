package vista;

import dao.ArbolRegistros;
import modelo.RegistroAcademico;
import java.util.Scanner;

/**
 * Vista de consola: muestra el menú, valida la entrada del usuario y delega toda la lógica en el DAO.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class MenuArbol {

    private static final String RUTA_DATOS = "datos_prueba/registros.csv";

    /**
     * Punto de entrada: muestra el menú y atiende las opciones hasta que el usuario elige salir.
     *
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArbolRegistros arbol = new ArbolRegistros();
        int opcion = 0;

        do {
            System.out.println("\n=================================================");
            System.out.println("  REGISTROS ACADÉMICOS (ÁRBOL BINARIO DE BÚSQUEDA)");
            System.out.println("=================================================");
            System.out.println("1. Registrar e insertar registro en el árbol");
            System.out.println("2. Buscar registro por código");
            System.out.println("3. Mostrar registros en orden ascendente");
            System.out.println("4. Calcular cantidad total de registros");
            System.out.println("5. Determinar la altura del árbol");
            System.out.println("6. Contar registros por estado (criterio)");
            System.out.println("7. Mostrar otros recorridos (preorden / postorden)");
            System.out.println("8. Cargar datos de prueba");
            System.out.println("9. Salir");
            System.out.print("Seleccione una opción: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine(); // Limpiar buffer
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                teclado.next();
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    int codigo = leerEntero(teclado, "Ingrese Código del registro: ");
                    System.out.print("Ingrese Nombre del estudiante: ");
                    String estudiante = teclado.nextLine().trim();
                    System.out.print("Ingrese Estado (Matriculado/Pendiente/Observado/Certificado): ");
                    String estado = teclado.nextLine().trim();
                    if (codigo <= 0 || estudiante.isEmpty() || estado.isEmpty()) {
                        System.out.println("Datos inválidos: complete todos los campos correctamente.");
                    } else if (arbol.insertar(new RegistroAcademico(codigo, estudiante, estado))) {
                        System.out.println("RegistroAcademico registrado e insertado en el árbol.");
                    }
                    break;
                case 2:
                    int buscar = leerEntero(teclado, "Ingrese el código a buscar: ");
                    arbol.buscar(buscar);
                    break;
                case 3:
                    arbol.mostrarAscendente();
                    break;
                case 4:
                    arbol.calcularTotal();
                    break;
                case 5:
                    arbol.calcularAltura();
                    break;
                case 6:
                    System.out.print("Ingrese el estado a contar: ");
                    String criterio = teclado.nextLine();
                    arbol.contarPorEstado(criterio);
                    break;
                case 7:
                    arbol.mostrarOtrosRecorridos();
                    break;
                case 8:
                    arbol.cargarDatosPrueba(RUTA_DATOS);
                    break;
                case 9:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 9);

        teclado.close();
    }

    /**
     * Lee un entero con validación: repite la pregunta hasta recibir un valor válido.
     *
     * @param teclado lector de consola
     * @param mensaje texto a mostrar
     * @return valor entero leído
     */
    private static int leerEntero(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextInt()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        int valor = teclado.nextInt();
        teclado.nextLine();
        return valor;
    }
}
