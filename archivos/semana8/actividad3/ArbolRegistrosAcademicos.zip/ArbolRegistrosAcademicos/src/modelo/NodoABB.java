package modelo;

/**
 * Nodo del árbol binario de búsqueda: guarda un expediente y los enlaces a sus subárboles izquierdo y derecho.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class NodoABB {

    private RegistroAcademico expediente;
    private NodoABB izquierdo; // Subárbol de códigos menores
    private NodoABB derecho;   // Subárbol de códigos mayores

    public NodoABB(RegistroAcademico expediente) {
        this.expediente = expediente;
        this.izquierdo = null;
        this.derecho = null;
    }

    public RegistroAcademico getRegistroAcademico() {
        return expediente;
    }

    public void setRegistroAcademico(RegistroAcademico expediente) {
        this.expediente = expediente;
    }

    public NodoABB getIzquierdo() {
        return izquierdo;
    }

    public void setIzquierdo(NodoABB izquierdo) {
        this.izquierdo = izquierdo;
    }

    public NodoABB getDerecho() {
        return derecho;
    }

    public void setDerecho(NodoABB derecho) {
        this.derecho = derecho;
    }
}
