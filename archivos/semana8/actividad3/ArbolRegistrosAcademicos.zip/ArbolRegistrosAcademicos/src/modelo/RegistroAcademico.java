package modelo;

/**
 * Modelo que representa un expediente académico: código, nombre del estudiante y estado.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class RegistroAcademico {

    private int codigo;
    private String estudiante;
    private String estado; // Matriculado, Pendiente, Observado, Certificado

    /**
     * Crea un expediente con todos sus datos.
     *
     * @param codigo código único del expediente
     * @param estudiante nombre del estudiante
     * @param estado estado del expediente
     */
    public RegistroAcademico(int codigo, String estudiante, String estado) {
        this.codigo = codigo;
        this.estudiante = estudiante;
        this.estado = estado;
    }

    // Getters y Setters
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(String estudiante) {
        this.estudiante = estudiante;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "RegistroAcademico [Código: " + codigo + ", Estudiante: " + estudiante
                + ", Estado: " + estado + "]";
    }
}
