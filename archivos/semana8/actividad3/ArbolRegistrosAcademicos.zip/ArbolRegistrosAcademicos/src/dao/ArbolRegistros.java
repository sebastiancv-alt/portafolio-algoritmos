package dao;

import modelo.RegistroAcademico;
import modelo.NodoABB;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * DAO que organiza los registros en un <b>árbol binario de búsqueda</b> ordenado por código.
 * La raíz es privada; todas las consultas se resuelven con recorridos recursivos (tiempo O(h) al buscar/insertar y O(n) al recorrer).
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class ArbolRegistros {

    private NodoABB raiz; // Raíz del árbol binario de búsqueda

    /**
     * Verifica si el árbol no tiene registros.
     *
     * @return true si la raíz es null
     */
    public boolean estaVacio() {
        return raiz == null;
    }

    /**
     * Inserta un registro en el árbol si su código no existe (opciones 1 y 2).
     *
     * @param registro registro a insertar
     * @return true si se insertó; false si el código ya existe
     */
    public boolean insertar(RegistroAcademico registro) {
        if (existeCodigo(raiz, registro.getCodigo())) {
            System.out.println("Error: ya existe un registro con el código " + registro.getCodigo());
            return false;
        }
        raiz = insertarRecursivo(raiz, registro);
        return true;
    }

    // 1) insertarRecursivo(NodoABB nodo, RegistroAcademico registro) [Recursivo]
    /**
     * Inserta recursivamente: menores a la izquierda, mayores a la derecha.
     * Caso base: posición libre (nodo null), donde se crea el nuevo nodo.
     *
     * @param nodo raíz del subárbol actual
     * @param registro registro a insertar
     * @return raíz del subárbol ya actualizada
     */
    private NodoABB insertarRecursivo(NodoABB nodo, RegistroAcademico registro) {
        if (nodo == null) { // Caso base: posición libre, se crea el nodo
            return new NodoABB(registro);
        }
        if (registro.getCodigo() < nodo.getRegistroAcademico().getCodigo()) {
            nodo.setIzquierdo(insertarRecursivo(nodo.getIzquierdo(), registro)); // Subárbol izquierdo
        } else {
            nodo.setDerecho(insertarRecursivo(nodo.getDerecho(), registro));     // Subárbol derecho
        }
        return nodo;
    }

    /**
     * Comprueba recursivamente si un código ya está registrado en el árbol.
     *
     * @param nodo raíz del subárbol actual
     * @param codigo código a verificar
     * @return true si el código existe
     */
    private boolean existeCodigo(NodoABB nodo, int codigo) {
        if (nodo == null) {
            return false;
        }
        int actual = nodo.getRegistroAcademico().getCodigo();
        if (codigo == actual) {
            return true;
        }
        return codigo < actual ? existeCodigo(nodo.getIzquierdo(), codigo) : existeCodigo(nodo.getDerecho(), codigo);
    }

    /**
     * Busca un registro por su código e informa el camino recorrido (opción 2).
     *
     * @param codigo código a buscar
     * @return el registro, o null si no existe
     */
    public RegistroAcademico buscar(int codigo) {
        if (estaVacio()) {
            System.out.println("El árbol está vacío. No hay registros registrados.");
            return null;
        }
        System.out.println("\nBúsqueda recursiva del código " + codigo + ":");
        NodoABB nodo = buscarRecursivo(raiz, codigo);
        if (nodo == null) {
            System.out.println("Resultado: no existe un registro con el código " + codigo);
            return null;
        }
        System.out.println("RegistroAcademico encontrado: " + nodo.getRegistroAcademico());
        return nodo.getRegistroAcademico();
    }

    // 2) buscarRecursivo(NodoABB nodo, int codigo) [Recursivo]
    /**
     * Búsqueda recursiva en el ABB: en cada nivel descarta un subárbol completo. Tiempo O(h).
     *
     * @param nodo raíz del subárbol actual
     * @param codigo código buscado
     * @return nodo encontrado, o null
     */
    private NodoABB buscarRecursivo(NodoABB nodo, int codigo) {
        if (nodo == null) { // Caso base: se llegó al final sin encontrarlo
            return null;
        }
        System.out.println("   Visitando nodo: " + nodo.getRegistroAcademico().getCodigo());
        if (codigo == nodo.getRegistroAcademico().getCodigo()) { // Caso base: encontrado
            return nodo;
        }
        if (codigo < nodo.getRegistroAcademico().getCodigo()) {
            return buscarRecursivo(nodo.getIzquierdo(), codigo); // Se descarta la mitad derecha
        }
        return buscarRecursivo(nodo.getDerecho(), codigo);       // Se descarta la mitad izquierda
    }

    /**
     * Muestra los registros en orden ascendente por código (opción 3).
     */
    public void mostrarAscendente() {
        if (estaVacio()) {
            System.out.println("El árbol está vacío. No hay registros registrados.");
            return;
        }
        System.out.println("\n--- EXPEDIENTES EN ORDEN ASCENDENTE (inorden) ---");
        inordenRecursivo(raiz);
    }

    // 3) inordenRecursivo(NodoABB nodo) [Recursivo]
    /**
     * Recorrido inorden recursivo: izquierdo, nodo, derecho. En un ABB entrega los códigos ordenados.
     *
     * @param nodo raíz del subárbol actual
     */
    private void inordenRecursivo(NodoABB nodo) {
        if (nodo == null) { // Caso base: subárbol vacío
            return;
        }
        inordenRecursivo(nodo.getIzquierdo());     // 1.º subárbol izquierdo
        System.out.println(nodo.getRegistroAcademico());  // 2.º se visita el nodo
        inordenRecursivo(nodo.getDerecho());       // 3.º subárbol derecho
    }

    /**
     * Calcula la cantidad total de registros (opción 4).
     *
     * @return cantidad de registros
     */
    public int calcularTotal() {
        int total = contarRecursivo(raiz);
        System.out.println("Cantidad total de registros: " + total);
        return total;
    }

    // 4) contarRecursivo(NodoABB nodo) [Recursivo]
    /**
     * Cuenta los nodos: 1 (el nodo actual) más los de cada subárbol.
     *
     * @param nodo raíz del subárbol actual
     * @return cantidad de nodos del subárbol
     */
    private int contarRecursivo(NodoABB nodo) {
        if (nodo == null) { // Caso base
            return 0;
        }
        return 1 + contarRecursivo(nodo.getIzquierdo()) + contarRecursivo(nodo.getDerecho());
    }

    /**
     * Determina la altura del árbol en niveles (opción 5).
     *
     * @return altura del árbol (0 si está vacío)
     */
    public int calcularAltura() {
        int altura = alturaRecursiva(raiz);
        System.out.println("Altura del árbol: " + altura + " nivel(es)");
        return altura;
    }

    // 5) alturaRecursiva(NodoABB nodo) [Recursivo]
    /**
     * Altura = 1 + la mayor altura entre los dos subárboles. Un árbol vacío tiene altura 0.
     *
     * @param nodo raíz del subárbol actual
     * @return altura del subárbol
     */
    private int alturaRecursiva(NodoABB nodo) {
        if (nodo == null) { // Caso base: un árbol vacío tiene altura 0
            return 0;
        }
        int alturaIzquierda = alturaRecursiva(nodo.getIzquierdo());
        int alturaDerecha = alturaRecursiva(nodo.getDerecho());
        return 1 + Math.max(alturaIzquierda, alturaDerecha);
    }

    /**
     * Cuenta los registros cuyo estado coincide con el criterio (opción 6).
     *
     * @param estado estado a buscar, sin distinguir mayúsculas
     * @return cantidad de registros que cumplen el criterio
     */
    public int contarPorEstado(String estado) {
        int total = contarPorEstadoRecursivo(raiz, estado.trim());
        System.out.println("RegistroAcademicos con estado \"" + estado.trim() + "\": " + total);
        return total;
    }

    // 6) contarPorEstadoRecursivo(NodoABB nodo, String estado) [Recursivo]
    /**
     * Recorre todo el árbol y suma 1 por cada registro con el estado indicado.
     *
     * @param nodo raíz del subárbol actual
     * @param estado estado buscado
     * @return cantidad en el subárbol
     */
    private int contarPorEstadoRecursivo(NodoABB nodo, String estado) {
        if (nodo == null) { // Caso base
            return 0;
        }
        int coincide = nodo.getRegistroAcademico().getEstado().equalsIgnoreCase(estado) ? 1 : 0;
        return coincide
                + contarPorEstadoRecursivo(nodo.getIzquierdo(), estado)
                + contarPorEstadoRecursivo(nodo.getDerecho(), estado);
    }

    /**
     * Muestra los recorridos preorden y postorden (opción 7).
     */
    public void mostrarOtrosRecorridos() {
        if (estaVacio()) {
            System.out.println("El árbol está vacío. No hay registros registrados.");
            return;
        }
        StringBuilder pre = new StringBuilder();
        StringBuilder post = new StringBuilder();
        preordenRecursivo(raiz, pre);
        postordenRecursivo(raiz, post);
        System.out.println("\nPreorden  (raíz, izq, der): " + pre.toString().trim());
        System.out.println("Postorden (izq, der, raíz): " + post.toString().trim());
    }

    // 7) preordenRecursivo(NodoABB nodo, StringBuilder salida) [Recursivo]
    /**
     * Recorrido preorden recursivo: nodo, izquierdo, derecho.
     *
     * @param nodo raíz del subárbol actual
     * @param salida acumulador de códigos
     */
    private void preordenRecursivo(NodoABB nodo, StringBuilder salida) {
        if (nodo == null) {
            return;
        }
        salida.append(nodo.getRegistroAcademico().getCodigo()).append(" ");
        preordenRecursivo(nodo.getIzquierdo(), salida);
        preordenRecursivo(nodo.getDerecho(), salida);
    }

    /**
     * Recorrido postorden recursivo: izquierdo, derecho, nodo.
     *
     * @param nodo raíz del subárbol actual
     * @param salida acumulador de códigos
     */
    private void postordenRecursivo(NodoABB nodo, StringBuilder salida) {
        if (nodo == null) {
            return;
        }
        postordenRecursivo(nodo.getIzquierdo(), salida);
        postordenRecursivo(nodo.getDerecho(), salida);
        salida.append(nodo.getRegistroAcademico().getCodigo()).append(" ");
    }

    /**
     * Carga datos de ejemplo desde un archivo CSV; omite los códigos repetidos y controla los errores de lectura.
     *
     * @param ruta ruta del archivo CSV
     */
    public void cargarDatosPrueba(String ruta) {
        int cargados = 0;
        int omitidos = 0;
        try (BufferedReader lector = new BufferedReader(
                new InputStreamReader(new FileInputStream(ruta), StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (linea.trim().isEmpty() || linea.startsWith("#")) {
                    continue; // Se ignoran comentarios y líneas vacías
                }
                String[] campos = linea.split(",");
                RegistroAcademico nuevo = new RegistroAcademico(Integer.parseInt(campos[0].trim()),
                        campos[1].trim(), campos[2].trim());
                if (existeCodigo(raiz, nuevo.getCodigo())) {
                    omitidos++; // Código repetido: no se duplica
                } else {
                    raiz = insertarRecursivo(raiz, nuevo);
                    cargados++;
                }
            }
            System.out.println("Datos de prueba cargados: " + cargados + " registro(s)"
                    + (omitidos > 0 ? " (" + omitidos + " omitido(s) por código repetido)." : "."));
        } catch (IOException | RuntimeException e) {
            System.out.println("No se pudo cargar el archivo " + ruta + ": " + e.getMessage());
        }
    }
}
