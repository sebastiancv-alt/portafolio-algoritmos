package modelo;

import java.util.Locale;

/**
 * Modelo que representa un fichero localizado durante el recorrido: nombre, ruta y tamaño en bytes.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class InfoFichero {

    private String nombre;
    private String ruta;
    private long tamano; // en bytes

    /**
     * Crea el registro de un archivo.
     *
     * @param nombre nombre del archivo con su extensión
     * @param ruta ruta completa del archivo
     * @param tamano tamaño en bytes
     */
    public InfoFichero(String nombre, String ruta, long tamano) {
        this.nombre = nombre;
        this.ruta = ruta;
        this.tamano = tamano;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public long getTamano() {
        return tamano;
    }

    public void setTamano(long tamano) {
        this.tamano = tamano;
    }

    /**
     * Obtiene la extensión del archivo en minúsculas.
     *
     * @return extensión con punto, o "(sin extensión)"
     */
    public String getExtension() {
        int punto = nombre.lastIndexOf('.');
        if (punto <= 0 || punto == nombre.length() - 1) {
            return "(sin extensión)";
        }
        return nombre.substring(punto).toLowerCase();
    }

    /**
     * Convierte una cantidad de bytes a una unidad legible (B, KB o MB).
     *
     * @param bytes tamaño en bytes
     * @return texto con el tamaño formateado
     */
    public static String formatearTamano(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        double kb = bytes / 1024.0;
        if (kb < 1024) {
            return String.format(Locale.US, "%.1f KB", kb);
        }
        return String.format(Locale.US, "%.2f MB", kb / 1024.0);
    }

    @Override
    public String toString() {
        return nombre + " | " + formatearTamano(tamano) + " | " + ruta;
    }
}
