package vista;

import dao.ExploradorCarpetas;
import java.util.Scanner;

/**
 * Vista de consola: muestra el menú, valida la entrada del usuario y delega toda la lógica en el DAO.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class MenuExplorador {

    private static final String RUTA_PRUEBA = "datos_prueba/Empresa";

    /**
     * Punto de entrada: muestra el menú y atiende las opciones hasta que el usuario elige salir.
     *
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ExploradorCarpetas explorador = new ExploradorCarpetas();
        int opcion = 0;

        do {
            System.out.println("\n=================================================");
            System.out.println("  GESTIÓN Y ANÁLISIS DE ARCHIVOS (RECURSIVIDAD)");
            System.out.println("=================================================");
            System.out.println("1. Seleccionar directorio raíz");
            System.out.println("2. Listar archivos por carpeta y subcarpeta");
            System.out.println("3. Contabilizar archivos");
            System.out.println("4. Calcular tamaño total");
            System.out.println("5. Buscar archivos por nombre o extensión");
            System.out.println("6. Reporte de cantidad de archivos por tipo");
            System.out.println("7. Mostrar estructura jerárquica de directorios");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opción: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine(); // Limpiar buffer
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                teclado.next();
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese la ruta del directorio raíz (Enter = " + RUTA_PRUEBA + "): ");
                    String ruta = teclado.nextLine().trim();
                    if (ruta.isEmpty()) {
                        ruta = RUTA_PRUEBA;
                    }
                    explorador.seleccionarRaiz(ruta);
                    break;
                case 2:
                    explorador.listarArchivos();
                    break;
                case 3:
                    explorador.contarArchivos();
                    break;
                case 4:
                    explorador.calcularTamanoTotal();
                    break;
                case 5:
                    System.out.print("Ingrese nombre o extensión a buscar (ej. factura o .pdf): ");
                    String criterio = teclado.nextLine();
                    explorador.buscarArchivos(criterio);
                    break;
                case 6:
                    explorador.reportePorTipo();
                    break;
                case 7:
                    explorador.mostrarEstructura();
                    break;
                case 8:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 8);

        teclado.close();
    }
}
