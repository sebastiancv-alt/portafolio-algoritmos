package dao;

import modelo.InfoFichero;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

/**
 * DAO que explora una jerarquía de carpetas de forma <b>recursiva</b>.
 * El directorio raíz es privado: la Vista solo usa los métodos de negocio publicados.
 * Cada operación recursiva visita cada elemento una sola vez: tiempo O(n) y espacio O(h), con h = niveles de carpetas.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class ExploradorCarpetas {

    private File raiz;                 // Directorio raíz a analizar
    private int carpetasInaccesibles;  // Carpetas sin permiso de lectura

    // 1) seleccionarRaiz(String ruta)
    /**
     * Selecciona el directorio raíz que se va a analizar.
     *
     * @param ruta ruta (relativa o absoluta) de la carpeta
     * @return true si la ruta existe y es un directorio
     */
    public boolean seleccionarRaiz(String ruta) {
        File candidato = new File(ruta);
        if (!candidato.exists() || !candidato.isDirectory()) {
            System.out.println("Error: la ruta no existe o no es un directorio: " + ruta);
            return false;
        }
        raiz = candidato;
        System.out.println("Directorio raíz seleccionado: " + raiz.getPath());
        return true;
    }

    /**
     * Comprueba que ya se haya seleccionado una raíz antes de ejecutar un reporte.
     *
     * @return true si hay una raíz válida
     */
    private boolean validarRaiz() {
        if (raiz == null) {
            System.out.println("Primero seleccione el directorio raíz (opción 1).");
            return false;
        }
        return true;
    }

    /**
     * Lista los archivos de cada carpeta y subcarpeta (opción 2).
     */
    public void listarArchivos() {
        if (!validarRaiz()) {
            return;
        }
        System.out.println("\n--- ARCHIVOS POR CARPETA Y SUBCARPETA ---");
        listarRecursivo(raiz);
    }

    // 2) listarRecursivo(File carpeta) [Recursivo]
    /**
     * Muestra los archivos de una carpeta y se llama a sí mismo por cada subcarpeta.
     * Caso base: carpeta sin acceso (listFiles() devuelve null).
     *
     * @param carpeta carpeta que se está procesando
     */
    private void listarRecursivo(File carpeta) {
        File[] contenido = carpeta.listFiles();
        if (contenido == null) { // Caso base: carpeta sin acceso
            System.out.println("[!] Sin acceso a: " + carpeta.getPath());
            return;
        }
        Arrays.sort(contenido);
        System.out.println("\n[Carpeta] " + carpeta.getPath());
        for (File elemento : contenido) {
            if (elemento.isFile()) {
                System.out.println("   - " + elemento.getName() + " (" + InfoFichero.formatearTamano(elemento.length()) + ")");
            }
        }
        for (File elemento : contenido) {
            if (elemento.isDirectory()) {
                listarRecursivo(elemento); // Caso recursivo: cada subcarpeta
            }
        }
    }

    /**
     * Contabiliza todos los archivos del árbol de directorios (opción 3).
     *
     * @return total de archivos, o -1 si no hay raíz
     */
    public int contarArchivos() {
        if (!validarRaiz()) {
            return -1;
        }
        int total = contarRecursivo(raiz);
        System.out.println("Total de archivos encontrados: " + total);
        return total;
    }

    // 3) contarRecursivo(File carpeta) [Recursivo]
    /**
     * Cuenta los archivos de una carpeta sumando el resultado de cada subcarpeta.
     *
     * @param carpeta carpeta que se está procesando
     * @return archivos encontrados en esa rama
     */
    private int contarRecursivo(File carpeta) {
        File[] contenido = carpeta.listFiles();
        if (contenido == null) { // Caso base: carpeta sin acceso
            return 0;
        }
        int total = 0;
        for (File elemento : contenido) {
            if (elemento.isFile()) {
                total++;
            } else if (elemento.isDirectory()) {
                total += contarRecursivo(elemento); // Caso recursivo
            }
        }
        return total;
    }

    /**
     * Calcula el tamaño total de los archivos accesibles (opción 4).
     *
     * @return tamaño total en bytes, o -1 si no hay raíz
     */
    public long calcularTamanoTotal() {
        if (!validarRaiz()) {
            return -1;
        }
        carpetasInaccesibles = 0;
        long total = tamanoRecursivo(raiz);
        System.out.println("Tamaño total de los archivos accesibles: "
                + InfoFichero.formatearTamano(total) + " (" + total + " bytes)");
        if (carpetasInaccesibles > 0) {
            System.out.println("Carpetas sin acceso omitidas: " + carpetasInaccesibles);
        }
        return total;
    }

    // 4) tamanoRecursivo(File carpeta) [Recursivo]
    /**
     * Suma el tamaño de los archivos de una carpeta y de todas sus subcarpetas.
     * Las carpetas sin permiso de lectura se cuentan como inaccesibles y aportan 0 bytes.
     *
     * @param carpeta carpeta que se está procesando
     * @return bytes acumulados en esa rama
     */
    private long tamanoRecursivo(File carpeta) {
        File[] contenido = carpeta.listFiles();
        if (contenido == null) { // Caso base: no se puede leer la carpeta
            carpetasInaccesibles++;
            return 0;
        }
        long total = 0;
        for (File elemento : contenido) {
            if (elemento.isFile()) {
                total += elemento.length();
            } else if (elemento.isDirectory()) {
                total += tamanoRecursivo(elemento); // Caso recursivo
            }
        }
        return total;
    }

    /**
     * Busca archivos por nombre o por extensión (opción 5).
     * Si el criterio empieza con punto (ej. ".pdf") se busca por extensión; si no, por nombre.
     *
     * @param criterio texto a buscar
     */
    public void buscarArchivos(String criterio) {
        if (!validarRaiz()) {
            return;
        }
        String clave = criterio.trim().toLowerCase();
        if (clave.isEmpty()) {
            System.out.println("Debe ingresar un nombre o una extensión.");
            return;
        }
        ArrayList<InfoFichero> resultados = new ArrayList<>();
        buscarRecursivo(raiz, clave, resultados);
        System.out.println("\n--- RESULTADOS PARA \"" + criterio.trim() + "\" ---");
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron archivos con ese criterio.");
            return;
        }
        for (InfoFichero archivo : resultados) {
            System.out.println(archivo);
        }
        System.out.println("Total encontrados: " + resultados.size());
    }

    // 5) buscarRecursivo(File carpeta, String clave, ArrayList<InfoFichero> resultados) [Recursivo]
    /**
     * Recorre las carpetas y agrega a la lista los archivos que cumplen el criterio.
     *
     * @param carpeta carpeta que se está procesando
     * @param clave criterio ya normalizado a minúsculas
     * @param resultados lista donde se acumulan las coincidencias
     */
    private void buscarRecursivo(File carpeta, String clave, ArrayList<InfoFichero> resultados) {
        File[] contenido = carpeta.listFiles();
        if (contenido == null) { // Caso base
            return;
        }
        Arrays.sort(contenido);
        for (File elemento : contenido) {
            if (elemento.isDirectory()) {
                buscarRecursivo(elemento, clave, resultados); // Caso recursivo
            } else {
                String nombre = elemento.getName().toLowerCase();
                // Si empieza con punto se busca por extensión; si no, por nombre
                boolean coincide = clave.startsWith(".") ? nombre.endsWith(clave) : nombre.contains(clave);
                if (coincide) {
                    resultados.add(new InfoFichero(elemento.getName(), elemento.getPath(), elemento.length()));
                }
            }
        }
    }

    /**
     * Genera el reporte de cantidad de archivos por tipo o extensión (opción 6).
     */
    public void reportePorTipo() {
        if (!validarRaiz()) {
            return;
        }
        TreeMap<String, Integer> conteo = new TreeMap<>();
        contarPorTipo(raiz, conteo);
        System.out.println("\n--- CANTIDAD DE ARCHIVOS POR TIPO ---");
        if (conteo.isEmpty()) {
            System.out.println("No hay archivos para reportar.");
            return;
        }
        for (Map.Entry<String, Integer> fila : conteo.entrySet()) {
            System.out.println(String.format("%-16s : %d archivo(s)", fila.getKey(), fila.getValue()));
        }
    }

    // 6) contarPorTipo(File carpeta, TreeMap<String, Integer> conteo) [Recursivo]
    /**
     * Cuenta recursivamente los archivos de cada extensión en un mapa ordenado.
     *
     * @param carpeta carpeta que se está procesando
     * @param conteo mapa extensión → cantidad
     */
    private void contarPorTipo(File carpeta, TreeMap<String, Integer> conteo) {
        File[] contenido = carpeta.listFiles();
        if (contenido == null) { // Caso base
            return;
        }
        for (File elemento : contenido) {
            if (elemento.isFile()) {
                String tipo = new InfoFichero(elemento.getName(), elemento.getPath(), 0).getExtension();
                conteo.put(tipo, conteo.getOrDefault(tipo, 0) + 1);
            } else if (elemento.isDirectory()) {
                contarPorTipo(elemento, conteo); // Caso recursivo
            }
        }
    }

    /**
     * Muestra la estructura jerárquica de directorios (opción 7).
     */
    public void mostrarEstructura() {
        if (!validarRaiz()) {
            return;
        }
        System.out.println("\n--- ESTRUCTURA JERÁRQUICA DE DIRECTORIOS ---");
        System.out.println(raiz.getName() + "/");
        estructuraRecursiva(raiz, "");
    }

    // 7) estructuraRecursiva(File carpeta, String prefijo) [Recursivo]
    /**
     * Dibuja el árbol de directorios; el prefijo crece un nivel por cada subcarpeta.
     *
     * @param carpeta carpeta que se está procesando
     * @param prefijo sangría acumulada de los niveles superiores
     */
    private void estructuraRecursiva(File carpeta, String prefijo) {
        File[] contenido = carpeta.listFiles();
        if (contenido == null) { // Caso base
            return;
        }
        Arrays.sort(contenido);
        for (int i = 0; i < contenido.length; i++) {
            boolean esUltimo = (i == contenido.length - 1);
            File elemento = contenido[i];
            System.out.println(prefijo + (esUltimo ? "`-- " : "|-- ") + elemento.getName()
                    + (elemento.isDirectory() ? "/" : ""));
            if (elemento.isDirectory()) {
                estructuraRecursiva(elemento, prefijo + (esUltimo ? "    " : "|   ")); // Caso recursivo
            }
        }
    }
}
