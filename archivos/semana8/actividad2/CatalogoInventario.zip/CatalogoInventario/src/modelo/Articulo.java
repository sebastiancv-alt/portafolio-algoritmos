package modelo;

import java.util.Locale;

/**
 * Modelo que representa un artículo del catálogo: código, descripción, precio y cantidad disponible.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class Articulo {

    private String codigo;
    private String descripcion;
    private double precio;
    private int cantidad;

    /**
     * Crea un producto con todos sus datos.
     *
     * @param codigo código único del producto
     * @param descripcion descripción del producto
     * @param precio precio unitario
     * @param cantidad unidades disponibles
     */
    public Articulo(String codigo, String descripcion, double precio, int cantidad) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Articulo [Código: " + codigo + ", Descripción: " + descripcion
                + ", Precio: $" + String.format(Locale.US, "%.2f", precio)
                + ", Stock: " + cantidad + "]";
    }
}
