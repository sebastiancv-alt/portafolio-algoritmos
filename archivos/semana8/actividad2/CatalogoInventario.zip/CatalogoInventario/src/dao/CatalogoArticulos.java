package dao;

import modelo.Articulo;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

/**
 * DAO que administra el inventario en una colección <b>ordenada por código</b>.
 * La colección es privada; la búsqueda binaria y los cálculos del inventario se resuelven con métodos recursivos.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class CatalogoArticulos {

    // Colección ORDENADA por código (requisito de la búsqueda binaria)
    private ArrayList<Articulo> articulos = new ArrayList<>();

    // 1) registrarArticulo(Articulo articulo)
    /**
     * Registra un articulo manteniendo la colección ordenada por código.
     *
     * @param articulo articulo a registrar
     * @return true si se registró; false si el código ya existe
     */
    public boolean registrarArticulo(Articulo articulo) {
        if (!insertarOrdenado(articulo)) {
            System.out.println("Error: ya existe un articulo con el código " + articulo.getCodigo());
            return false;
        }
        return true;
    }

    /**
     * Inserta el articulo en la posición correcta; es el requisito para usar búsqueda binaria.
     *
     * @param articulo articulo a insertar
     * @return false si ya existe un articulo con ese código
     */
    private boolean insertarOrdenado(Articulo articulo) {
        int posicion = 0;
        while (posicion < articulos.size()
                && articulos.get(posicion).getCodigo().compareToIgnoreCase(articulo.getCodigo()) < 0) {
            posicion++; // Se busca la posición para mantener el orden por código
        }
        if (posicion < articulos.size()
                && articulos.get(posicion).getCodigo().equalsIgnoreCase(articulo.getCodigo())) {
            return false;
        }
        articulos.add(posicion, articulo);
        return true;
    }

    // 2) mostrarArticulos()
    /**
     * Muestra los articulos registrados, ordenados por código.
     */
    public void mostrarArticulos() {
        if (articulos.isEmpty()) {
            System.out.println("No hay articulos registrados.");
            return;
        }
        System.out.println("\n--- PRODUCTOS REGISTRADOS (ordenados por código) ---");
        for (int i = 0; i < articulos.size(); i++) {
            System.out.println("[" + i + "] " + articulos.get(i));
        }
        System.out.println("Total de articulos: " + articulos.size());
    }

    /**
     * Busca un articulo por código mediante búsqueda binaria recursiva (opción 3).
     *
     * @param codigo código a buscar
     * @return posición del articulo, o -1 si no existe
     */
    public int buscarPorCodigo(String codigo) {
        if (articulos.isEmpty()) {
            System.out.println("No hay articulos registrados.");
            return -1;
        }
        System.out.println("\nBúsqueda binaria recursiva de \"" + codigo + "\":");
        int indice = busquedaBinaria(codigo, 0, articulos.size() - 1);
        if (indice == -1) {
            System.out.println("Resultado: no existe un articulo con el código " + codigo);
        } else {
            System.out.println("Articulo encontrado en la posición [" + indice + "]: " + articulos.get(indice));
        }
        return indice;
    }

    // 3) busquedaBinaria(String codigo, int inicio, int fin) [Recursivo]
    /**
     * Búsqueda binaria recursiva: en cada llamada descarta la mitad del rango. Tiempo O(log n).
     * Casos base: rango vacío (no existe) y elemento central igual al buscado.
     *
     * @param codigo código buscado
     * @param inicio primera posición del rango
     * @param fin última posición del rango
     * @return posición encontrada, o -1
     */
    private int busquedaBinaria(String codigo, int inicio, int fin) {
        if (inicio > fin) { // Caso base: rango vacío, no existe
            return -1;
        }
        int medio = (inicio + fin) / 2;
        String codigoMedio = articulos.get(medio).getCodigo();
        System.out.println("   Paso: inicio=" + inicio + ", medio=" + medio + ", fin=" + fin + " -> " + codigoMedio);
        int comparacion = codigo.compareToIgnoreCase(codigoMedio);
        if (comparacion == 0) { // Caso base: encontrado
            return medio;
        }
        if (comparacion < 0) {
            return busquedaBinaria(codigo, inicio, medio - 1); // Mitad izquierda
        }
        return busquedaBinaria(codigo, medio + 1, fin);        // Mitad derecha
    }

    /**
     * Calcula el valor total del inventario (opción 4).
     *
     * @return suma de precio × cantidad de todos los articulos
     */
    public double calcularValorTotal() {
        double total = valorRecursivo(0);
        System.out.println("Valor total del inventario: $" + String.format(Locale.US, "%.2f", total));
        return total;
    }

    // 4) valorRecursivo(int indice) [Recursivo]
    /**
     * Suma recursivamente precio × cantidad desde la posición indicada hasta el final.
     * Caso base: el índice llegó al final de la lista.
     *
     * @param indice posición del articulo que se procesa
     * @return valor acumulado del resto de articulos
     */
    private double valorRecursivo(int indice) {
        if (indice == articulos.size()) { // Caso base: no quedan articulos
            return 0;
        }
        Articulo actual = articulos.get(indice);
        return actual.getPrecio() * actual.getCantidad() + valorRecursivo(indice + 1);
    }

    /**
     * Calcula las unidades totales disponibles (opción 5).
     *
     * @return total de unidades
     */
    public int calcularUnidadesTotales() {
        int total = unidadesRecursivo(0);
        System.out.println("Unidades totales disponibles: " + total);
        return total;
    }

    // 5) unidadesRecursivo(int indice) [Recursivo]
    /**
     * Suma recursivamente la cantidad disponible desde la posición indicada.
     *
     * @param indice posición del articulo que se procesa
     * @return unidades acumuladas del resto de articulos
     */
    private int unidadesRecursivo(int indice) {
        if (indice == articulos.size()) { // Caso base
            return 0;
        }
        return articulos.get(indice).getCantidad() + unidadesRecursivo(indice + 1);
    }

    /**
     * Muestra los articulos sin existencias, es decir, con cantidad igual a cero (opción 6).
     */
    public void mostrarSinExistencias() {
        ArrayList<Articulo> resultado = new ArrayList<>();
        sinExistenciasRecursivo(0, resultado);
        System.out.println("\n--- PRODUCTOS SIN EXISTENCIAS ---");
        if (resultado.isEmpty()) {
            System.out.println("Todos los articulos tienen stock disponible.");
            return;
        }
        for (Articulo p : resultado) {
            System.out.println(p);
        }
        System.out.println("Total sin existencias: " + resultado.size());
    }

    // 6) sinExistenciasRecursivo(int indice, ArrayList<Articulo> resultado) [Recursivo]
    /**
     * Recorre recursivamente la colección y reúne los articulos agotados.
     *
     * @param indice posición del articulo que se procesa
     * @param resultado lista donde se acumulan los agotados
     */
    private void sinExistenciasRecursivo(int indice, ArrayList<Articulo> resultado) {
        if (indice == articulos.size()) { // Caso base
            return;
        }
        if (articulos.get(indice).getCantidad() == 0) {
            resultado.add(articulos.get(indice));
        }
        sinExistenciasRecursivo(indice + 1, resultado); // Caso recursivo
    }

    /**
     * Genera el reporte de articulos con bajo inventario: de 1 unidad hasta el umbral (opción 7).
     *
     * @param umbral cantidad máxima considerada bajo inventario
     */
    public void reporteBajoInventario(int umbral) {
        ArrayList<Articulo> resultado = new ArrayList<>();
        bajoInventarioRecursivo(0, umbral, resultado);
        System.out.println("\n--- PRODUCTOS CON BAJO INVENTARIO (1 a " + umbral + " unidades) ---");
        if (resultado.isEmpty()) {
            System.out.println("No hay articulos con bajo inventario.");
            return;
        }
        for (Articulo p : resultado) {
            System.out.println(p);
        }
        System.out.println("Total con bajo inventario: " + resultado.size());
    }

    // 7) bajoInventarioRecursivo(int indice, int umbral, ArrayList<Articulo> resultado) [Recursivo]
    /**
     * Recorre recursivamente la colección y reúne los articulos con 1 a umbral unidades.
     *
     * @param indice posición del articulo que se procesa
     * @param umbral cantidad máxima considerada bajo inventario
     * @param resultado lista donde se acumulan los articulos
     */
    private void bajoInventarioRecursivo(int indice, int umbral, ArrayList<Articulo> resultado) {
        if (indice == articulos.size()) { // Caso base
            return;
        }
        int stock = articulos.get(indice).getCantidad();
        if (stock > 0 && stock <= umbral) {
            resultado.add(articulos.get(indice));
        }
        bajoInventarioRecursivo(indice + 1, umbral, resultado); // Caso recursivo
    }

    /**
     * Carga datos de ejemplo desde un archivo CSV; omite los códigos repetidos y controla los errores de lectura.
     *
     * @param ruta ruta del archivo CSV
     */
    public void cargarDatosPrueba(String ruta) {
        int cargados = 0;
        int omitidos = 0;
        try (BufferedReader lector = new BufferedReader(
                new InputStreamReader(new FileInputStream(ruta), StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (linea.trim().isEmpty() || linea.startsWith("#")) {
                    continue; // Se ignoran comentarios y líneas vacías
                }
                String[] campos = linea.split(",");
                Articulo nuevo = new Articulo(campos[0].trim(), campos[1].trim(),
                        Double.parseDouble(campos[2].trim()), Integer.parseInt(campos[3].trim()));
                if (insertarOrdenado(nuevo)) {
                    cargados++;
                } else {
                    omitidos++; // Código repetido: no se duplica
                }
            }
            System.out.println("Datos de prueba cargados: " + cargados + " articulo(s)"
                    + (omitidos > 0 ? " (" + omitidos + " omitido(s) por código repetido)." : "."));
        } catch (IOException | RuntimeException e) {
            System.out.println("No se pudo cargar el archivo " + ruta + ": " + e.getMessage());
        }
    }
}
