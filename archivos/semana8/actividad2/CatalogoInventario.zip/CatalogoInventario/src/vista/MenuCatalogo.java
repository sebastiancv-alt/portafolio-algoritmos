package vista;

import dao.CatalogoArticulos;
import modelo.Articulo;
import java.util.Locale;
import java.util.Scanner;

/**
 * Vista de consola: muestra el menú, valida la entrada del usuario y delega toda la lógica en el DAO.
 *
 * @author Proyecto de estructuras de datos
 * @version 1.0
 */
public class MenuCatalogo {

    private static final String RUTA_DATOS = "datos_prueba/articulos.csv";

    /**
     * Punto de entrada: muestra el menú y atiende las opciones hasta que el usuario elige salir.
     *
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        teclado.useLocale(Locale.US); // Los decimales se escriben con punto
        CatalogoArticulos inventario = new CatalogoArticulos();
        int opcion = 0;

        do {
            System.out.println("\n=================================================");
            System.out.println("  BÚSQUEDA DE PRODUCTOS E INVENTARIO (RECURSIVO)");
            System.out.println("=================================================");
            System.out.println("1. Registrar articulo");
            System.out.println("2. Mostrar articulos");
            System.out.println("3. Buscar por código (búsqueda binaria recursiva)");
            System.out.println("4. Calcular valor total del inventario");
            System.out.println("5. Calcular unidades totales disponibles");
            System.out.println("6. Identificar articulos sin existencias");
            System.out.println("7. Reporte de articulos con bajo inventario");
            System.out.println("8. Cargar datos de prueba");
            System.out.println("9. Salir");
            System.out.print("Seleccione una opción: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine(); // Limpiar buffer
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                teclado.next();
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese Código: ");
                    String codigo = teclado.nextLine().trim();
                    System.out.print("Ingrese Descripción: ");
                    String descripcion = teclado.nextLine().trim();
                    double precio = leerDecimal(teclado, "Ingrese Precio ($): ");
                    int cantidad = leerEntero(teclado, "Ingrese Cantidad disponible: ");
                    if (codigo.isEmpty() || descripcion.isEmpty() || precio < 0 || cantidad < 0) {
                        System.out.println("Datos inválidos: complete todos los campos con valores positivos.");
                    } else if (inventario.registrarArticulo(new Articulo(codigo, descripcion, precio, cantidad))) {
                        System.out.println("Articulo registrado correctamente.");
                    }
                    break;
                case 2:
                    inventario.mostrarArticulos();
                    break;
                case 3:
                    System.out.print("Ingrese el código a buscar: ");
                    String buscar = teclado.nextLine().trim();
                    inventario.buscarPorCodigo(buscar);
                    break;
                case 4:
                    inventario.calcularValorTotal();
                    break;
                case 5:
                    inventario.calcularUnidadesTotales();
                    break;
                case 6:
                    inventario.mostrarSinExistencias();
                    break;
                case 7:
                    int umbral = leerEntero(teclado, "Ingrese el umbral de bajo inventario (unidades): ");
                    inventario.reporteBajoInventario(umbral);
                    break;
                case 8:
                    inventario.cargarDatosPrueba(RUTA_DATOS);
                    break;
                case 9:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 9);

        teclado.close();
    }

    /**
     * Lee un entero con validación: repite la pregunta hasta recibir un valor válido.
     *
     * @param teclado lector de consola
     * @param mensaje texto a mostrar
     * @return valor entero leído
     */
    private static int leerEntero(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextInt()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        int valor = teclado.nextInt();
        teclado.nextLine();
        return valor;
    }

    /**
     * Lee un decimal con validación: repite la pregunta hasta recibir un valor válido.
     *
     * @param teclado lector de consola
     * @param mensaje texto a mostrar
     * @return valor decimal leído
     */
    private static double leerDecimal(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextDouble()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        double valor = teclado.nextDouble();
        teclado.nextLine();
        return valor;
    }
}
