package modelo;

public class NodoEquipo {

    private EquipoPC equipo;
    private NodoEquipo siguiente;

    public NodoEquipo(EquipoPC equipo) {
        this.equipo = equipo;
        this.siguiente = null;
    }

    public EquipoPC getEquipo() {
        return equipo;
    }

    public void setEquipo(EquipoPC equipo) {
        this.equipo = equipo;
    }

    public NodoEquipo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoEquipo siguiente) {
        this.siguiente = siguiente;
    }
}
