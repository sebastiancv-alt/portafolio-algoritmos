package modelo;

import java.util.Locale;

public class EquipoPC {

    private String serie;
    private String marca;
    private String modelo;
    private String cpu;
    private int memoriaRam;
    private double valor;

    public EquipoPC(String serie, String marca, String modelo,
            String cpu, int memoriaRam, double valor) {
        this.serie = serie;
        this.marca = marca;
        this.modelo = modelo;
        this.cpu = cpu;
        this.memoriaRam = memoriaRam;
        this.valor = valor;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getMemoriaRam() {
        return memoriaRam;
    }

    public void setMemoriaRam(int memoriaRam) {
        this.memoriaRam = memoriaRam;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Equipo [Serie: " + serie + ", Marca: " + marca
                + ", Modelo: " + modelo + ", CPU: " + cpu
                + ", RAM: " + memoriaRam + "GB, Precio: $"
                + String.format(Locale.US, "%.2f", valor) + "]";
    }
}
