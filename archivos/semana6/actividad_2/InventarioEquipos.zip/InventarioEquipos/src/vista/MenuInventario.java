package vista;

import dao.StackInventario;
import modelo.EquipoPC;
import java.util.Locale;
import java.util.Scanner;

public class MenuInventario {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        teclado.useLocale(Locale.US);
        StackInventario pila = new StackInventario();
        int opcion = 0;

        do {
            System.out.println("\n=================================================");
            System.out.println("  INVENTARIO DE EQUIPOS (PILA DINÁMICA)");
            System.out.println("=================================================");
            System.out.println("1. Registrar equipo (apilar)");
            System.out.println("2. Ver inventario");
            System.out.println("3. Despachar equipo de la cima (desapilar)");
            System.out.println("4. Consultar cima");
            System.out.println("5. Limpiar inventario");
            System.out.println("6. Contar equipos");
            System.out.println("7. Buscar por número de serie");
            System.out.println("8. Calcular valor total del inventario");
            System.out.println("9. Equipos superiores a un precio");
            System.out.println("10. Equipo más caro");
            System.out.println("11. Salir");
            System.out.print("Seleccione una opción: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine();
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                teclado.next();
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese Número de Serie: ");
                    String serie = teclado.nextLine();
                    System.out.print("Ingrese Marca: ");
                    String marca = teclado.nextLine();
                    System.out.print("Ingrese Modelo: ");
                    String modelo = teclado.nextLine();
                    System.out.print("Ingrese Procesador: ");
                    String cpu = teclado.nextLine();
                    int ram = leerEntero(teclado, "Ingrese Memoria RAM en GB: ");
                    double precio = leerDecimal(teclado, "Ingrese Precio ($): ");
                    pila.apilar(new EquipoPC(serie, marca, modelo, cpu, ram, precio));
                    break;
                case 2:
                    pila.listarInventario();
                    break;
                case 3:
                    pila.desapilar();
                    break;
                case 4:
                    pila.verCima();
                    break;
                case 5:
                    pila.limpiar();
                    break;
                case 6:
                    pila.contar();
                    break;
                case 7:
                    System.out.print("Ingrese el número de serie a buscar: ");
                    String buscar = teclado.nextLine();
                    pila.buscarPorSerie(buscar);
                    break;
                case 8:
                    pila.calcularValorTotal();
                    break;
                case 9:
                    double limite = leerDecimal(teclado, "Ingrese el precio de referencia ($): ");
                    pila.filtrarPorPrecio(limite);
                    break;
                case 10:
                    pila.equipoMasCaro();
                    break;
                case 11:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 11);

        teclado.close();
    }

    private static int leerEntero(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextInt()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        int valor = teclado.nextInt();
        teclado.nextLine();
        return valor;
    }

    private static double leerDecimal(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextDouble()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        double valor = teclado.nextDouble();
        teclado.nextLine();
        return valor;
    }
}
