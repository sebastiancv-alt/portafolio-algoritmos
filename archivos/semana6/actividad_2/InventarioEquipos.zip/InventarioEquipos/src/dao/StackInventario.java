package dao;

import modelo.EquipoPC;
import modelo.NodoEquipo;
import java.util.Locale;

public class StackInventario {

    private NodoEquipo tope;

    public StackInventario() {
        this.tope = null;
    }

    public boolean estaVacia() {
        return tope == null;
    }

    public void apilar(EquipoPC equipo) {
        NodoEquipo nuevo = new NodoEquipo(equipo);
        nuevo.setSiguiente(tope);
        tope = nuevo;
        System.out.println("Equipo con serie [" + equipo.getSerie() + "] apilado con éxito.");
    }

    public void listarInventario() {
        if (estaVacia()) {
            System.out.println("El inventario está vacío. No hay equipos registrados.");
            return;
        }
        System.out.println("\n--- INVENTARIO DE EQUIPOS (Cima a Base) ---");
        NodoEquipo actual = tope;
        int posicion = 1;
        while (actual != null) {
            if (posicion == 1) {
                System.out.println("-> [CIMA] " + actual.getEquipo());
            } else {
                System.out.println("   [     ] " + actual.getEquipo());
            }
            actual = actual.getSiguiente();
            posicion++;
        }
        System.out.println("---------------------------------------------");
    }

    public EquipoPC desapilar() {
        if (estaVacia()) {
            System.out.println("Error: Underflow. El inventario está vacío, no hay equipos para despachar.");
            return null;
        }
        EquipoPC despachado = tope.getEquipo();
        tope = tope.getSiguiente();
        System.out.println("Equipo despachado con éxito de la cima (Serie): " + despachado.getSerie());
        return despachado;
    }

    public EquipoPC verCima() {
        if (estaVacia()) {
            System.out.println("El inventario está vacío. No hay equipos en la cima.");
            return null;
        }
        System.out.println("Equipo en la cima actual: " + tope.getEquipo());
        return tope.getEquipo();
    }

    public void limpiar() {
        if (estaVacia()) {
            System.out.println("El inventario ya se encuentra vacío.");
            return;
        }
        tope = null;
        System.out.println("El inventario de equipos ha sido limpiado por completo.");
    }

    public int contar() {
        int total = 0;
        NodoEquipo actual = tope;
        while (actual != null) {
            total++;
            actual = actual.getSiguiente();
        }
        System.out.println("Total de equipos almacenados: " + total);
        return total;
    }

    public EquipoPC buscarPorSerie(String serie) {
        if (estaVacia()) {
            System.out.println("El inventario está vacío. No hay equipos para buscar.");
            return null;
        }
        NodoEquipo actual = tope;
        int posicion = 1;
        while (actual != null) {
            if (actual.getEquipo().getSerie().equalsIgnoreCase(serie)) {
                System.out.println("Equipo encontrado: " + actual.getEquipo());
                System.out.println("Posición desde la cima: " + posicion);
                return actual.getEquipo();
            }
            actual = actual.getSiguiente();
            posicion++;
        }
        System.out.println("No existe ningún equipo con la serie: " + serie);
        return null;
    }

    public double calcularValorTotal() {
        double total = 0;
        NodoEquipo actual = tope;
        while (actual != null) {
            total += actual.getEquipo().getValor();
            actual = actual.getSiguiente();
        }
        System.out.println("Valor total del inventario: $" + String.format(Locale.US, "%.2f", total));
        return total;
    }

    public void filtrarPorPrecio(double precioLimite) {
        if (estaVacia()) {
            System.out.println("El inventario está vacío. No hay equipos para filtrar.");
            return;
        }
        System.out.println("\n--- EQUIPOS CON PRECIO MAYOR A $" + String.format(Locale.US, "%.2f", precioLimite) + " ---");
        NodoEquipo actual = tope;
        int encontrados = 0;
        while (actual != null) {
            if (actual.getEquipo().getValor() > precioLimite) {
                System.out.println(actual.getEquipo());
                encontrados++;
            }
            actual = actual.getSiguiente();
        }
        if (encontrados == 0) {
            System.out.println("Ningún equipo supera el precio de referencia.");
        } else {
            System.out.println("Total encontrados: " + encontrados);
        }
    }

    public EquipoPC equipoMasCaro() {
        if (estaVacia()) {
            System.out.println("El inventario está vacío. No hay equipos para comparar.");
            return null;
        }
        EquipoPC masCaro = tope.getEquipo();
        NodoEquipo actual = tope.getSiguiente();
        while (actual != null) {
            if (actual.getEquipo().getValor() > masCaro.getValor()) {
                masCaro = actual.getEquipo();
            }
            actual = actual.getSiguiente();
        }
        System.out.println("Equipo más caro del inventario: " + masCaro);
        return masCaro;
    }
}
