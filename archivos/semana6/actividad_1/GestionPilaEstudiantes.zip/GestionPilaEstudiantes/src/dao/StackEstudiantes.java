package dao;

import modelo.EstudianteRegistro;

public class StackEstudiantes {

    private int maximo;
    private EstudianteRegistro[] datos;
    private int cima;

    public StackEstudiantes(int maximo) {
        this.maximo = maximo;
        this.datos = new EstudianteRegistro[maximo];
        this.cima = -1;
    }

    public boolean estaLlena() {
        return cima == maximo - 1;
    }

    public boolean estaVacia() {
        return cima == -1;
    }

    public boolean apilar(EstudianteRegistro estudiante) {
        if (estaLlena()) {
            System.out.println("Error: Desbordamiento (Stack Overflow). La pila está llena.");
            return false;
        }
        cima++;
        datos[cima] = estudiante;
        System.out.println("Estudiante insertado correctamente en el tope.");
        return true;
    }

    public void listarPila() {
        if (estaVacia()) {
            System.out.println("La pila de estudiantes está vacía.");
            return;
        }
        System.out.println("\n--- CONTENIDO DE LA PILA DE ESTUDIANTES (Cima a Base) ---");
        for (int i = cima; i >= 0; i--) {
            if (i == cima) {
                System.out.println("-> [CIMA] " + datos[i]);
            } else {
                System.out.println("   [     ] " + datos[i]);
            }
        }
        System.out.println("----------------------------------------------------------");
    }

    public EstudianteRegistro desapilar() {
        if (estaVacia()) {
            System.out.println("Error: Subdesbordamiento (Stack Underflow). No hay estudiantes para eliminar.");
            return null;
        }
        EstudianteRegistro eliminado = datos[cima];
        datos[cima] = null;
        cima--;
        System.out.println("Estudiante eliminado del tope con éxito: " + eliminado.getNombreCompleto());
        return eliminado;
    }

    public void vaciarPila() {
        if (estaVacia()) {
            System.out.println("La pila ya se encuentra vacía.");
            return;
        }
        for (int i = 0; i <= cima; i++) {
            datos[i] = null;
        }
        cima = -1;
        System.out.println("La pila de estudiantes ha sido vaciada por completo.");
    }

    public EstudianteRegistro verCima() {
        if (estaVacia()) {
            System.out.println("La pila está vacía. No hay estudiante en la cima.");
            return null;
        }
        System.out.println("Estudiante en la cima: " + datos[cima]);
        return datos[cima];
    }

    public void estadoCapacidad() {
        int elementos = cima + 1;
        int libres = maximo - elementos;
        System.out.println("\n--- ESTADO DE CAPACIDAD ---");
        System.out.println("Capacidad total        : " + maximo);
        System.out.println("Elementos almacenados  : " + elementos);
        System.out.println("Espacios libres        : " + libres);
    }

    public void buscarPorId(String id) {
        if (estaVacia()) {
            System.out.println("La pila está vacía. No hay estudiantes para buscar.");
            return;
        }
        for (int i = cima; i >= 0; i--) {
            if (datos[i].getId().equalsIgnoreCase(id)) {
                int posicion = cima - i;
                System.out.println("Estudiante encontrado: " + datos[i]);
                if (posicion == 0) {
                    System.out.println("Posición relativa: se encuentra en la CIMA.");
                } else {
                    System.out.println("Posición relativa: " + posicion
                            + " posición(es) debajo de la cima.");
                }
                return;
            }
        }
        System.out.println("No existe ningún estudiante con el ID: " + id);
    }

    public void estadoLogico() {
        System.out.println("\n--- ESTADO LÓGICO DE LA PILA ---");
        System.out.println("¿La pila está vacía? : " + estaVacia());
        System.out.println("¿La pila está llena? : " + estaLlena());
    }

    public void mostrarMejorPromedio() {
        if (estaVacia()) {
            System.out.println("La pila está vacía. No se puede determinar el mejor promedio.");
            return;
        }
        EstudianteRegistro mejor = datos[cima];
        for (int i = cima - 1; i >= 0; i--) {
            if (datos[i].getNotaPromedio() > mejor.getNotaPromedio()) {
                mejor = datos[i];
            }
        }
        System.out.println("\nEstudiante con el mayor promedio: " + mejor);
    }
}
