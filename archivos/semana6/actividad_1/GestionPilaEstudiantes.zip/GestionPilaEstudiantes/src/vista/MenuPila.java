package vista;

import dao.StackEstudiantes;
import modelo.EstudianteRegistro;
import java.util.Scanner;

public class MenuPila {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int capacidad;
        do {
            System.out.print("Ingrese la capacidad máxima de la pila de estudiantes: ");
            while (!teclado.hasNextInt()) {
                System.out.print("Ingrese un número entero válido: ");
                teclado.next();
            }
            capacidad = teclado.nextInt();
            teclado.nextLine();
            if (capacidad <= 0) {
                System.out.println("La capacidad debe ser mayor que cero.");
            }
        } while (capacidad <= 0);

        StackEstudiantes pila = new StackEstudiantes(capacidad);
        int opcion = 0;

        do {
            System.out.println("\n==========================================");
            System.out.println("  GESTIÓN DE ESTUDIANTES CON PILA");
            System.out.println("==========================================");
            System.out.println("1. Registrar estudiante (apilar)");
            System.out.println("2. Ver listado de la pila");
            System.out.println("3. Quitar estudiante del tope (desapilar)");
            System.out.println("4. Vaciar toda la pila");
            System.out.println("5. Consultar elemento en la cima");
            System.out.println("6. Ver estado de capacidad");
            System.out.println("7. Buscar estudiante por ID");
            System.out.println("8. Verificar estado lógico (vacía/llena)");
            System.out.println("9. Mostrar mejor promedio");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine();
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                teclado.next();
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    if (pila.estaLlena()) {
                        System.out.println("Error: Desbordamiento (Stack Overflow). La pila está llena.");
                        break;
                    }
                    System.out.print("Ingrese ID: ");
                    String id = teclado.nextLine();
                    System.out.print("Ingrese Nombre completo: ");
                    String nombre = teclado.nextLine();
                    int anios = leerEntero(teclado, "Ingrese Edad: ");
                    double promedio = leerDecimal(teclado, "Ingrese Promedio: ");
                    pila.apilar(new EstudianteRegistro(id, nombre, anios, promedio));
                    break;
                case 2:
                    pila.listarPila();
                    break;
                case 3:
                    pila.desapilar();
                    break;
                case 4:
                    pila.vaciarPila();
                    break;
                case 5:
                    pila.verCima();
                    break;
                case 6:
                    pila.estadoCapacidad();
                    break;
                case 7:
                    System.out.print("Ingrese el ID a buscar: ");
                    String buscar = teclado.nextLine();
                    pila.buscarPorId(buscar);
                    break;
                case 8:
                    pila.estadoLogico();
                    break;
                case 9:
                    pila.mostrarMejorPromedio();
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 0);

        teclado.close();
    }

    private static int leerEntero(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextInt()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        int valor = teclado.nextInt();
        teclado.nextLine();
        return valor;
    }

    private static double leerDecimal(Scanner teclado, String mensaje) {
        System.out.print(mensaje);
        while (!teclado.hasNextDouble()) {
            System.out.print("Valor inválido. " + mensaje);
            teclado.next();
        }
        double valor = teclado.nextDouble();
        teclado.nextLine();
        return valor;
    }
}
