package modelo;

public class EstudianteRegistro {

    private String id;
    private String nombreCompleto;
    private int anios;
    private double notaPromedio;

    public EstudianteRegistro() {
    }

    public EstudianteRegistro(String id, String nombreCompleto, int anios, double notaPromedio) {
        this.id = id;
        this.nombreCompleto = nombreCompleto;
        this.anios = anios;
        this.notaPromedio = notaPromedio;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getAnios() {
        return anios;
    }

    public void setAnios(int anios) {
        this.anios = anios;
    }

    public double getNotaPromedio() {
        return notaPromedio;
    }

    public void setNotaPromedio(double notaPromedio) {
        this.notaPromedio = notaPromedio;
    }

    @Override
    public String toString() {
        return "Estudiante [ID: " + id + ", Nombre: " + nombreCompleto
                + ", Edad: " + anios + ", Promedio: " + notaPromedio + "]";
    }
}
