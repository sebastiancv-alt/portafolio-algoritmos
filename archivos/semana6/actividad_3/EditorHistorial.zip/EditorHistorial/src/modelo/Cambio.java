package modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Cambio {

    private int codigo;
    private String detalle;
    private LocalDateTime momento;

    public Cambio(int codigo, String detalle) {
        this.codigo = codigo;
        this.detalle = detalle;
        this.momento = LocalDateTime.now();
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public LocalDateTime getMomento() {
        return momento;
    }

    public void setMomento(LocalDateTime momento) {
        this.momento = momento;
    }

    @Override
    public String toString() {
        return "Cambio [ID: " + codigo + ", Descripción: " + detalle
                + ", Hora: " + momento.format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "]";
    }
}
