package modelo;

public class NodoCambio {

    private Cambio cambio;
    private NodoCambio siguiente;

    public NodoCambio(Cambio cambio) {
        this.cambio = cambio;
        this.siguiente = null;
    }

    public Cambio getCambio() {
        return cambio;
    }

    public void setCambio(Cambio cambio) {
        this.cambio = cambio;
    }

    public NodoCambio getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCambio siguiente) {
        this.siguiente = siguiente;
    }
}
