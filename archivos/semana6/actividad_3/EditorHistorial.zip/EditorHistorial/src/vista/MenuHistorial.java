package vista;

import dao.HistorialCambios;
import java.util.Scanner;

public class MenuHistorial {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        HistorialCambios gestor = new HistorialCambios();
        int opcion = 0;

        do {
            System.out.println("\n=================================================");
            System.out.println("  EDITOR CON HISTORIAL DE CAMBIOS (UNDO/REDO)");
            System.out.println("=================================================");
            System.out.println("1. Registrar nuevo cambio");
            System.out.println("2. Deshacer (Undo)");
            System.out.println("3. Rehacer (Redo)");
            System.out.println("4. Mostrar estado del historial");
            System.out.println("5. Buscar cambio en el historial");
            System.out.println("6. Invertir pila de cambios vigentes");
            System.out.println("7. Exportar resumen del historial");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opción: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine();
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                teclado.next();
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese la descripción del cambio: ");
                    String detalle = teclado.nextLine().trim();
                    if (detalle.isEmpty()) {
                        System.out.println("La descripción no puede estar vacía.");
                    } else {
                        gestor.registrarCambio(detalle);
                    }
                    break;
                case 2:
                    gestor.deshacer();
                    break;
                case 3:
                    gestor.rehacer();
                    break;
                case 4:
                    gestor.mostrarEstado();
                    break;
                case 5:
                    System.out.print("Ingrese la palabra clave a buscar: ");
                    String clave = teclado.nextLine().trim();
                    gestor.buscarEnHistorial(clave);
                    break;
                case 6:
                    gestor.invertirPilaVigentes();
                    break;
                case 7:
                    gestor.exportarResumen();
                    break;
                case 8:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 8);

        teclado.close();
    }
}
