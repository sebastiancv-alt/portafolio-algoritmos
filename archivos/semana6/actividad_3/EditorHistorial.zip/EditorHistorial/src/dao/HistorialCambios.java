package dao;

import modelo.Cambio;
import modelo.NodoCambio;

public class HistorialCambios {

    private NodoCambio cimaVigentes;
    private NodoCambio cimaDeshechos;
    private int contadorId;
    private int totalUndo;
    private int totalRedo;

    public HistorialCambios() {
        this.cimaVigentes = null;
        this.cimaDeshechos = null;
    }

    public void registrarCambio(String detalle) {
        contadorId++;
        Cambio nuevo = new Cambio(contadorId, detalle);
        NodoCambio nodo = new NodoCambio(nuevo);
        nodo.setSiguiente(cimaVigentes);
        cimaVigentes = nodo;
        System.out.println("Cambio registrado: " + nuevo);
        if (cimaDeshechos != null) {
            cimaDeshechos = null;
            System.out.println("Pila de rehacer vaciada: ya no se pueden rehacer cambios anteriores.");
        }
    }

    public Cambio deshacer() {
        if (cimaVigentes == null) {
            System.out.println("Error: Underflow. No hay cambios para deshacer.");
            return null;
        }
        NodoCambio nodo = cimaVigentes;
        cimaVigentes = nodo.getSiguiente();
        nodo.setSiguiente(cimaDeshechos);
        cimaDeshechos = nodo;
        totalUndo++;
        System.out.println("Cambio deshecho: " + nodo.getCambio());
        return nodo.getCambio();
    }

    public Cambio rehacer() {
        if (cimaDeshechos == null) {
            System.out.println("Error: Underflow. No hay cambios para rehacer.");
            return null;
        }
        NodoCambio nodo = cimaDeshechos;
        cimaDeshechos = nodo.getSiguiente();
        nodo.setSiguiente(cimaVigentes);
        cimaVigentes = nodo;
        totalRedo++;
        System.out.println("Cambio rehecho: " + nodo.getCambio());
        return nodo.getCambio();
    }

    public void mostrarEstado() {
        System.out.println("\n--- HISTORIAL VIGENTE: pila de cambios (Cima a Base) ---");
        NodoCambio actual = cimaVigentes;
        if (actual == null) {
            System.out.println("   (vacía)");
        }
        while (actual != null) {
            System.out.println((actual == cimaVigentes ? "-> [CIMA] " : "   [     ] ") + actual.getCambio());
            actual = actual.getSiguiente();
        }
        System.out.println("\n--- DISPONIBLES PARA REHACER: pila de deshechos (Cima a Base) ---");
        actual = cimaDeshechos;
        if (actual == null) {
            System.out.println("   (vacía)");
        }
        while (actual != null) {
            System.out.println((actual == cimaDeshechos ? "-> [CIMA] " : "   [     ] ") + actual.getCambio());
            actual = actual.getSiguiente();
        }
    }

    public void buscarEnHistorial(String palabraClave) {
        String clave = palabraClave.toLowerCase();
        int coincidencias = 0;
        NodoCambio actual = cimaVigentes;
        while (actual != null) {
            if (actual.getCambio().getDetalle().toLowerCase().contains(clave)) {
                System.out.println("[VIGENTE]  " + actual.getCambio());
                coincidencias++;
            }
            actual = actual.getSiguiente();
        }
        actual = cimaDeshechos;
        while (actual != null) {
            if (actual.getCambio().getDetalle().toLowerCase().contains(clave)) {
                System.out.println("[DESHECHA] " + actual.getCambio());
                coincidencias++;
            }
            actual = actual.getSiguiente();
        }
        if (coincidencias == 0) {
            System.out.println("No se encontró ningún cambio que contenga: " + palabraClave);
        } else {
            System.out.println("Total de coincidencias: " + coincidencias);
        }
    }

    public void invertirPilaVigentes() {
        if (cimaVigentes == null) {
            System.out.println("La pila de cambios está vacía. No hay nada que invertir.");
            return;
        }
        NodoCambio aux = null;
        while (cimaVigentes != null) {
            NodoCambio nodo = cimaVigentes;
            cimaVigentes = nodo.getSiguiente();
            nodo.setSiguiente(aux);
            aux = nodo;
        }
        cimaVigentes = aux;
        System.out.println("\n--- HISTORIAL EN ORDEN CRONOLÓGICO (desde el inicio) ---");
        NodoCambio actual = cimaVigentes;
        while (actual != null) {
            System.out.println(actual.getCambio());
            actual = actual.getSiguiente();
        }
        System.out.println("La pila quedó invertida. Ejecute esta opción de nuevo para restaurar el orden.");
    }

    public void exportarResumen() {
        int vigentes = 0;
        NodoCambio actual = cimaVigentes;
        while (actual != null) {
            vigentes++;
            actual = actual.getSiguiente();
        }
        int porRehacer = 0;
        actual = cimaDeshechos;
        while (actual != null) {
            porRehacer++;
            actual = actual.getSiguiente();
        }
        System.out.println("\n--- RESUMEN ESTADÍSTICO DEL HISTORIAL ---");
        System.out.println("Total de cambios acumulados      : " + contadorId);
        System.out.println("Nodos en pila vigentes           : " + vigentes);
        System.out.println("Nodos en pila de rehacer         : " + porRehacer);
        System.out.println("Operaciones Deshacer realizadas  : " + totalUndo);
        System.out.println("Operaciones Rehacer realizadas   : " + totalRedo);
    }
}
